/* global React, ReactDOM, DesignCanvas, DCSection, DCArtboard,
   EndpointsDashboard, EndpointsAgents, EndpointsAgentDetail,
   EndpointsTasks, CreateTaskModal, EnrollAgentModal, ExecutionDetailModal,
   useTweaks, TweaksPanel, TweakSection, TweakRadio */
const { createRoot: createRootEp } = ReactDOM;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "heartbeatChartStyle": "line",
  "executionPattern": "modal",
  "agentDetailTab": "heartbeat"
}/*EDITMODE-END*/;

function EndpointsApp() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);

  return (
    <>
      <DesignCanvas
        title="Achilles · Endpoints Module"
        subtitle="Fleet management — dashboard, agents, detail (4 tabs), tasks + 3 modals · variations gated by Tweaks"
        backgroundColor="#02040a"
      >
        <DCSection id="dashboard" title="01 · Agent Dashboard" subtitle="Fleet KPIs, version/OS/status mix, recent tasks">
          <DCArtboard id="dash" label="Endpoints — Dashboard" width={1280} height={1500} background="#02040a">
            <EndpointsDashboard/>
          </DCArtboard>
        </DCSection>

        <DCSection id="agents" title="02 · Agents List" subtitle="Filterable host table · health, version, tags">
          <DCArtboard id="agents" label="Endpoints — Agents" width={1280} height={950} background="#02040a">
            <EndpointsAgents/>
          </DCArtboard>
        </DCSection>

        <DCSection id="detail" title="03 · Agent Detail" subtitle="Per-agent surface — Overview / Task History / Heartbeat / Event Log tabs">
          <DCArtboard id="detail-overview" label="Agent Detail — Overview" width={1280} height={1150} background="#02040a">
            <EndpointsAgentDetail tab="overview"/>
          </DCArtboard>
          <DCArtboard id="detail-tasks" label="Agent Detail — Task History" width={1280} height={900} background="#02040a">
            <EndpointsAgentDetail tab="tasks"/>
          </DCArtboard>
          <DCArtboard id="detail-heartbeat" label="Agent Detail — Heartbeat" width={1280} height={1000} background="#02040a">
            <EndpointsAgentDetail tab="heartbeat" chartStyle={tweaks.heartbeatChartStyle}/>
          </DCArtboard>
          <DCArtboard id="detail-events" label="Agent Detail — Event Log" width={1280} height={1100} background="#02040a">
            <EndpointsAgentDetail tab="events"/>
          </DCArtboard>
        </DCSection>

        <DCSection id="tasks" title="04 · Tasks" subtitle="Scheduled bundles + execution table with expandable agent rows">
          <DCArtboard id="tasks" label="Endpoints — Tasks" width={1280} height={1500} background="#02040a">
            <EndpointsTasks/>
          </DCArtboard>
        </DCSection>

        <DCSection id="modals" title="05 · Modals & Drawers" subtitle="Create Task · Enroll Agent · Execution Detail (pattern toggleable in Tweaks)">
          <DCArtboard id="modal-create" label="Modal — Create Task" width={1280} height={950} background="#02040a">
            <CreateTaskModal onClose={()=>{}}/>
          </DCArtboard>
          <DCArtboard id="modal-enroll" label="Modal — Enroll Agent" width={1280} height={950} background="#02040a">
            <EnrollAgentModal onClose={()=>{}}/>
          </DCArtboard>
          <DCArtboard id="modal-exec" label={`Modal — Execution Detail (${tweaks.executionPattern})`} width={1280} height={950} background="#02040a">
            <ExecutionDetailModal onClose={()=>{}} pattern={tweaks.executionPattern}/>
          </DCArtboard>
        </DCSection>
      </DesignCanvas>

      <TweaksPanel title="Endpoints Tweaks">
        <TweakSection title="Heartbeat charts">
          <TweakRadio
            label="Chart style"
            value={tweaks.heartbeatChartStyle}
            options={[
              { value:'line', label:'Line' },
              { value:'area', label:'Area' },
            ]}
            onChange={v => setTweak('heartbeatChartStyle', v)}
          />
        </TweakSection>
        <TweakSection title="Execution detail">
          <TweakRadio
            label="Pattern"
            value={tweaks.executionPattern}
            options={[
              { value:'modal',  label:'Modal' },
              { value:'drawer', label:'Drawer' },
            ]}
            onChange={v => setTweak('executionPattern', v)}
          />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

createRootEp(document.getElementById('root')).render(<EndpointsApp/>);
