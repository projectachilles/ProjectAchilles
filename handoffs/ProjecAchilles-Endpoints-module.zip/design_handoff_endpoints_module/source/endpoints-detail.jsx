/* global React, Icon, I, EI, EpShell, ED, OsPill, HealthBadge, StatusPill, EpSpark, EpLineChart */
const { useState: useDetailState } = React;

// ── Info row ─────────────────────────────────────────────────────────
function InfoRow({ icon, label, value, valueColor }) {
  return (
    <div className="ep-info-row">
      <span className="label">{icon && <Icon d={icon} size={12}/>}{label}</span>
      <span className="value" style={valueColor ? {color: valueColor} : null}>{value}</span>
    </div>
  );
}

// ── Tab nav ──────────────────────────────────────────────────────────
function Tabs({ tabs, active, onChange }) {
  return (
    <div className="ep-tabs">
      {tabs.map(t => (
        <button key={t.id} className={`ep-tab ${active===t.id?'is-active':''}`} onClick={() => onChange(t.id)}>
          {t.label}
        </button>
      ))}
    </div>
  );
}

// ── Overview tab ─────────────────────────────────────────────────────
function OverviewTab({ a }) {
  return (
    <>
      <div className="ep-grid">
        <div className="col-6 ep-card">
          <div className="ep-card-head">
            <div className="ep-card-title"><Icon d={I.cmd} size={14}/> System Information</div>
          </div>
          <InfoRow icon={I.layout}    label="Hostname"        value={a.hostname}/>
          <InfoRow icon={I.monitor}   label="OS / Arch"       value={`${a.os} / ${a.arch}`}/>
          <InfoRow icon={I.cmd}       label="Agent Version"   value={a.version}/>
          <InfoRow icon={EI.cpu}      label="CPU"             value={a.cpu} valueColor="var(--accent)"/>
          <InfoRow icon={EI.mem}      label="Memory"          value={a.memory}/>
          <InfoRow icon={EI.hdd}      label="Disk Free"       value={a.diskFree}/>
          <InfoRow icon={I.clock}     label="Uptime"          value={a.uptime}/>
        </div>

        <div className="col-6 ep-card">
          <div className="ep-card-head">
            <div className="ep-card-title"><Icon d={I.shield} size={14}/> Metadata</div>
          </div>
          <InfoRow label="Enrolled"        value={a.enrolled}/>
          <InfoRow label="Last Heartbeat"  value={a.lastHeartbeat}/>
          <div className="ep-info-row">
            <span className="label">Status</span>
            <span><StatusPill status={a.status}/></span>
          </div>
          <div className="ep-info-row">
            <span className="label">Health Score</span>
            <span><HealthBadge value={a.health}/></span>
          </div>
          <InfoRow icon={EI.tag} label="Tags" value="No tags" valueColor="var(--text-faint)"/>
          <div style={{marginTop:14, padding:'10px 12px', background:'rgba(255,200,87,.06)', border:'1px solid rgba(255,200,87,.25)', borderRadius:4, display:'flex', alignItems:'center', gap:10}}>
            <Icon d={EI.alert} size={14}/>
            <div>
              <div style={{fontSize:12, color:'var(--warn-bright)', fontWeight:600}}>Health below 50</div>
              <div style={{fontSize:11, color:'var(--text-muted)', marginTop:2}}>Recurring Defender exit codes likely contributing</div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Tasks */}
      <div className="ep-card" style={{marginTop:14}}>
        <div className="ep-card-head">
          <div className="ep-card-title"><Icon d={I.task} size={14}/> Recent Tasks</div>
          <a style={{fontFamily:'var(--font-mono)', fontSize:11, color:'var(--accent)'}}>View All →</a>
        </div>
        {a.recentTasks.map((t, i) => (
          <div key={i} className="ep-recent-row">
            <StatusPill status={t.status}/>
            <span className="ep-recent-name">{t.name}</span>
            <span className="ep-recent-when">{t.when}</span>
          </div>
        ))}
      </div>
    </>
  );
}

// ── Heartbeat tab ────────────────────────────────────────────────────
function HeartbeatTab({ a, chartStyle = 'line' }) {
  const [period, setPeriod] = useDetailState('7d');
  const [activeMetric, setActiveMetric] = useDetailState('cpu');

  const sparks = [
    { id:'cpu',     label:'CPU · Host',      val:'37%',     sub:'agent: 3.0%',   data:a.heartbeat.cpuHost,  color:'#00e68a', delta:'+12%', warn:false },
    { id:'mem',     label:'Memory · Host',   val:'10.7 GB', sub:'agent: 19 MB',  data:a.heartbeat.memHost,  color:'#7eaaff', delta:'-3%',  warn:false },
    { id:'disk',    label:'Disk Free',       val:'335 GB',  sub:'+1.2 GB · 7d',  data:a.heartbeat.diskFree, color:'#ffc857', delta:'+0.4%', warn:false },
    { id:'agent',   label:'Agent Memory',    val:'19 MB',   sub:'host: 10.7 GB', data:a.heartbeat.memAgent, color:'#a78bfa', delta:'+1%',  warn:false },
  ];

  const active = sparks.find(s => s.id === activeMetric);

  // Pick which series to show in the expanded chart
  const expandedSeries = activeMetric === 'cpu' ? [
    { data:a.heartbeat.cpuHost,  color:'#00e68a' },
    { data:a.heartbeat.cpuAgent, color:'#a78bfa', opacity:.7 },
  ] : activeMetric === 'mem' ? [
    { data:a.heartbeat.memHost,  color:'#7eaaff' },
  ] : activeMetric === 'disk' ? [
    { data:a.heartbeat.diskFree, color:'#ffc857' },
  ] : [
    { data:a.heartbeat.memAgent, color:'#a78bfa' },
  ];

  // Compute area path for area variant
  const renderArea = (data, color, w=720, h=200) => {
    const padL=36, padR=12, padT=12, padB=22, cw=w-padL-padR, ch=h-padT-padB;
    const max = Math.max(...data);
    const ys = data.map(v => padT+ch-(v/max)*ch);
    const xs = data.map((_,i) => padL+(i/(data.length-1))*cw);
    const line = ys.map((y,i)=>`${i===0?'M':'L'}${xs[i]},${y}`).join(' ');
    const fill = `${line} L${xs[xs.length-1]},${padT+ch} L${xs[0]},${padT+ch} Z`;
    return { line, fill, max };
  };

  return (
    <>
      <div style={{display:'flex', alignItems:'center', gap:14, marginBottom:14}}>
        <span style={{fontFamily:'var(--font-mono)', fontSize:10.5, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'.18em'}}>Period</span>
        <div className="ep-period">
          {['7d','14d','30d'].map(p => (
            <button key={p} className={p===period?'is-active':''} onClick={() => setPeriod(p)}>{p}</button>
          ))}
        </div>
        <span style={{fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-muted)'}}>778 data points</span>
        <div style={{flex:1}}/>
        <span style={{fontFamily:'var(--font-mono)', fontSize:10.5, color:'var(--text-muted)'}}>style:</span>
        <span style={{fontFamily:'var(--font-mono)', fontSize:10.5, color:'var(--accent)'}}>{chartStyle}</span>
      </div>

      <div className="ep-grid" style={{gridTemplateColumns:'repeat(4, 1fr)', marginBottom:14}}>
        {sparks.map(s => (
          <div key={s.id} className={`ep-spark-card ${activeMetric===s.id?'is-active':''}`} onClick={() => setActiveMetric(s.id)}>
            <div className="ep-spark-head">
              <span className="ep-spark-name">{s.label}</span>
              <span className={`ep-spark-delta ${s.warn?'is-warn':''}`}>{s.delta}</span>
            </div>
            <div className="ep-spark-val">{s.val}</div>
            <div className="ep-spark-sub">{s.sub}</div>
            <div style={{marginTop:8}}>
              <EpSpark data={s.data} color={s.color} w={200} h={28}/>
            </div>
          </div>
        ))}
      </div>

      {/* Expanded chart */}
      <div className="ep-card">
        <div className="ep-card-head">
          <div className="ep-card-title">
            <Icon d={I.chart} size={14}/> {active.label} — {period}
          </div>
          <div style={{display:'flex', gap:14, alignItems:'center'}}>
            {expandedSeries.length > 1 && (
              <div style={{display:'flex', gap:14}}>
                <span style={{display:'flex', alignItems:'center', gap:6, fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-muted)'}}>
                  <span style={{width:9, height:9, borderRadius:2, background:'#00e68a'}}/> Host
                </span>
                <span style={{display:'flex', alignItems:'center', gap:6, fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-muted)'}}>
                  <span style={{width:9, height:9, borderRadius:2, background:'#a78bfa'}}/> Agent
                </span>
              </div>
            )}
            <button className="ep-icon-btn"><Icon d={EI.expand} size={12}/></button>
          </div>
        </div>
        {chartStyle === 'area' ? (
          <svg viewBox="0 0 720 220" style={{width:'100%', height:220, display:'block'}}>
            {[0, .25, .5, .75, 1].map(t => (
              <line key={t} x1={36} y1={12+196*(1-t)} x2={708} y2={12+196*(1-t)} stroke="rgba(255,255,255,.04)" strokeDasharray="2 4"/>
            ))}
            {expandedSeries.map((s, i) => {
              const r = renderArea(s.data, s.color, 720, 220);
              return (
                <g key={i}>
                  <path d={r.fill} fill={s.color} opacity={.18}/>
                  <path d={r.line} fill="none" stroke={s.color} strokeWidth="1.4" opacity={s.opacity ?? 1}/>
                </g>
              );
            })}
          </svg>
        ) : (
          <EpLineChart series={expandedSeries} height={220}/>
        )}
        <div style={{display:'flex', justifyContent:'space-between', marginTop:6, fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-faint)'}}>
          <span>4/20</span><span>4/21</span><span>4/22</span><span>4/23</span><span>4/24</span><span>4/25</span><span>4/26</span>
        </div>
      </div>
    </>
  );
}

// ── Task History tab ─────────────────────────────────────────────────
function TaskHistoryTab({ a, onExec }) {
  const rows = [...a.recentTasks, ...a.recentTasks].map((t, i) => ({
    ...t, id:`t${i}`, exitCode: i % 5 === 4 ? 1 : 101, duration: `${30 + (i*7)%180}s`,
  }));
  return (
    <div className="ep-table-wrap">
      <table className="ep-table">
        <thead>
          <tr>
            <th style={{width:120}}>Status</th>
            <th>Task</th>
            <th style={{width:120}}>Started</th>
            <th style={{width:80}}>Duration</th>
            <th style={{width:80}}>Exit</th>
            <th className="col-actions">Actions</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id} onClick={() => onExec && onExec(r)} style={{cursor:'pointer'}}>
              <td><StatusPill status={r.status}/></td>
              <td style={{color:'var(--text-primary)'}}>{r.name}</td>
              <td className="col-mono" style={{color:'var(--text-muted)'}}>{r.when}</td>
              <td className="col-mono">{r.duration}</td>
              <td className="col-mono" style={{color: r.exitCode === 1 ? 'var(--danger)' : 'var(--text-primary)'}}>{r.exitCode}</td>
              <td className="col-actions">
                <button className="ep-icon-btn" onClick={e => e.stopPropagation()}><Icon d={EI.more} size={14}/></button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ── Event Log tab ────────────────────────────────────────────────────
function EventLogTab({ a }) {
  const [filter, setFilter] = useDetailState('All');
  const filters = ['All', 'Enrolled', 'Came Online', 'Went Offline', 'Task Completed', 'Task Failed', 'Version Updated', 'Key Rotated', 'Status Changed', 'Decommissioned'];

  const pillFor = (type) => {
    const map = {
      'task-completed': { cls:'is-completed', label:'Task Completed' },
      'task-failed':    { cls:'is-failed',    label:'Task Failed' },
      'came-online':    { cls:'is-online',    label:'Came Online' },
      'went-offline':   { cls:'is-offline',   label:'Went Offline' },
    };
    return map[type] || { cls:'', label:type };
  };

  return (
    <>
      <div className="ep-event-chips">
        {filters.map(f => (
          <button key={f} className={`ep-event-chip ${filter===f?'is-active':''}`} onClick={() => setFilter(f)}>{f}</button>
        ))}
      </div>
      <div>
        {a.events.map((e, i) => {
          const p = pillFor(e.type);
          return (
            <div key={i} className="ep-event-row">
              <span className={`ep-event-pill ${p.cls}`}>{p.label}</span>
              <span className="ep-event-detail">{e.detail}</span>
              <span className="ep-event-when">{e.when}</span>
            </div>
          );
        })}
      </div>
    </>
  );
}

// ── Detail page ──────────────────────────────────────────────────────
function EndpointsAgentDetail({ tab='overview', onBack, onExec, chartStyle='line' }) {
  const [active, setActive] = useDetailState(tab);
  const a = ED.detailAgent;

  return (
    <EpShell title="Endpoints · Agent Detail" activeKey="endpoints:agents" label={`03 Agent Detail · ${active}`}>
      <div className="ep-crumb">
        <a onClick={onBack}>← Agents</a>
        <span className="ep-crumb-sep">/</span>
        <span style={{color:'var(--text-primary)'}}>{a.hostname}</span>
      </div>

      <div style={{display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:16, gap:14}}>
        <div>
          <div style={{display:'flex', alignItems:'center', gap:10, flexWrap:'wrap'}}>
            <h1 style={{fontFamily:'var(--font-display)', fontSize:24, fontWeight:600, letterSpacing:'.04em', color:'var(--text-primary)'}}>{a.hostname}</h1>
            <span style={{display:'inline-flex', alignItems:'center', gap:5}}>
              <span className="ep-status-dot"/>
              <StatusPill status={a.status}/>
            </span>
            <OsPill os={a.os}/>
            <span style={{fontFamily:'var(--font-mono)', fontSize:12, color:'var(--text-muted)'}}>{a.arch} · v{a.version}</span>
          </div>
          <div style={{marginTop:6, fontFamily:'var(--font-mono)', fontSize:10.5, color:'var(--text-muted)'}}>
            ID: {a.id}
          </div>
        </div>
        <div style={{display:'flex', gap:8}}>
          <button className="ep-btn"><Icon d={I.play} size={12}/> Run Task</button>
          <button className="ep-btn"><Icon d={EI.refresh} size={12}/> Refresh Heartbeat</button>
          <button className="ep-btn danger"><Icon d={EI.trash} size={12}/> Decommission</button>
        </div>
      </div>

      <Tabs
        tabs={[
          { id:'overview',  label:'Overview' },
          { id:'tasks',     label:'Task History' },
          { id:'heartbeat', label:'Heartbeat' },
          { id:'events',    label:'Event Log' },
        ]}
        active={active}
        onChange={setActive}
      />

      {active === 'overview'  && <OverviewTab a={a}/>}
      {active === 'tasks'     && <TaskHistoryTab a={a} onExec={onExec}/>}
      {active === 'heartbeat' && <HeartbeatTab a={a} chartStyle={chartStyle}/>}
      {active === 'events'    && <EventLogTab a={a}/>}
    </EpShell>
  );
}

Object.assign(window, { EndpointsAgentDetail });
