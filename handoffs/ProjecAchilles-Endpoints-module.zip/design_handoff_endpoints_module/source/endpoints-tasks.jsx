/* global React, Icon, I, EI, EpShell, ED, OsPill, StatusPill */
const { useState: useTasksState } = React;

// ── Tasks page ───────────────────────────────────────────────────────
function EndpointsTasks({ onCreate, onExec }) {
  const [expanded, setExpanded] = useTasksState(new Set(['e1']));
  const [filter, setFilter] = useTasksState('All Status');

  const toggle = (id) => {
    const next = new Set(expanded);
    if (next.has(id)) next.delete(id); else next.add(id);
    setExpanded(next);
  };

  return (
    <EpShell title="Endpoints · Tasks" activeKey="endpoints:tasks" label="04 Endpoints — Tasks">
      <div className="ep-page-head">
        <div>
          <h1>Tasks</h1>
          <p>Create and monitor security test tasks · {ED.executions.length} bundles · {ED.scheduled.length} scheduled</p>
        </div>
        <button className="ep-btn primary" onClick={onCreate}>
          <Icon d={EI.plus} size={13}/> Create Task
        </button>
      </div>

      {/* Scheduled Tasks */}
      <div className="ep-section-title">
        <Icon d={I.clock} size={14}/>
        <span>Scheduled Tasks</span>
        <span className="ep-section-count">({ED.scheduled.length})</span>
      </div>
      {ED.scheduled.map((s, i) => (
        <div className="ep-sched-row" key={i}>
          <div className="ep-sched-info">
            <div className="ep-sched-name">
              <span>{s.name}</span>
              <StatusPill status={s.status}/>
              <span className="ep-pill" style={{color:'var(--text-muted)', borderColor:'var(--line)'}}>Weekly</span>
            </div>
            <div className="ep-sched-cadence">{s.cadence}</div>
            <div className="ep-sched-meta">
              <span>Next: {s.next}</span>
              <span>Last: {s.last}</span>
              <span>{s.agents} agents</span>
            </div>
          </div>
          <div className="ep-sched-actions">
            {s.status === 'paused'
              ? <button className="ep-icon-btn"><Icon d={I.play} size={13}/></button>
              : <button className="ep-icon-btn"><Icon d={EI.pause} size={13}/></button>
            }
            <button className="ep-icon-btn is-danger"><Icon d={EI.trash} size={13}/></button>
          </div>
        </div>
      ))}

      {/* Executions */}
      <div className="ep-section-title">
        <Icon d={I.play} size={14}/>
        <span>Executions</span>
        <span className="ep-section-count">({ED.executions.length})</span>
      </div>

      <div className="ep-filter-row" style={{marginBottom:0, borderBottomLeftRadius:0, borderBottomRightRadius:0}}>
        <select className="ep-filter-select" value={filter} onChange={e => setFilter(e.target.value)}>
          <option>All Status</option><option>Completed</option><option>Failed</option><option>Pending</option>
        </select>
        <div className="ep-filter-input" style={{maxWidth:280}}>
          <Icon d={I.search} size={13}/>
          <input placeholder="Search tasks…" style={{flex:1, background:'transparent', border:'none', outline:'none', color:'var(--text-primary)', fontSize:12.5}}/>
        </div>
        <div style={{flex:1}}/>
        <button className="ep-btn"><Icon d={EI.refresh} size={12}/> Refresh</button>
      </div>

      <div className="ep-table-wrap" style={{borderTopLeftRadius:0, borderTopRightRadius:0, borderTop:'none'}}>
        <table className="ep-table">
          <thead>
            <tr>
              <th style={{width:32}}><span className="ep-checkbox"/></th>
              <th style={{width:32}}></th>
              <th style={{width:180}}>Status</th>
              <th>Task</th>
              <th style={{width:100}}>Agent</th>
              <th style={{width:80}}>Created</th>
              <th style={{width:80}}>Duration</th>
              <th style={{width:80}}>Exit</th>
              <th style={{width:60}}>Notes</th>
              <th className="col-actions">Actions</th>
            </tr>
          </thead>
          <tbody>
            {ED.executions.map(e => (
              <React.Fragment key={e.id}>
                <tr>
                  <td><span className="ep-checkbox"/></td>
                  <td>
                    <span className={`ep-expander ${expanded.has(e.id)?'is-open':''}`} onClick={() => toggle(e.id)}>
                      <Icon d={EI.chev} size={12}/>
                    </span>
                  </td>
                  <td>
                    <div className="ep-counts">
                      {e.counts.completed && <span className="ep-count is-completed">completed ×{e.counts.completed}</span>}
                      {e.counts.failed    && <span className="ep-count is-failed">failed ×{e.counts.failed}</span>}
                      {e.counts.pending   && <span className="ep-count is-pending">pending</span>}
                      {e.counts.assigned  && <span className="ep-count is-assigned">assigned</span>}
                    </div>
                  </td>
                  <td style={{color:'var(--text-primary)'}}>{e.task}</td>
                  <td className="col-mono" style={{color:'var(--signal)'}}>{e.agents} agents</td>
                  <td className="col-mono" style={{color:'var(--text-muted)'}}>{e.created}</td>
                  <td className="col-mono" style={{color:'var(--text-faint)'}}>—</td>
                  <td className="col-mono" style={{color:'var(--text-faint)'}}>—</td>
                  <td className="col-mono" style={{color:'var(--text-faint)'}}>—</td>
                  <td className="col-actions">
                    <button className="ep-icon-btn"><Icon d={EI.close} size={12}/></button>
                    <button className="ep-icon-btn is-danger" style={{marginLeft:4}}><Icon d={EI.trash} size={12}/></button>
                  </td>
                </tr>
                {expanded.has(e.id) && (
                  <tr><td colSpan="10" style={{padding:0, background:'rgba(0,0,0,.18)'}}>
                    <div style={{padding:'8px 18px 14px 64px'}}>
                      <table style={{width:'100%', borderCollapse:'collapse'}}>
                        <thead>
                          <tr style={{borderBottom:'1px solid var(--line)'}}>
                            <th style={{padding:'8px 10px', textAlign:'left', fontFamily:'var(--font-mono)', fontSize:9.5, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'.18em', width:32}}><span className="ep-checkbox"/></th>
                            <th style={{padding:'8px 10px', textAlign:'left', fontFamily:'var(--font-mono)', fontSize:9.5, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'.18em'}}>Agent</th>
                            <th style={{padding:'8px 10px', textAlign:'left', fontFamily:'var(--font-mono)', fontSize:9.5, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'.18em', width:140}}>Status</th>
                            <th style={{padding:'8px 10px', textAlign:'left', fontFamily:'var(--font-mono)', fontSize:9.5, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'.18em', width:100}}>Duration</th>
                            <th style={{padding:'8px 10px', textAlign:'left', fontFamily:'var(--font-mono)', fontSize:9.5, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'.18em', width:80}}>Exit</th>
                            <th style={{padding:'8px 10px', textAlign:'left', fontFamily:'var(--font-mono)', fontSize:9.5, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'.18em', width:60}}>Notes</th>
                            <th style={{padding:'8px 10px', textAlign:'right', fontFamily:'var(--font-mono)', fontSize:9.5, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'.18em', width:90}}>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {ED.childRows(e.task).slice(0, 8).map((c, i) => (
                            <tr key={i} style={{borderBottom:'1px solid var(--line-soft)', cursor:'pointer'}} onClick={() => onExec && onExec({ ...c, taskName: e.task })}>
                              <td style={{padding:'10px'}}><span className="ep-checkbox"/></td>
                              <td style={{padding:'10px', fontFamily:'var(--font-mono)', color:'var(--text-primary)', fontSize:12}}>{c.agent}</td>
                              <td style={{padding:'10px'}}><StatusPill status={c.status}/></td>
                              <td style={{padding:'10px', fontFamily:'var(--font-mono)', fontSize:11.5, color:'var(--text-secondary)'}}>{c.duration}ms</td>
                              <td style={{padding:'10px'}}>
                                <span style={{display:'inline-block', padding:'1px 7px', fontFamily:'var(--font-mono)', fontSize:10, borderRadius:3, background: c.exitCode === 1 ? 'rgba(255,59,92,.10)' : 'rgba(255,200,87,.08)', color: c.exitCode === 1 ? 'var(--danger)' : 'var(--warn-bright)', border: `1px solid ${c.exitCode === 1 ? 'rgba(255,59,92,.3)' : 'rgba(255,200,87,.3)'}`}}>{c.exitCode}</span>
                              </td>
                              <td style={{padding:'10px'}}><Icon d={I.cmd} size={11}/></td>
                              <td style={{padding:'10px', textAlign:'right'}}>
                                <button className="ep-icon-btn is-danger" onClick={ev => ev.stopPropagation()}><Icon d={EI.trash} size={11}/></button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </td></tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </EpShell>
  );
}

// ── Create Task Modal ────────────────────────────────────────────────
function CreateTaskModal({ onClose }) {
  const [mode, setMode] = useTasksState('test');
  const [run, setRun] = useTasksState('now');
  const [selected, setSelected] = useTasksState(new Set());

  return (
    <EpShell title="Endpoints · Tasks" activeKey="endpoints:tasks" label="05 Modal · Create Task">
      <div style={{filter:'blur(1px) brightness(.7)', pointerEvents:'none', height:'100%'}}>
        <EndpointsTasks onCreate={()=>{}}/>
      </div>
      <div className="ep-modal-shell">
        <div className="ep-modal">
          <div className="ep-modal-head">
            <div>
              <div className="ep-modal-title">Create Task</div>
              <div className="ep-modal-sub">Execute a task on selected agents</div>
            </div>
            <button className="ep-icon-btn" onClick={onClose}><Icon d={EI.close} size={14}/></button>
          </div>
          <div className="ep-modal-body">
            <div className="ep-field">
              <label className="ep-field-label">Target Agents ({selected.size} selected)</label>
              <div style={{display:'flex', gap:8}}>
                <div className="ep-filter-input" style={{flex:1}}>
                  <Icon d={I.search} size={13}/>
                  <input placeholder="Search hostname…" style={{flex:1, background:'transparent', border:'none', outline:'none', color:'var(--text-primary)', fontSize:12.5}}/>
                </div>
                <div style={{display:'flex', alignItems:'center', gap:6}}>
                  <span className="ep-toggle is-on"/>
                  <span style={{fontSize:11.5, color:'var(--text-muted)'}}>Online</span>
                </div>
              </div>
              <div style={{display:'flex', gap:6, marginTop:8, flexWrap:'wrap'}}>
                <span className="ep-tag">happycat</span>
                <span className="ep-tag" style={{color:'var(--warn-bright)', borderColor:'rgba(255,200,87,.3)', background:'rgba(255,200,87,.10)'}}>to-remove</span>
              </div>
              <div style={{marginTop:8, fontFamily:'var(--font-mono)', fontSize:10.5, color:'var(--text-muted)'}}>Select all (31) · Deselect all</div>
              <div style={{marginTop:8, maxHeight:160, overflow:'auto', border:'1px solid var(--line)', borderRadius:4, background:'rgba(0,0,0,.2)'}}>
                {ED.hosts.slice(0, 7).map(h => (
                  <label key={h.id} style={{display:'flex', alignItems:'center', gap:10, padding:'8px 12px', borderBottom:'1px solid var(--line-soft)', cursor:'pointer', fontSize:12, color:'var(--text-primary)'}}>
                    <span className="ep-checkbox"/>
                    <span className="ep-status-dot"/>
                    <span style={{fontFamily:'var(--font-mono)'}}>{h.hostname}</span>
                    <span style={{fontFamily:'var(--font-mono)', fontSize:10.5, color:'var(--text-muted)'}}>({h.os}/{h.arch})</span>
                    {h.tags.map(t => <span key={t} className="ep-tag" style={{marginLeft:'auto'}}>{t}</span>)}
                  </label>
                ))}
              </div>
            </div>

            <div className="ep-field">
              <label className="ep-field-label">Task Type</label>
              <div className="ep-seg">
                <button className={mode==='test'?'is-active':''} onClick={() => setMode('test')}><Icon d={I.play} size={11}/> Security Test</button>
                <button className={mode==='cmd' ?'is-active':''} onClick={() => setMode('cmd')}><Icon d={I.cmd} size={11}/> Command</button>
              </div>
            </div>

            <div className="ep-field">
              <label className="ep-field-label">{mode === 'test' ? 'Security Test' : 'Command'}</label>
              <div className="ep-filter-input">
                <Icon d={I.search} size={13}/>
                <input placeholder={mode==='test'?'Search tests…':'Enter command…'} style={{flex:1, background:'transparent', border:'none', outline:'none', color:'var(--text-primary)', fontSize:12.5}}/>
              </div>
            </div>

            <div className="ep-field">
              <label className="ep-field-label">Run Mode</label>
              <div className="ep-seg">
                <button className={run==='now'?'is-active':''} onClick={() => setRun('now')}><Icon d={I.play} size={11}/> Run Now</button>
                <button className={run==='schedule'?'is-active':''} onClick={() => setRun('schedule')}><Icon d={I.clock} size={11}/> Schedule</button>
              </div>
            </div>

            <div className="ep-grid" style={{gridTemplateColumns:'1fr 1fr 1fr', gap:10}}>
              <div className="ep-field" style={{margin:0}}>
                <label className="ep-field-label">Timeout (sec)</label>
                <input className="ep-field-input" defaultValue="300"/>
              </div>
              <div className="ep-field" style={{margin:0}}>
                <label className="ep-field-label">Priority</label>
                <select className="ep-field-input"><option>Normal (1)</option><option>High (2)</option><option>Low (0)</option></select>
              </div>
              <div className="ep-field" style={{margin:0}}>
                <label className="ep-field-label">Target Index</label>
                <select className="ep-field-input"><option>achilles-results</option></select>
              </div>
            </div>
          </div>
          <div className="ep-modal-foot">
            <button className="ep-btn" onClick={onClose}>Cancel</button>
            <button className="ep-btn primary">Create {selected.size} Task(s)</button>
          </div>
        </div>
      </div>
    </EpShell>
  );
}

// ── Enroll Agent Modal ───────────────────────────────────────────────
function EnrollAgentModal({ onClose }) {
  const [ttl, setTtl] = useTasksState('24');
  const [maxUses, setMaxUses] = useTasksState('1');
  const token = 'acht_1420d10ed34bd0c5cddc189426e6f067481e8cdb89129fb39b3f2049041f807a';
  const [open, setOpen] = useTasksState('windows');

  const oses = [
    { id:'windows', label:'Windows (PowerShell)',    cmd:'Invoke-WebRequest -Uri "https://rga.agent.projectachilles.io/api/agent/download?os=windows&arch=amd64" -Headers @{"ngrok-skip-browser-warning"="true"} -OutFile achilles-agent.exe; .\\achilles-agent.exe install -t '+token },
    { id:'linux64', label:'Linux (amd64)',           cmd:'curl -fSL -H "ngrok-skip-browser-warning: true" "https://rga.agent.projectachilles.io/api/agent/download?os=linux&arch=amd64" -o achilles-agent && chmod +x achilles-agent && sudo ./achilles-agent install -t '+token },
    { id:'linuxarm', label:'Linux (arm64)',          cmd:'curl -fSL -H "ngrok-skip-browser-warning: true" "https://rga.agent.projectachilles.io/api/agent/download?os=linux&arch=arm64" -o achilles-agent && chmod +x achilles-agent && sudo ./achilles-agent install -t '+token },
    { id:'macarm',  label:'macOS (Apple Silicon)',   cmd:'curl -fSL -H "ngrok-skip-browser-warning: true" "https://rga.agent.projectachilles.io/api/agent/download?os=darwin&arch=arm64" -o achilles-agent && chmod +x achilles-agent && sudo ./achilles-agent install -t '+token },
    { id:'macintel', label:'macOS (Intel)',          cmd:'curl -fSL -H "ngrok-skip-browser-warning: true" "https://rga.agent.projectachilles.io/api/agent/download?os=darwin&arch=amd64" -o achilles-agent && chmod +x achilles-agent && sudo ./achilles-agent install -t '+token },
  ];

  return (
    <EpShell title="Endpoints · Agents" activeKey="endpoints:agents" label="06 Modal · Enroll Agent">
      <div style={{filter:'blur(1px) brightness(.7)', pointerEvents:'none', height:'100%'}}>
        <EndpointsAgents/>
      </div>
      <div className="ep-modal-shell">
        <div className="ep-modal is-wide">
          <div className="ep-modal-head">
            <div>
              <div className="ep-modal-title" style={{display:'flex', alignItems:'center', gap:8}}>
                <Icon d={I.shield} size={16} cls=""/> Enroll Agent
              </div>
              <div className="ep-modal-sub">Generate a one-time token, then run the install command on the target host</div>
            </div>
            <button className="ep-icon-btn" onClick={onClose}><Icon d={EI.close} size={14}/></button>
          </div>
          <div className="ep-modal-body">
            <div className="ep-grid" style={{gridTemplateColumns:'1fr 1fr', gap:12}}>
              <div className="ep-field" style={{margin:0}}>
                <label className="ep-field-label">TTL (hours)</label>
                <input className="ep-field-input" value={ttl} onChange={e => setTtl(e.target.value)}/>
              </div>
              <div className="ep-field" style={{margin:0}}>
                <label className="ep-field-label">Max Uses</label>
                <input className="ep-field-input" value={maxUses} onChange={e => setMaxUses(e.target.value)}/>
              </div>
            </div>

            <div style={{marginTop:14}}>
              <div className="ep-field-label" style={{marginBottom:6}}>Token Generated</div>
              <div className="ep-token">
                <span style={{flex:1, overflow:'hidden', textOverflow:'ellipsis'}}>{token}</span>
                <button className="ep-icon-btn"><Icon d={EI.copy} size={12}/></button>
              </div>
            </div>

            <div style={{marginTop:18}}>
              <div className="ep-field-label" style={{marginBottom:8}}>Install Commands</div>
              {oses.map(os => (
                <div className="ep-os-block" key={os.id}>
                  <div className="ep-os-block-head" onClick={() => setOpen(open===os.id?null:os.id)} style={{cursor:'pointer'}}>
                    <Icon d={I.cmd} size={12}/>
                    <span>{os.label}</span>
                    <Icon d={EI.chev} size={11} cls=""/>
                  </div>
                  {open === os.id && (
                    <div className="ep-os-block-body">
                      <code>{os.cmd}</code>
                      <button className="ep-icon-btn"><Icon d={EI.copy} size={11}/></button>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div style={{marginTop:18, padding:'10px 14px', background:'rgba(79,142,255,.06)', border:'1px solid rgba(79,142,255,.2)', borderRadius:6, fontSize:11.5, color:'var(--text-secondary)', display:'flex', gap:10}}>
              <Icon d={I.shield} size={14} cls=""/>
              <span>Token expires in {ttl}h · single-use · agent fingerprint pinned at first heartbeat. Active tokens appear in the table below after generation.</span>
            </div>
          </div>
          <div className="ep-modal-foot">
            <button className="ep-btn" onClick={onClose}>Close</button>
            <button className="ep-btn primary"><Icon d={EI.refresh} size={12}/> Generate New Token</button>
          </div>
        </div>
      </div>
    </EpShell>
  );
}

// ── Execution Detail Modal ───────────────────────────────────────────
function ExecutionDetailModal({ onClose, pattern='modal' }) {
  const [tab, setTab] = useTasksState('output');
  const c = ED.childRows('Cyber-Hygiene Bundle')[0];
  const taskName = 'Cyber-Hygiene Bundle (Windows Defender Edition)';

  const detail = (
    <>
      <div className="ep-exec-meta-grid">
        <div className="ep-exec-meta-cell">
          <span className="lbl">Agent</span>
          <span className="val">{c.agent}</span>
        </div>
        <div className="ep-exec-meta-cell">
          <span className="lbl">Status</span>
          <span className="val"><StatusPill status={c.status}/></span>
        </div>
        <div className="ep-exec-meta-cell">
          <span className="lbl">Duration</span>
          <span className="val">{c.duration}ms</span>
        </div>
        <div className="ep-exec-meta-cell">
          <span className="lbl">Exit Code</span>
          <span className="val" style={{color:'var(--warn-bright)'}}>{c.exitCode}</span>
        </div>
        <div className="ep-exec-meta-cell">
          <span className="lbl">Started</span>
          <span className="val">{c.started}</span>
        </div>
        <div className="ep-exec-meta-cell">
          <span className="lbl">Completed</span>
          <span className="val">{c.completed}</span>
        </div>
        <div className="ep-exec-meta-cell" style={{gridColumn:'span 2'}}>
          <span className="lbl">Agent ID</span>
          <span className="val">b37576e1-5bd0-46e7-806f-ad50644547f4</span>
        </div>
      </div>

      <div className="ep-exec-tabs">
        {[
          { id:'output',  label:'stdout' },
          { id:'stderr',  label:'stderr' },
          { id:'meta',    label:'Metadata' },
          { id:'raw',     label:'Raw JSON' },
        ].map(t => (
          <button key={t.id} className={`ep-exec-tab ${tab===t.id?'is-active':''}`} onClick={() => setTab(t.id)}>{t.label}</button>
        ))}
        <div style={{flex:1}}/>
        <button className="ep-icon-btn" style={{margin:'4px 0'}}><Icon d={EI.copy} size={12}/></button>
      </div>

      {tab === 'output' && <pre className="ep-exec-stdout">{c.stdout}</pre>}
      {tab === 'stderr' && <pre className="ep-exec-stdout" style={{color:'var(--text-muted)'}}>{c.stderr}</pre>}
      {tab === 'meta' && (
        <div className="ep-exec-stdout">
{`task_uuid:    a3c923ae-1a46-4b1f-b696-be9c2731a628
task_name:    ${taskName}
priority:     normal
timeout_sec:  300
target_index: achilles-results
attempt:      1 of 1
parent_run:   r-2026-04-23-08-00
exit_code:    ${c.exitCode}  (defender-protected, not a failure)`}
        </div>
      )}
      {tab === 'raw' && (
        <pre className="ep-exec-stdout" style={{color:'var(--violet)'}}>{`{
  "task_id": "a3c923ae-1a46-4b1f-b696-be9c2731a628",
  "agent": "${c.agent}",
  "exit_code": ${c.exitCode},
  "duration_ms": ${c.duration},
  "stdout_lines": 14,
  "stderr_lines": 0,
  "started_at": "${c.started}",
  "completed_at": "${c.completed}"
}`}</pre>
      )}
    </>
  );

  // Switch UI based on pattern (tweakable)
  if (pattern === 'drawer') {
    return (
      <EpShell title="Endpoints · Tasks" activeKey="endpoints:tasks" label="07 Modal · Execution Detail">
        <div style={{filter:'blur(1px) brightness(.7)', pointerEvents:'none', height:'100%'}}>
          <EndpointsTasks/>
        </div>
        <div style={{position:'absolute', inset:0, background:'rgba(2,4,10,.5)', backdropFilter:'blur(4px)', zIndex:50}}>
          <div style={{position:'absolute', top:0, right:0, bottom:0, width:560, background:'#0a0e1a', borderLeft:'1px solid var(--line-strong)', display:'flex', flexDirection:'column', boxShadow:'-20px 0 60px rgba(0,0,0,.6)'}}>
            <div className="ep-modal-head">
              <div>
                <div className="ep-modal-title">Execution · {c.agent}</div>
                <div className="ep-modal-sub">{taskName}</div>
              </div>
              <button className="ep-icon-btn" onClick={onClose}><Icon d={EI.close} size={14}/></button>
            </div>
            <div className="ep-modal-body">{detail}</div>
          </div>
        </div>
      </EpShell>
    );
  }

  return (
    <EpShell title="Endpoints · Tasks" activeKey="endpoints:tasks" label="07 Modal · Execution Detail">
      <div style={{filter:'blur(1px) brightness(.7)', pointerEvents:'none', height:'100%'}}>
        <EndpointsTasks/>
      </div>
      <div className="ep-modal-shell">
        <div className="ep-modal is-wide">
          <div className="ep-modal-head">
            <div>
              <div className="ep-modal-title">Execution Detail · {c.agent}</div>
              <div className="ep-modal-sub">{taskName}</div>
            </div>
            <div style={{display:'flex', gap:8}}>
              <button className="ep-btn"><Icon d={EI.expand} size={12}/> Open in agent</button>
              <button className="ep-icon-btn" onClick={onClose}><Icon d={EI.close} size={14}/></button>
            </div>
          </div>
          <div className="ep-modal-body">{detail}</div>
        </div>
      </div>
    </EpShell>
  );
}

Object.assign(window, { EndpointsTasks, CreateTaskModal, EnrollAgentModal, ExecutionDetailModal });
