// ── Endpoints module mock data ────────────────────────────────────────
// Sourced from screenshots: rga.projectachilles.io/endpoints/*

window.ENDPOINTS_DATA = (function() {
  const hosts = [
    { hostname: 'LAP-MZ03EPS6',   id:'a01', os:'windows', arch:'amd64', version:'0.5.4', stale:false, status:'active', lastSeen:'10s ago',  health:84, tags:[] },
    { hostname: 'CPC-Samy-FETC09', id:'a02', os:'windows', arch:'amd64', version:'0.5.4', stale:true,  status:'active', lastSeen:'12s ago',  health:99, tags:[] },
    { hostname: 'LAP-PF2BP11F',   id:'a03', os:'windows', arch:'amd64', version:'0.5.4', stale:true,  status:'active', lastSeen:'13s ago',  health:62, tags:[] },
    { hostname: 'CPC-Cesar-5K4JE', id:'a04', os:'windows', arch:'amd64', version:'0.5.4', stale:false, status:'active', lastSeen:'13s ago',  health:99, tags:[] },
    { hostname: 'CPC-Sarah-IQ7G1', id:'a05', os:'windows', arch:'amd64', version:'0.5.4', stale:true,  status:'active', lastSeen:'14s ago',  health:99, tags:[] },
    { hostname: 'RG-PF12U5Q9',    id:'a06', os:'windows', arch:'amd64', version:'0.5.4', stale:false, status:'active', lastSeen:'16s ago',  health:96, tags:[] },
    { hostname: 'LAP-PF59YL2J',   id:'a07', os:'windows', arch:'amd64', version:'0.5.4', stale:true,  status:'active', lastSeen:'20s ago',  health:99, tags:[] },
    { hostname: 'LAP-PF3N2LXF',   id:'a08', os:'windows', arch:'amd64', version:'0.5.4', stale:false, status:'active', lastSeen:'52s ago',  health:27, tags:['happycat'] },
    { hostname: 'LAP-PF62CFTV',   id:'0897f05d-84c6-4275-8db7-a6d3da236dc3', os:'windows', arch:'amd64', version:'0.5.4', stale:false, status:'active', lastSeen:'1m ago', health:46, tags:[] },
    { hostname: 'CPC-Ray-GB1R2YK', id:'a10', os:'windows', arch:'amd64', version:'0.5.4', stale:true,  status:'active', lastSeen:'25m ago', health:49, tags:[] },
    { hostname: 'LAP-PF55YGBW',   id:'a11', os:'windows', arch:'amd64', version:'0.5.4', stale:false, status:'active', lastSeen:'2m ago',   health:71, tags:[] },
    { hostname: 'LAP-PF1A47F0',   id:'a12', os:'windows', arch:'amd64', version:'0.5.4', stale:false, status:'active', lastSeen:'3m ago',   health:88, tags:[] },
    { hostname: 'LAP-PF4NE6S4',   id:'a13', os:'windows', arch:'amd64', version:'0.5.4', stale:false, status:'active', lastSeen:'4m ago',   health:91, tags:[] },
  ];

  const scheduled = [
    { name:'TA453 NICECURL VBScript Backdoor Detection', status:'paused', cadence:'Weekly Thu, random time (office hours) America/Santo_Domingo', next:'17d ago', last:'24d ago', agents:9 },
    { name:'UNK_RobotDreams Rust Backdoor Execution Chain', status:'paused', cadence:'Weekly Thu, random time (office hours) America/Santo_Domingo', next:'17d ago', last:'24d ago', agents:9 },
    { name:'Identity Endpoint Posture Bundle', status:'active', cadence:'Weekly Mon, Wed, random time (office hours) Europe/London', next:'in 21h', last:'4d ago', agents:9 },
    { name:'Cyber-Hygiene Bundle (Windows Defender Edition)', status:'active', cadence:'Weekly Tue, Thu, random time (office hours) Europe/London', next:'in 2d', last:'3d ago', agents:9 },
    { name:'CIS Windows Endpoint Level 1 Hardening Bundle', status:'active', cadence:'Weekly Mon, Wed, random time (office hours) Europe/London', next:'in 20h', last:'4d ago', agents:9 },
  ];

  const executions = [
    { id:'e1', task:'Cyber-Hygiene Bundle (Windows Defender Edition)', counts:{completed:8, failed:1, pending:1}, agents:10, created:'2d ago' },
    { id:'e2', task:'Identity Endpoint Posture Bundle', counts:{completed:7, failed:4, assigned:1}, agents:12, created:'3d ago' },
    { id:'e3', task:'CIS Windows Endpoint Level 1 Hardening Bundle', counts:{completed:7, failed:2}, agents:9, created:'3d ago' },
    { id:'e4', task:'Cyber-Hygiene Bundle (Windows Defender Edition)', counts:{completed:8, failed:3}, agents:11, created:'4d ago' },
    { id:'e5', task:'Identity Endpoint Posture Bundle', counts:{completed:8, failed:2}, agents:10, created:'5d ago' },
    { id:'e6', task:'CIS Windows Endpoint Level 1 Hardening Bundle', counts:{completed:9, failed:1}, agents:10, created:'5d ago' },
  ];

  // Per-execution child rows (10 agents per task)
  const childRows = (parentTask) => hosts.slice(0,10).map((h, i) => ({
    agent:h.hostname,
    status:i === 4 ? 'failed' : 'completed',
    duration: 60000 + Math.floor(Math.random()*120000),
    exitCode: i === 4 ? 1 : 101,
    stdout: `FORTIKA Cyber-Hygiene Bundle - Windows Defender Edition v2\nMulti-Binary Architecture (quarantine-resilient)\n\nTest UUID: a3c923ae-1a46-4b1f-b696-be9c2731a628\nVersion:   2.0.0\nTime:      2026-04-24 00:00:28 UTC\n\n[MODULE 1] Defender Status Probe ............. PASS\n[MODULE 2] AMSI Bypass Check  ................ PASS\n[MODULE 3] Tamper Protection Active .......... PASS\n[MODULE 4] Real-time Monitoring On ........... PASS\n[MODULE 5] Cloud Submission Enabled .......... PASS\n[MODULE 6] Network Inspection ................ PASS\n[MODULE 7] Controlled Folder Access .......... PASS\n[MODULE 8] Attack Surface Reduction Rules .... PASS (12/15)\nExit code: 101 — protected, defender intact`,
    stderr:'(empty)',
    started:'4/23/2026, 8:00:26 PM',
    completed:'4/23/2026, 8:01:42 PM',
  }));

  // Dashboard KPIs
  const dashKpis = {
    totalAgents: 31,
    online: 9,
    offline: 22,
    pendingTasks: 1,
    fleetUptime: 4.2,        // %
    taskSuccess: 77.8,        // % over 7d
    mtbf: 12.6,               // hours
    staleAgents: 22,
    avgHealth: 55,
  };

  // 24h task activity
  const activity24h = { completed:0, failed:0, inProgress:1, successRate:0 };

  // Recent tasks shown on dashboard
  const recentTasks = [
    { status:'completed', task:'Cyber-Hygiene Bundle (Windows Defender Edition)', agent:'LAP-PF55YGBW', duration:'2m 12s', exitCode:101, created:'1d ago' },
    { status:'completed', task:'Cyber-Hygiene Bundle (Windows Defender Edition)', agent:'LAP-PF62CFTV', duration:'1m 32s', exitCode:101, created:'2d ago' },
    { status:'pending',   task:'Cyber-Hygiene Bundle (Windows Defender Edition)', agent:'LAP-PF55YAXT', duration:'—', exitCode:'—', created:'2d ago' },
    { status:'completed', task:'Identity Endpoint Posture Bundle', agent:'LAP-PF1A47F0', duration:'48s', exitCode:0, created:'2d ago' },
    { status:'completed', task:'CIS Windows Endpoint Level 1 Hardening Bundle', agent:'CPC-Cesar-5K4JE', duration:'3m 04s', exitCode:0, created:'3d ago' },
    { status:'failed',    task:'TA453 NICECURL VBScript Backdoor Detection', agent:'LAP-PF3N2LXF', duration:'12s', exitCode:1, created:'3d ago' },
  ];

  // Agent detail (focus on LAP-PF62CFTV)
  const detailAgent = {
    hostname:'LAP-PF62CFTV',
    id:'0897f05d-84c6-4275-8db7-a6d3da236dc3',
    status:'active', os:'windows', arch:'amd64', version:'0.5.4',
    enrolled:'3/30/2026, 6:44:13 AM',
    lastHeartbeat:'4/26/2026, 9:55:22 AM',
    cpu:'3.0%', memory:'10,978 MB', diskFree:'335.0 GB', uptime:'21h 59m',
    health:46,
    recentTasks: [
      { status:'completed', name:'Cyber-Hygiene Bundle (Windows Defender Edition)', when:'4/23/2026, 8:00:09 PM' },
      { status:'completed', name:'Identity Endpoint Posture Bundle', when:'4/22/2026, 8:00:41 PM' },
      { status:'completed', name:'CIS Windows Endpoint Level 1 Hardening Bundle', when:'4/22/2026, 8:00:41 PM' },
      { status:'completed', name:'Cyber-Hygiene Bundle (Windows Defender Edition)', when:'4/21/2026, 8:00:21 PM' },
      { status:'completed', name:'Identity Endpoint Posture Bundle', when:'4/20/2026, 8:00:05 PM' },
    ],
    // Heartbeat sparkline data (~778 data points → simplified to 60)
    heartbeat: {
      cpuHost: Array.from({length:60}, (_,i) => 6 + 4*Math.sin(i/3) + Math.random()*30 + (i%14===0?40:0)),
      cpuAgent: Array.from({length:60}, (_,i) => 1.5 + Math.random()*3 + (i%17===0?5:0)),
      memHost: Array.from({length:60}, () => 11000 + Math.random()*2500),
      memAgent: Array.from({length:60}, () => 18 + Math.random()*4),
      diskFree: Array.from({length:60}, () => 333 + Math.random()*4),
    },
    events: [
      { type:'task-completed', label:'Task Completed', detail:'Task: a1314d2f-cb99-4374-b9e2-c7b6acdbe8c', when:'4/23/2026, 8:02:38 PM' },
      { type:'came-online',    label:'Came Online', detail:'Machine Reboot · Offline for 4m · 2 failed heartbeats', when:'4/23/2026, 3:25:38 PM' },
      { type:'went-offline',   label:'Went Offline', detail:'CPU: 37% · Mem: 32% · Disk: 331 GB free', when:'4/23/2026, 3:25:04 PM' },
      { type:'came-online',    label:'Came Online', detail:'Machine Reboot · Offline for 3m · 2 failed heartbeats', when:'4/23/2026, 3:21:45 PM' },
      { type:'came-online',    label:'Came Online', detail:'Network Adapter Disabled · Offline for 2m · 2 failed heartbeats', when:'4/23/2026, 11:15:08 AM' },
      { type:'went-offline',   label:'Went Offline', detail:'CPU: 6% · Mem: 88% · Disk: 321 GB free', when:'4/23/2026, 11:14:54 AM' },
      { type:'task-completed', label:'Task Completed', detail:'Task: 62aebf29-c7f1-4dd4-8f08-adee603cf3fb', when:'4/23/2026, 9:48:08 AM' },
      { type:'task-completed', label:'Task Completed', detail:'Task: 48fed0f5-70d3-4854-9bc7-81779cb12869', when:'4/23/2026, 9:46:19 AM' },
      { type:'came-online',    label:'Came Online', detail:'Network Recovery · Offline for 17h 15m · 2 failed heartbeats', when:'4/23/2026, 9:44:05 AM' },
      { type:'went-offline',   label:'Went Offline', detail:'CPU: 6% · Mem: 88% · Disk: 320 GB free', when:'4/22/2026, 4:32:34 PM' },
      { type:'came-online',    label:'Came Online', detail:'Network Recovery · Offline for 13h 30m · 2 failed heartbeats', when:'4/22/2026, 9:54:55 AM' },
      { type:'went-offline',   label:'Went Offline', detail:'CPU: 98% · Mem: 86% · Disk: 322 GB free', when:'4/21/2026, 10:42:25 PM' },
    ],
  };

  return {
    branch:'main', commit:'4239c59', syncedAgo:'11h ago',
    hosts, scheduled, executions, childRows, dashKpis, activity24h,
    recentTasks, detailAgent,
    osDistribution: [{ os:'Windows', pct:100, count:31 }],
    statusDistribution: [{ status:'Active', pct:70, count:31, color:'#00e68a' }, { status:'Decommissioned', pct:30, count:13, color:'#ff3b5c' }],
    versionDistribution: [{ version:'0.5.4', pct:100, count:31, color:'#a78bfa' }],
  };
})();
