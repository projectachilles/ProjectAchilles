/* global React, Icon, I, EI, EpShell, ED, OsPill, HealthBadge */
const { useState: useAgentsState } = React;

function EndpointsAgents({ onEnroll, onPick }) {
  const [filter, setFilter] = useAgentsState('');
  const [onlineOnly, setOnlineOnly] = useAgentsState(false);
  const hosts = ED.hosts;

  return (
    <EpShell title="Endpoints · Agents" activeKey="endpoints:agents" label="02 Endpoints — Agents">
      <div className="ep-page-head">
        <div>
          <h1>Agents</h1>
          <p>Manage and monitor your Achilles agents · {hosts.length} enrolled</p>
        </div>
        <button className="ep-btn primary" onClick={onEnroll}>
          <Icon d={EI.plus} size={13}/> Enroll Agent
        </button>
      </div>

      {/* Collapsed expandables */}
      <div className="ep-grid" style={{gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:14}}>
        <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 16px', background:'var(--bg-card)', border:'1px solid var(--line)', borderRadius:6}}>
          <div style={{display:'flex', alignItems:'center', gap:10}}>
            <Icon d={EI.cpu} size={14}/>
            <span style={{fontSize:12.5, fontWeight:500, color:'var(--text-primary)'}}>Available Binaries</span>
            <span className="ep-pill" style={{color:'var(--text-muted)', borderColor:'var(--line)'}}>5 platforms</span>
          </div>
          <Icon d={EI.chev} size={14} cls="" />
        </div>
        <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 16px', background:'var(--bg-card)', border:'1px solid var(--line)', borderRadius:6}}>
          <div style={{display:'flex', alignItems:'center', gap:10}}>
            <Icon d={EI.refresh} size={14}/>
            <span style={{fontSize:12.5, fontWeight:500, color:'var(--text-primary)'}}>Automatic Key Rotation</span>
            <span className="ep-pill" style={{color:'var(--accent)', borderColor:'rgba(0,230,138,.3)', background:'rgba(0,230,138,.10)'}}>● enabled · 90d</span>
          </div>
          <Icon d={EI.chev} size={14}/>
        </div>
      </div>

      {/* Filter row */}
      <div className="ep-filter-row" style={{marginBottom:0, borderBottomLeftRadius:0, borderBottomRightRadius:0, borderBottom:'none'}}>
        <Icon d={EI.filter} size={14} cls=""/>
        <div className="ep-filter-input" style={{flex:1, maxWidth:280}}>
          <Icon d={I.search} size={13}/>
          <input
            value={filter}
            onChange={e => setFilter(e.target.value)}
            placeholder="Filter by hostname"
            style={{flex:1, background:'transparent', border:'none', outline:'none', color:'var(--text-primary)', fontSize:12.5}}
          />
        </div>
        <select className="ep-filter-select"><option>All OS</option></select>
        <select className="ep-filter-select"><option>All Status</option></select>
        <div style={{display:'flex', alignItems:'center', gap:8, marginLeft:6}}>
          <span className={`ep-toggle ${onlineOnly?'is-on':''}`} onClick={() => setOnlineOnly(!onlineOnly)}/>
          <span style={{fontSize:11.5, color:'var(--text-muted)'}}>Online Only</span>
        </div>
        <div style={{flex:1}}/>
        <span style={{fontFamily:'var(--font-mono)', fontSize:10.5, color:'var(--text-muted)'}}>{hosts.length} agents</span>
        <button className="ep-btn"><Icon d={EI.refresh} size={12}/> Refresh</button>
      </div>

      <div className="ep-table-wrap" style={{borderTopLeftRadius:0, borderTopRightRadius:0, borderTop:'none'}}>
        <table className="ep-table">
          <thead>
            <tr>
              <th style={{width:32}}><span className="ep-checkbox"/></th>
              <th style={{width:62}}>Status</th>
              <th>Hostname</th>
              <th style={{width:80}}>OS</th>
              <th style={{width:64}}>Arch</th>
              <th style={{width:96}}>Version</th>
              <th style={{width:90}}>Last Seen</th>
              <th style={{width:64}}>Health</th>
              <th style={{width:90}}>Tags</th>
              <th className="col-actions">Actions</th>
            </tr>
          </thead>
          <tbody>
            {hosts.filter(h => !filter || h.hostname.toLowerCase().includes(filter.toLowerCase())).map(h => (
              <tr key={h.id} onClick={() => onPick && onPick(h)} style={{cursor:'pointer'}}>
                <td><span className="ep-checkbox"/></td>
                <td><span className={`ep-status-dot ${h.status==='offline'?'is-offline':''}`}/></td>
                <td className="col-host">{h.hostname}</td>
                <td><OsPill os={h.os}/></td>
                <td className="col-mono">{h.arch}</td>
                <td className="col-mono">
                  {h.version}
                  {h.stale && <span className="ep-stale-tag">stale</span>}
                </td>
                <td className="col-mono" style={{color:'var(--text-muted)'}}>{h.lastSeen}</td>
                <td><HealthBadge value={h.health}/></td>
                <td>
                  {h.tags.map(t => <span key={t} className="ep-tag">{t}</span>)}
                </td>
                <td className="col-actions">
                  <button className="ep-icon-btn" onClick={e => e.stopPropagation()}><Icon d={EI.more} size={14}/></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:12, fontFamily:'var(--font-mono)', fontSize:10.5, color:'var(--text-muted)'}}>
        <span>showing 1–{hosts.length} of {hosts.length}</span>
        <span>page 1 of 1</span>
      </div>
    </EpShell>
  );
}

Object.assign(window, { EndpointsAgents });
