/* global React, Icon, I */
const { useState: useEpState } = React;
const ED = window.ENDPOINTS_DATA;

// ── Endpoints icons ───────────────────────────────────────────────────
const EI = {
  bot: <><rect x="3" y="11" width="18" height="10" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4"/><path d="M8 16h.01"/><path d="M16 16h.01"/></>,
  online: <><circle cx="12" cy="12" r="9"/><path d="M12 8v4l2 2"/></>,
  wifi:  <><path d="M5 12.55a11 11 0 0 1 14 0"/><path d="M2 8.5a17 17 0 0 1 20 0"/><path d="M8.5 16a6 6 0 0 1 7 0"/><line x1="12" y1="20" x2="12" y2="20"/></>,
  wifiOff: <><line x1="2" y1="2" x2="22" y2="22"/><path d="M8.5 16.5a5 5 0 0 1 7 0"/><path d="M2 8.82a15 15 0 0 1 4.17-2.65"/><path d="M10.66 5c4.01-.36 8.14.9 11.34 3.76"/><path d="M16.85 11.25a10 10 0 0 1 2.22 1.68"/><path d="M5 12.55a10.94 10.94 0 0 1 5.17-2.39"/><line x1="12" y1="20" x2="12.01" y2="20"/></>,
  clip:  <><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></>,
  copy:  <><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></>,
  refresh: <><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10"/><path d="M20.49 15A9 9 0 0 1 5.64 18.36L1 14"/></>,
  pause: <><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></>,
  trash: <><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/></>,
  plus:  <><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></>,
  more:  <><circle cx="12" cy="12" r="1"/><circle cx="5" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>,
  expand:<><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></>,
  back:  <><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></>,
  cpu:   <><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="15" x2="23" y2="15"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="15" x2="4" y2="15"/></>,
  hdd:   <><line x1="22" y1="12" x2="2" y2="12"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/><line x1="6" y1="16" x2="6.01" y2="16"/><line x1="10" y1="16" x2="10.01" y2="16"/></>,
  mem:   <><path d="M3 7h18M3 17h18M7 3v18M17 3v18"/></>,
  heart: <><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></>,
  alert: <><path d="m10.29 3.86-8.55 14.83A2 2 0 0 0 3.47 22h17.06a2 2 0 0 0 1.73-3.31L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></>,
  filter:<><path d="M22 3H2l8 9.46V19l4 2v-8.54L22 3z"/></>,
  chev:  <><polyline points="9 18 15 12 9 6"/></>,
  close: <><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></>,
};

// ── Sidebar (Endpoints active) ────────────────────────────────────────
function EpSidebar({ activeKey = 'endpoints:dashboard' }) {
  const items = [
    { group:'Tests', icon: I.flask, items: [
      { key:'tests:dashboard', icon: I.layout, label:'Dashboard' },
      { key:'tests:browse',    icon: I.grid,   label:'Browse All' },
      { key:'tests:favorites', icon: I.star,   label:'Favorites' },
    ]},
    { group:'Analytics', icon: I.chart, items: [
      { key:'analytics:dashboard',  icon: I.layout, label:'Dashboard' },
      { key:'analytics:executions', icon: I.play,   label:'Executions' },
    ]},
    { group:'Endpoints', icon: I.monitor, items: [
      { key:'endpoints:dashboard', icon: I.layout, label:'Dashboard' },
      { key:'endpoints:agents',    icon: EI.bot,   label:'Agents' },
      { key:'endpoints:tasks',     icon: I.task,   label:'Tasks' },
    ]},
  ];
  return (
    <aside className="dash-sidebar" style={{ '--side-accent':'var(--accent)' }}>
      <div className="dash-sidebar-logo">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L4 6v6c0 5 3.5 9 8 10 4.5-1 8-5 8-10V6l-8-4z" stroke="var(--accent)" strokeWidth="1.8"/>
          <path d="M9 12l2 2 4-4" stroke="var(--accent)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        <span className="dash-sidebar-brand">ACHILLES</span>
      </div>
      <div className="dash-sidebar-section-title">Modules</div>
      {items.map(g => (
        <div key={g.group} className="dash-sidebar-group">
          <div className="dash-sidebar-group-head">
            <Icon d={g.icon} size={14} />
            <span>{g.group}</span>
          </div>
          <ul>
            {g.items.map(it => (
              <li key={it.key} className={activeKey === it.key ? 'is-active' : ''}>
                <Icon d={it.icon} size={14} />
                <span>{it.label}</span>
                {activeKey === it.key && <span className="dash-sidebar-active-bar"/>}
              </li>
            ))}
          </ul>
        </div>
      ))}
      <div className="dash-sidebar-foot">
        <button className="dash-sidebar-settings">
          <Icon d={I.cog} size={14}/><span>Settings</span>
        </button>
      </div>
    </aside>
  );
}

function EpTopBar({ title }) {
  return (
    <header className="dash-topbar">
      <div className="dash-topbar-left">
        <div className="dash-topbar-title">{title}</div>
        <div className="dash-topbar-search">
          <Icon d={I.search} size={14}/>
          <input placeholder="Search tests, agents, tasks…"/>
          <span className="dash-topbar-kbd">⌘K</span>
        </div>
      </div>
      <div className="dash-topbar-right">
        <button className="dash-icon-btn"><Icon d={I.bell} size={16}/></button>
        <button className="dash-icon-btn"><Icon d={I.cmd} size={16}/></button>
        <div className="dash-theme-pill">Tactical Dark ▾</div>
        <div className="dash-user-chip">
          <span className="tac-label" style={{color:'var(--accent)'}}>Administrator</span>
          <div className="dash-user-avatar">J</div>
        </div>
      </div>
    </header>
  );
}

// ── Page shell ────────────────────────────────────────────────────────
function EpShell({ title, activeKey, label, children }) {
  return (
    <div className="dash-shell" data-screen-label={label || title}>
      <EpSidebar activeKey={activeKey}/>
      <div style={{display:'flex', flexDirection:'column', minWidth:0}}>
        <EpTopBar title={title}/>
        <main className="ep-main"><div className="ep-scroll">{children}</div></main>
      </div>
    </div>
  );
}

// ── Status pill ───────────────────────────────────────────────────────
function StatusPill({ status }) {
  const map = {
    completed: { c:'#00e68a', bg:'rgba(0,230,138,.12)', label:'completed' },
    failed:    { c:'#ff5a72', bg:'rgba(255,59,92,.12)', label:'failed' },
    pending:   { c:'#ffc857', bg:'rgba(255,200,87,.10)', label:'pending' },
    assigned:  { c:'#7eaaff', bg:'rgba(79,142,255,.12)', label:'assigned' },
    active:    { c:'#00e68a', bg:'rgba(0,230,138,.12)', label:'active' },
    paused:    { c:'#ffc857', bg:'rgba(255,200,87,.10)', label:'paused' },
  };
  const m = map[status] || { c:'var(--text-muted)', bg:'rgba(255,255,255,.04)', label:status };
  return <span className="ep-pill" style={{color:m.c, background:m.bg, borderColor:m.c+'33'}}>{m.label}</span>;
}

// ── Health badge ──────────────────────────────────────────────────────
function HealthBadge({ value }) {
  const c = value >= 80 ? '#00e68a' : value >= 50 ? '#ffc857' : '#ff5a72';
  const bg = value >= 80 ? 'rgba(0,230,138,.14)' : value >= 50 ? 'rgba(255,200,87,.14)' : 'rgba(255,59,92,.14)';
  return <span className="ep-health" style={{color:c, background:bg, borderColor:c+'40'}}>{value}</span>;
}

// ── OS pill ───────────────────────────────────────────────────────────
function OsPill({ os }) {
  return <span className="ep-os">{os}</span>;
}

// ── Sparkline (minimal) ───────────────────────────────────────────────
function EpSpark({ data, color = '#00e68a', w = 100, h = 28 }) {
  const min = Math.min(...data), max = Math.max(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => [(i / (data.length - 1)) * w, h - ((v - min) / range) * (h - 4) - 2]);
  const path = pts.map((p, i) => (i === 0 ? `M${p[0]},${p[1]}` : `L${p[0]},${p[1]}`)).join(' ');
  return (
    <svg width={w} height={h} style={{display:'block'}}>
      <path d={`${path} L${w},${h} L0,${h} Z`} fill={color} opacity=".12"/>
      <path d={path} fill="none" stroke={color} strokeWidth="1.4" strokeLinecap="round"/>
    </svg>
  );
}

// ── Detailed line chart with axes ─────────────────────────────────────
function EpLineChart({ series, height = 200, showAxes = true, yMax }) {
  const w = 720, padL = 36, padR = 12, padT = 12, padB = 22;
  const cw = w - padL - padR, ch = height - padT - padB;
  const allMax = yMax ?? Math.max(...series.flatMap(s => s.data));
  const yScale = v => padT + ch - (v / allMax) * ch;
  const xScale = (i, n) => padL + (i / (n - 1)) * cw;
  const linePath = data => data.map((v, i) => `${i === 0 ? 'M' : 'L'}${xScale(i, data.length)},${yScale(v)}`).join(' ');

  return (
    <svg viewBox={`0 0 ${w} ${height}`} style={{width:'100%', height, display:'block'}}>
      {showAxes && [0, 0.25, 0.5, 0.75, 1].map(t => (
        <g key={t}>
          <line x1={padL} y1={padT + ch * (1 - t)} x2={padL + cw} y2={padT + ch * (1 - t)} stroke="rgba(255,255,255,.04)" strokeDasharray="2 4"/>
          <text x={padL - 6} y={padT + ch * (1 - t) + 3} fill="#6b7388" fontSize="9" textAnchor="end" fontFamily="var(--font-mono)">{Math.round(allMax * t)}</text>
        </g>
      ))}
      {series.map((s, i) => (
        <path key={i} d={linePath(s.data)} fill="none" stroke={s.color} strokeWidth="1.4" opacity={s.opacity ?? 1}/>
      ))}
    </svg>
  );
}

Object.assign(window, { EpSidebar, EpTopBar, EpShell, EI, StatusPill, HealthBadge, OsPill, EpSpark, EpLineChart, ED });
