/* global React, Icon, I, EI, EpShell, ED, OsPill, StatusPill, EpSpark */
const { useState: useDashState } = React;

// ── KPI tile ─────────────────────────────────────────────────────────
function KPI({ icon, tone='accent', value, label, suffix }) {
  return (
    <div className="ep-kpi">
      <div className={`ep-kpi-icon is-${tone}`}><Icon d={icon} size={18}/></div>
      <div>
        <div className="ep-kpi-val">
          {value}{suffix && <span style={{fontSize:14, color:'var(--text-muted)', marginLeft:2}}>{suffix}</span>}
        </div>
        <div className="ep-kpi-label">{label}</div>
      </div>
    </div>
  );
}

// ── Donut (single-segment + center label) ────────────────────────────
function Donut({ slices, size=120, label, sublabel }) {
  const cx = size/2, cy = size/2, r = size/2 - 8, c = 2*Math.PI*r;
  let offset = 0;
  return (
    <div style={{position:'relative', width:size, height:size, flexShrink:0}}>
      <svg width={size} height={size} style={{transform:'rotate(-90deg)'}}>
        <circle cx={cx} cy={cy} r={r} fill="none" stroke="rgba(255,255,255,.04)" strokeWidth="10"/>
        {slices.map((s, i) => {
          const len = (s.pct/100) * c;
          const dash = `${len} ${c-len}`;
          const node = <circle key={i} cx={cx} cy={cy} r={r} fill="none" stroke={s.color} strokeWidth="10" strokeDasharray={dash} strokeDashoffset={-offset}/>;
          offset += len;
          return node;
        })}
      </svg>
      <div style={{position:'absolute', inset:0, display:'grid', placeItems:'center', textAlign:'center'}}>
        <div>
          <div style={{fontFamily:'var(--font-display)', fontSize:18, fontWeight:700, color:'var(--text-primary)'}}>{label}</div>
          {sublabel && <div style={{fontFamily:'var(--font-mono)', fontSize:9.5, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'.18em', marginTop:2}}>{sublabel}</div>}
        </div>
      </div>
    </div>
  );
}

// ── Activity bars ────────────────────────────────────────────────────
function ActivityCell({ icon, color, value, label }) {
  return (
    <div style={{display:'flex', alignItems:'center', gap:10}}>
      <div style={{width:28, height:28, borderRadius:4, display:'grid', placeItems:'center', background:`${color}1f`, color, border:`1px solid ${color}33`}}>
        <Icon d={icon} size={13}/>
      </div>
      <div>
        <div style={{fontFamily:'var(--font-display)', fontSize:18, fontWeight:700, color:'var(--text-primary)', lineHeight:1}}>{value}</div>
        <div style={{fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'.14em', marginTop:4}}>{label}</div>
      </div>
    </div>
  );
}

function EndpointsDashboard() {
  const k = ED.dashKpis, a = ED.activity24h;
  return (
    <EpShell title="Endpoints · Dashboard" activeKey="endpoints:dashboard" label="01 Endpoints — Dashboard">
      <div className="ep-page-head">
        <div>
          <h1>Agent Dashboard</h1>
          <p>Fleet overview and operational status · 31 agents across the estate</p>
        </div>
        <div style={{display:'flex', gap:8}}>
          <button className="ep-btn"><Icon d={I.sync} size={13}/> Refresh</button>
          <button className="ep-btn"><Icon d={I.download} size={13}/> Export CSV</button>
        </div>
      </div>

      {/* Top KPI row */}
      <div className="ep-grid" style={{gridTemplateColumns:'repeat(4, 1fr)'}}>
        <KPI icon={I.monitor} tone="blue"  value={k.totalAgents} label="Total Agents"/>
        <KPI icon={EI.wifi}   tone="accent" value={k.online} label="Online"/>
        <KPI icon={EI.wifiOff} tone="pink"  value={k.offline} label="Offline"/>
        <KPI icon={EI.clip}   tone="warn"  value={k.pendingTasks} label="Pending Tasks"/>
      </div>

      {/* Health metrics row */}
      <div className="ep-grid" style={{gridTemplateColumns:'repeat(5, 1fr)', marginTop:14}}>
        <KPI icon={I.chart}   tone="accent" value={k.fleetUptime} suffix="%" label="Fleet Uptime (30d)"/>
        <KPI icon={I.check}   tone="blue"   value={k.taskSuccess} suffix="%" label="Task Success (7d)"/>
        <KPI icon={I.clock}   tone="violet" value={k.mtbf}        suffix="h" label="MTBF"/>
        <KPI icon={EI.alert}  tone="warn"   value={k.staleAgents}            label="Stale Agents"/>
        <KPI icon={EI.heart}  tone="pink"   value={k.avgHealth}              label="Avg Health"/>
      </div>

      {/* Stale callout */}
      <div className="ep-callout" style={{marginTop:14}}>
        <div className="ep-callout-icon"><Icon d={EI.alert} size={20}/></div>
        <div className="ep-callout-text">
          <strong>22 stale agents detected</strong>
          <p>Online agents with no completed tasks in the last 7 days · likely scheduling drift or task scope mismatch</p>
        </div>
        <button className="ep-callout-btn">View →</button>
      </div>

      {/* Two-column row */}
      <div className="ep-grid" style={{marginTop:14}}>
        {/* Task activity */}
        <div className="col-6 ep-card">
          <div className="ep-card-head">
            <div className="ep-card-title"><Icon d={I.play} size={14}/> Task Activity (24h)</div>
            <span style={{fontFamily:'var(--font-mono)', fontSize:10.5, color:'var(--text-muted)'}}>{a.completed + a.failed + a.inProgress} runs</span>
          </div>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:14, marginBottom:14}}>
            <ActivityCell icon={I.check}  color="#00e68a" value={a.completed} label="Completed"/>
            <ActivityCell icon={EI.alert} color="#ff5a72" value={a.failed} label="Failed"/>
            <ActivityCell icon={I.play}   color="#7eaaff" value={a.inProgress} label="In Progress"/>
            <ActivityCell icon={I.chart}  color="#a78bfa" value={`${a.successRate}%`} label="Success Rate"/>
          </div>
          <div style={{padding:'10px 12px', background:'rgba(0,0,0,.25)', borderRadius:4, border:'1px solid var(--line)'}}>
            <div style={{fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'.18em', marginBottom:6}}>Activity (last 24h)</div>
            <EpSpark data={[2,3,1,4,2,5,3,7,4,2,1,3,2,1,4,6,3,2,1,2,4,1,2,1]} color="#7eaaff" w={400} h={36}/>
          </div>
        </div>

        {/* Agent versions */}
        <div className="col-6 ep-card">
          <div className="ep-card-head">
            <div className="ep-card-title"><Icon d={I.cmd} size={14}/> Agent Version Distribution</div>
            <a className="ep-pill" style={{borderColor:'rgba(167,139,250,.3)', color:'var(--violet)', background:'rgba(167,139,250,.10)'}}>1 version</a>
          </div>
          <div className="ep-donut-wrap">
            <Donut slices={[{pct:100, color:'#a78bfa'}]} size={130} label="0.5.4" sublabel="Latest"/>
            <div className="ep-donut-legend">
              {ED.versionDistribution.map(v => (
                <div className="ep-donut-row" key={v.version}>
                  <span className="ep-donut-sw" style={{background:v.color}}/>
                  <span className="ep-donut-name">v{v.version}</span>
                  <span className="ep-donut-val">{v.count} ({v.pct}%)</span>
                </div>
              ))}
              <div style={{marginTop:8, padding:'8px 10px', background:'rgba(0,230,138,.06)', border:'1px solid rgba(0,230,138,.2)', borderRadius:4, fontSize:11, color:'var(--accent)'}}>
                ✓ All agents on latest version
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* OS + Status row */}
      <div className="ep-grid" style={{marginTop:14}}>
        <div className="col-6 ep-card">
          <div className="ep-card-head">
            <div className="ep-card-title"><Icon d={I.layout} size={14}/> OS Distribution</div>
          </div>
          {ED.osDistribution.map(d => (
            <div className="ep-bar-row" key={d.os}>
              <span style={{color:'var(--text-primary)', fontSize:12.5}}>{d.os}</span>
              <div className="ep-bar"><div className="ep-bar-fill" style={{width:`${d.pct}%`}}/></div>
              <span className="ep-bar-pct">{d.count} ({d.pct}%)</span>
            </div>
          ))}
          <div style={{marginTop:14, paddingTop:14, borderTop:'1px solid var(--line-soft)', display:'flex', gap:24}}>
            <div>
              <div style={{fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'.18em'}}>Architecture</div>
              <div style={{marginTop:6, display:'flex', alignItems:'center', gap:8}}>
                <span style={{fontFamily:'var(--font-display)', fontSize:18, fontWeight:700, color:'var(--text-primary)'}}>amd64</span>
                <span className="ep-pill" style={{color:'var(--text-muted)', borderColor:'var(--line)'}}>31</span>
              </div>
            </div>
            <div>
              <div style={{fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'.18em'}}>Latest version</div>
              <div style={{marginTop:6, fontFamily:'var(--font-mono)', fontSize:14, color:'var(--accent)'}}>v0.5.4</div>
            </div>
          </div>
        </div>

        <div className="col-6 ep-card">
          <div className="ep-card-head">
            <div className="ep-card-title"><Icon d={I.shield} size={14}/> Status Distribution</div>
          </div>
          <div className="ep-donut-wrap">
            <Donut
              slices={[
                {pct:70, color:'#00e68a'},
                {pct:30, color:'#ff3b5c'},
              ]}
              size={130} label="44" sublabel="Total"/>
            <div className="ep-donut-legend">
              {ED.statusDistribution.map(s => (
                <div className="ep-donut-row" key={s.status}>
                  <span className="ep-donut-sw" style={{background:s.color}}/>
                  <span className="ep-donut-name">{s.status}</span>
                  <span className="ep-donut-val">{s.count} ({s.pct}%)</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Recent tasks table */}
      <div className="ep-card" style={{marginTop:14, padding:0}}>
        <div className="ep-card-head" style={{padding:'14px 18px 10px'}}>
          <div className="ep-card-title"><Icon d={I.task} size={14}/> Recent Tasks</div>
          <a style={{fontFamily:'var(--font-mono)', fontSize:11, color:'var(--accent)'}}>View All →</a>
        </div>
        <table className="ep-table" style={{border:'none', borderRadius:0}}>
          <thead>
            <tr>
              <th style={{width:120}}>Status</th>
              <th>Task</th>
              <th style={{width:160}}>Agent</th>
              <th style={{width:100}}>Duration</th>
              <th style={{width:100}}>Exit Code</th>
              <th style={{width:90}}>Created</th>
            </tr>
          </thead>
          <tbody>
            {ED.recentTasks.map((t, i) => (
              <tr key={i}>
                <td><StatusPill status={t.status}/></td>
                <td style={{color:'var(--text-primary)'}}>{t.task}</td>
                <td className="col-mono">{t.agent}</td>
                <td className="col-mono">{t.duration}</td>
                <td className="col-mono" style={{color: t.exitCode === '—' ? 'var(--text-muted)' : t.exitCode === 1 ? 'var(--danger)' : 'var(--text-primary)'}}>{t.exitCode}</td>
                <td className="col-mono" style={{color:'var(--text-muted)'}}>{t.created}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </EpShell>
  );
}

Object.assign(window, { EndpointsDashboard });
