# Handoff: Endpoints Module

## Overview

This is a redesign of the Achilles **Endpoints Module** — fleet management for enrolled
agents. Current implementation lives in `frontend/src/pages/endpoints/` (multiple page
files + modals).

The redesign covers four primary surfaces + three modals/drawers:

1. **Agent Dashboard** — fleet KPIs (total / online / offline / pending tasks +
   uptime / task success / MTBF / stale agents / avg health), stale-agents callout,
   task activity (24h), agent version distribution donut, OS distribution bars,
   status distribution donut, recent tasks table.
2. **Agents** — filterable host table with status dot, OS pill, version + stale flag,
   last-seen, health badge, tags, per-row action menu.
3. **Agent Detail** — per-agent surface, four tabs:
   - **Overview** — system info + metadata + recent tasks
   - **Task History** — full task table for this host
   - **Heartbeat** — sparkline cards (CPU / Memory / Disk / Agent Memory) → expanded chart
   - **Event Log** — filter chips + chronological event stream
4. **Tasks** — scheduled bundles + executions table with expandable per-agent child rows.

**Modals:**
- **Create Task** — target agents picker, task type (Security Test / Command), run mode
  (Run Now / Schedule), timeout / priority / target index.
- **Enroll Agent** — TTL + max-uses, generated token, install-command snippets for 5 OSes.
- **Execution Detail** — per-agent execution drill-down (stdout/stderr/metadata/raw JSON tabs).
  Toggleable between **Modal** and **Drawer** layout via the in-page Tweaks panel.

The visual language is the same Tactical Green system established by the Dashboard V1
handoff (`design_handoff_dashboard_v1/`) and the landing page handoff
(`design_handoff_achilles_landing/`). Reuse those tokens; do not introduce new ones.

> **Branch.** Implement on a new branch — suggested name: `redesign/endpoints-module-v1`.

## About the Design Files

The files in `source/` are **design references created in HTML/JSX** — a high-fidelity
prototype demonstrating the intended look, layout, behavior, copy, and interactions for
the Endpoints Module. They use React 18 from a CDN with in-browser Babel transpilation
and mock data from `endpoints-data.js`.

**Your job is not to ship this HTML directly.** Recreate the design in the existing
Fortika `frontend/` codebase using its established patterns: TSX components, the existing
styling system, the existing endpoints/agents hooks/services in `frontend/src/services/`
and `frontend/src/hooks/`, and the `AchillesShell` layout produced in the dashboard
handoff (if merged) or the existing layout shell otherwise.

## Fidelity

**High-fidelity (hifi).** All colors, typography, spacing, copy, and interaction details
are final. Recreate pixel-perfectly. All design tokens are inherited from
`source/styles.css` (already shipped via the dashboard handoff).

## File Map

```
design_handoff_endpoints_module/
├── README.md                       ← you are here
└── source/
    ├── Endpoints Module.html       ← entry point (script tags only)
    ├── endpoints-app.jsx           ← root mount + design-canvas wrapper (strip in prod)
    ├── endpoints-shared.jsx        ← EpShell, OsPill, HealthBadge, StatusPill,
    │                                 EpSpark, EpLineChart helpers
    ├── endpoints-dashboard.jsx     ← Agent Dashboard
    ├── endpoints-agents.jsx        ← Agents list
    ├── endpoints-detail.jsx        ← Agent Detail (4 tabs)
    ├── endpoints-tasks.jsx         ← Tasks page + 3 modals (CreateTask, Enroll, ExecDetail)
    ├── endpoints-data.js           ← mock data (window.EP_DATA aliased as ED)
    ├── endpoints.css               ← Endpoints-module styles
    ├── shared.jsx                  ← Sidebar / TopBar / Icon set (from dashboard handoff)
    ├── tweaks-panel.jsx            ← in-design Tweaks panel (PROTOTYPE ONLY — strip)
    ├── data.js, styles.css, shell.css, v1.css, tests.css, analytics.css ← reused
    ├── design-canvas.jsx           ← DEV ONLY canvas wrapper (strip)
    └── assets/
        └── logo-achilles.svg
```

## Surfaces

The Endpoints Module has its **own sub-nav** rendered as a horizontal tab strip below
the top bar, listing `Dashboard / Agents / Tasks`. Active tab gets accent underline +
bright text. (Agent Detail is reached by clicking a row in Agents — not its own tab.)

### 1 — Agent Dashboard (`endpoints-dashboard.jsx` → `EndpointsDashboard`)

**Purpose:** at-a-glance fleet status.

**Layout (12-col grid, gap 14px):**
- **Row 1 — KPI strip (12 cols):** 4 KPI tiles, equal width.
  - Total Agents · Online · Offline · Pending Tasks
- **Row 2 — Health metrics (12 cols):** 5 KPI tiles.
  - Fleet Uptime (30d) · Task Success (7d) · MTBF · Stale Agents · Avg Health
- **Row 3 — Stale callout (12 cols):** full-width amber callout with `View →` action.
- **Row 4 — Activity + Versions (12 cols):**
  - Task Activity (24h, 6 cols): 4 mini stats (completed/failed/in-progress/success rate) + sparkline.
  - Agent Version Distribution (6 cols): donut + legend + "All agents on latest" check.
- **Row 5 — OS + Status (12 cols):**
  - OS Distribution (6 cols): horizontal bars + Architecture / Latest version footer.
  - Status Distribution (6 cols): donut + legend.
- **Row 6 — Recent Tasks (12 cols):** table — `Status · Task · Agent · Duration · Exit · Created`.

### 2 — Agents (`endpoints-agents.jsx` → `EndpointsAgents`)

**Purpose:** find and act on individual agents.

**Layout:**
- Page header: title + count + `Enroll Agent` primary button.
- Two collapsed-expandable strips: **Available Binaries** + **Automatic Key Rotation** (90d, enabled).
- Filter strip: hostname search · OS dropdown · Status dropdown · Online-only toggle · Refresh.
- Table:
  - Columns: `chk · status dot · hostname · OS pill · arch · version (+ stale tag) · last seen · health · tags · ⋯`.
  - Row click → Agent Detail.
- Pagination footer.

### 3 — Agent Detail (`endpoints-detail.jsx` → `EndpointsAgentDetail`)

**Purpose:** deep dive on a single host.

**Layout:**
- Crumb: `← Agents / <hostname>`.
- Header strip: hostname (Orbitron 24px) + status dot + status pill + OS pill + arch + version + ID,
  right side actions: `Run Task · Refresh Heartbeat · Decommission` (decommission is danger).
- Tab strip: `Overview · Task History · Heartbeat · Event Log`.

**Overview tab:**
- Two-column: System Information (left, 6 cols) + Metadata (right, 6 cols).
- Health-below-50 amber callout if applicable.
- Recent Tasks card below.

**Task History tab:**
- Full-width table — `Status · Task · Started · Duration · Exit · Actions`.
- Row click → Execution Detail modal.

**Heartbeat tab:**
- Period selector (`7d / 14d / 30d`) + data-points count.
- Four sparkline cards (CPU · Memory · Disk Free · Agent Memory). Click a card → expanded chart.
- Expanded chart: line chart by default (toggleable to area in Tweaks). Multi-series for CPU
  (host vs agent). X-axis date labels.

**Event Log tab:**
- Filter chips: `All · Enrolled · Came Online · Went Offline · Task Completed · Task Failed ·
  Version Updated · Key Rotated · Status Changed · Decommissioned`.
- Stream of event rows: type pill + detail + timestamp.

### 4 — Tasks (`endpoints-tasks.jsx` → `EndpointsTasks`)

**Purpose:** schedule bundles and inspect executions.

**Layout:**
- Page header: title + counts + `Create Task` primary button.
- **Scheduled Tasks** section: list of cadence rows with pause/resume + delete actions.
- **Executions** section: filter strip + grouped table.
  - Parent rows: `chk · expander · status counts · task name · agents · created · duration · exit · notes · actions`.
  - Click expander → child table (per-agent rows): `agent · status · duration · exit code · notes · actions`.
  - Child row click → Execution Detail modal.

### Modals

**Create Task (`endpoints-tasks.jsx` → `CreateTaskModal`):**
- Target Agents picker (search + online toggle + scrollable checkbox list + tag chips).
- Task Type segmented (Security Test / Command).
- Task / Command picker.
- Run Mode segmented (Run Now / Schedule).
- Three-up: Timeout (sec) · Priority · Target Index.

**Enroll Agent (`endpoints-tasks.jsx` → `EnrollAgentModal`):**
- TTL (hours) + Max Uses inputs.
- Generated token in mono token-row with copy button.
- Install Commands accordion: 5 OS variants — Windows PS, Linux amd64, Linux arm64,
  macOS Apple Silicon, macOS Intel. Open one at a time. Each shows the curl/PowerShell
  one-liner with the token baked in + copy button.
- Info callout: `Token expires in {ttl}h · single-use · agent fingerprint pinned at first heartbeat.`

**Execution Detail (`endpoints-tasks.jsx` → `ExecutionDetailModal`):**
- Two layout patterns, switchable via Tweaks: **Modal** (centered, wide) or **Drawer**
  (right-edge, 560px).
- Header: `Execution · {agent}` + task name.
- Meta grid: `Agent · Status · Duration · Exit Code · Started · Completed · Agent ID`.
- Tabs: `stdout · stderr · Metadata · Raw JSON`.
- Content area is a mono `<pre>` with copy action.
- **Default in production:** ship Drawer pattern. Modal is the alternative if user testing prefers it.

## Components & Cards

Reusable helpers in `endpoints-shared.jsx`:
- **EpShell**: page wrapper with sub-nav.
- **OsPill**: 1px-border pill with OS glyph color (windows blue / linux warn / darwin violet).
- **StatusPill**: success/failure/pending/in-progress/assigned coloring.
- **HealthBadge**: 0–100 score with severity color (≥80 accent / 50–79 warn / <50 danger).
- **EpSpark**: tiny SVG sparkline for KPI cards.
- **EpLineChart**: full-width SVG line chart with axis ticks, multi-series.

## Interactions & Behavior

- **Agents row click** → `/endpoints/agents/:id` (Agent Detail).
- **Agent Detail tab change**: tabs are URL params (`?tab=heartbeat`) so deep-links work.
- **Heartbeat sparkline card click**: switches the expanded chart's metric. Active card
  gets accent border.
- **Heartbeat chart style** (line vs area): Tweaks-panel toggle in the prototype. In
  production, ship **line**. Area is for explorations only.
- **Period selector** (7d/14d/30d): updates the spark + expanded chart data.
- **Task expander chevron**: rotates 90° when open, expands child table.
- **Bulk-select**: standard checkbox model on parent rows.
- **Create Task modal — host picker**: search + online toggle + tag chips. Multi-select.
- **Enroll Agent — token generation**: clicking `Generate New Token` regenerates and
  rebakes the token into all 5 install commands.
- **Execution Detail tabs**: stdout/stderr/Metadata/Raw JSON. Copy-to-clipboard button
  in the tab strip.
- **Decommission (Agent Detail)**: opens a confirm dialog — reuse existing pattern.

## State Management

- `route`: sub-nav active page from React Router.
- `agentDetailTab`: from URL param.
- `heartbeatPeriod`: `'7d' | '14d' | '30d'`.
- `heartbeatActiveMetric`: `'cpu' | 'mem' | 'disk' | 'agent'`.
- `expandedBundles` (Tasks): `Set<string>`.
- `eventLogFilter`: string from filter chip set.
- `executionDetail`: `{ open: bool, executionId: string }` driven by route or modal state.

## Design Tokens

Reuse tokens from `source/styles.css` per `design_handoff_dashboard_v1/README.md`.
No new tokens.

OS pill colors:
- `windows` → `var(--signal)` (blue)
- `linux` → `var(--warn-bright)` (amber)
- `darwin` → `var(--violet)`

Status pill colors:
- `completed` → `var(--accent)`
- `failed` → `var(--danger)`
- `pending` → `var(--warn-bright)`
- `in-progress` → `var(--signal)`
- `assigned` → `var(--text-muted)`

Module-specific style classes live in `source/endpoints.css`.

## Data Model

The prototype uses `window.EP_DATA` (aliased as `ED`) from `endpoints-data.js`. Mapping:

| Mock field | Replace with |
|---|---|
| `dashKpis` | Aggregations from agent service (online/offline/pending counts, uptime, MTBF) |
| `activity24h` | Task service: 24h success/failure counts |
| `versionDistribution` | Group `agents[]` by `version` |
| `osDistribution`, `statusDistribution` | Group agents by `os` / `status` |
| `recentTasks` | Task service: latest 5 tasks across fleet |
| `hosts[]` | Existing agents service |
| `host.health` | Health-score service (or stub: derived from uptime + task success) |
| `host.tags` | Existing tag service |
| `detailAgent.heartbeat.*` | Per-host heartbeat time-series (CPU/Mem/Disk) |
| `detailAgent.events[]` | Per-host event-log service |
| `executions[]`, `childRows()` | Task / execution services |
| `scheduled[]` | Schedule service |

## Assets

- `assets/logo-achilles.svg` — reuse existing import if present.

## Dev-only files to strip

- **`design-canvas.jsx`** + **`endpoints-app.jsx`** — design-tool wrapper.
- **`tweaks-panel.jsx`** + the `useTweaks` hook + `<TweaksPanel>` usage — prototype-only
  in-design controls. Pick one variant per knob (heartbeat: line, exec detail: drawer)
  and ship it.
- **The script-tag bootstrap** in `Endpoints Module.html`.
- Any `?v=N` cache-busting query strings.
- Mock data files (`endpoints-data.js`, `data.js`).

## Files in the source bundle

- `Endpoints Module.html` — entry HTML (script tags only)
- `endpoints-app.jsx` — design-canvas mount (dev only)
- `endpoints-shared.jsx` — shell, pills, badges, sparkline, line-chart helpers
- `endpoints-dashboard.jsx` — Agent Dashboard
- `endpoints-agents.jsx` — Agents list
- `endpoints-detail.jsx` — Agent Detail (4 tabs)
- `endpoints-tasks.jsx` — Tasks page + Create / Enroll / Execution-Detail modals
- `endpoints-data.js` — mock data
- `endpoints.css` — Endpoints-module styles
- `tweaks-panel.jsx` — prototype-only Tweaks shell (strip)
- Plus reused files: `shared.jsx`, `data.js`, `styles.css`, `shell.css`, `v1.css`,
  `tests.css`, `analytics.css`
- `design-canvas.jsx` — dev-only wrapper (strip)
- `assets/logo-achilles.svg`
