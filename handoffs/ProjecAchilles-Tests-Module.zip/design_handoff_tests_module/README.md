# Handoff: Tests Module

## Overview

This is a redesign of the Achilles **Tests Module** — the catalog browse view + per-test
detail page. Current implementation lives at `frontend/src/pages/browser/` (sibling to
`BrowserHomePage.tsx`, which was already redesigned in `design_handoff_dashboard_v1`).

The redesign covers two screens:

1. **Browse All** — dense, table-style list of every test in the catalog with severity,
   category, MITRE technique chips, score, last-run timestamp, and per-row run / inspect
   actions. Replaces the current card-grid browse.
2. **Test Detail** — per-test surface with three primary panels:
   - **Files & Documentation** viewer (left tree + tabbed content panel: README / how-it-works /
     YAML / scoring artefacts).
   - **Kill Chain** visualization — horizontal stage diagram (Recon → Weaponize → Deliver →
     Exploit → Install → C2 → Actions) with sub-step rows beneath each stage,
     interactive click-through to drill into a step.
   - Header strip (test ID, severity, category, MITRE technique badges, score, run buttons).

The visual language is the same Tactical Green system established by the Dashboard V1
handoff (`design_handoff_dashboard_v1/`) and the landing page handoff
(`design_handoff_achilles_landing/`). Reuse those tokens; do not introduce new ones.

> **Branch.** Implement on a new branch — suggested name: `redesign/tests-module-v1`.

## About the Design Files

The files in `source/` are **design references created in HTML/JSX** — a high-fidelity
prototype demonstrating the intended look, layout, behavior, copy, and interactions for
the Tests Module. They use React 18 from a CDN with in-browser Babel transpilation and
mock data from `tests-data.js` (catalog) and `data.js` (shell + branch state).

**Your job is not to ship this HTML directly.** Recreate the design in the existing
Fortika `frontend/` codebase using its established patterns: TSX components, the existing
styling system, the existing test catalog hooks/services in `frontend/src/services/` and
`frontend/src/hooks/`, and the `AchillesShell` layout produced in the dashboard handoff
(if merged) or the existing layout shell otherwise.

## Fidelity

**High-fidelity (hifi).** All colors, typography, spacing, copy, and interaction details
are final. Recreate pixel-perfectly. All design tokens are inherited from
`source/styles.css` (already shipped via the dashboard handoff).

## File Map

```
design_handoff_tests_module/
├── README.md                       ← you are here
└── source/
    ├── Tests Module.html           ← entry point (script tags only)
    ├── tests-app.jsx               ← root mount + design-canvas wrapper (strip in prod)
    ├── tests-shared.jsx            ← TestsShell, severity/category/technique pills, etc.
    ├── tests-browse.jsx            ← Browse All (dense list/table)
    ├── tests-detail.jsx            ← Test Detail (header + Files panel + Kill Chain)
    ├── tests-data.js               ← mock catalog (window.TESTS_DATA)
    ├── tests.css                   ← Tests-module-specific styles
    ├── shared.jsx                  ← Sidebar / TopBar / Icon set (from dashboard handoff)
    ├── data.js                     ← shell branch / agent / build state
    ├── styles.css                  ← design tokens (DO NOT redefine)
    ├── shell.css                   ← Sidebar / TopBar / generic .dash-card
    ├── v1.css                      ← reused .v1-grid layout
    ├── design-canvas.jsx           ← DEV ONLY canvas wrapper (strip)
    └── assets/
        └── logo-achilles.svg
```

## Screens

### 1 — Browse All (`tests-browse.jsx` → `TestsBrowse`)

**Purpose:** scan and filter the entire test catalog; click into a test detail; bulk-run
or queue tests.

**Layout:**

```
AchillesShell
└── Page header:  "Tests" title + result count + filter/sort/run-all action row
└── Filter strip: search box · severity chip group · category chip group · MITRE filter
└── Table (full width):
     ┌──────┬──────────┬─────────────────────┬──────┬──────────┬──────────────┬────────┬───────┬──────┐
     │ chk  │ ID       │ Name                │ Sev  │ Category │ Techniques   │ Score  │ Last  │ Run  │
     ├──────┼──────────┼─────────────────────┼──────┼──────────┼──────────────┼────────┼───────┼──────┤
     │      │ T-0001   │ Defender Tamper…    │ HIGH │ cyber-…  │ T1562 +2     │ 92     │ 6m    │ ▶    │
     │      │ ...      │                     │      │          │              │        │       │      │
     └──────┴──────────┴─────────────────────┴──────┴──────────┴──────────────┴────────┴───────┴──────┘
```

**Per-row spec:**
- Row height: 44px. Hover: `background: var(--accent-subtle)`. Active row: 2px accent left bar.
- ID: mono, 11px, `--text-faint` → hover `--accent`.
- Name: Inter 13px, `--text-primary`, single-line truncate w/ tooltip.
- Severity pill: tactical font, sev-coded (critical=danger, high=warn-bright, medium=signal, low=muted).
- Category pill: small chip with category color dot + label (cyber-hygiene/intel-driven/mitre-top10).
- Techniques: max 2 pills + `+N` overflow chip. Each pill = `T####` mono.
- Score: Orbitron 14px tabular-nums, accent-bright if ≥80, signal if 50–79, danger if <50.
- Last run: mono, 11px, relative time ("6m", "2h", "yesterday").
- Run column: ghost play icon button, hover fills accent.

**Filter strip:**
- Search: 320px input, mono placeholder.
- Severity chips: `All / Critical / High / Medium / Low` — toggle. Multi-select.
- Category chips: `All / cyber-hygiene / intel-driven / mitre-top10`.
- MITRE filter: dropdown with technique IDs grouped by tactic.
- Sort dropdown: `Recently modified · Score (desc) · Severity (high→low) · Name (A–Z)`.

### 2 — Test Detail (`tests-detail.jsx` → `TestsDetail`)

**Purpose:** read the test definition, inspect its files, understand its kill-chain, run
it, and review its scoring history.

**Layout:**

```
AchillesShell
└── Header strip:
     test ID badge · name (Orbitron 22px) · severity pill · category pill ·
     MITRE technique badges · last-modified · author · "▶ Run" / "⋯" actions
└── Two-column body:
     ┌──────────────────────────────┬────────────────────────────────────────┐
     │ FILES PANEL                  │ KILL CHAIN PANEL                       │
     │ ┌──────────┬─────────────┐   │ ┌────────────────────────────────────┐ │
     │ │ tree     │ tabbed      │   │ │ horizontal stage strip             │ │
     │ │ (180px)  │ content     │   │ │ Recon → Weap → Deliver → ...       │ │
     │ │          │             │   │ ├────────────────────────────────────┤ │
     │ │          │             │   │ │ stage detail: sub-steps as rows    │ │
     │ │          │             │   │ │ each row: cmd + technique +        │ │
     │ │          │             │   │ │           expected outcome         │ │
     │ └──────────┴─────────────┘   │ └────────────────────────────────────┘ │
     └──────────────────────────────┴────────────────────────────────────────┘
```

**Files & Documentation panel (left column, ~7/12 grid columns):**
- File tree column (180px wide):
  - Folder icons + filenames in mono. Active file highlighted with `--accent-subtle` bg + 2px accent left bar.
  - File types: `README.md`, `how-it-works.md`, `test.yaml`, `score.yaml`, `assets/*`.
- Tabbed content panel (right of tree):
  - Tab strip on top: filename tabs, mono, 11px tracked .12em. Active tab gets accent underline.
  - Content area: rendered Markdown for `.md` files (use existing markdown renderer in the codebase),
    syntax-highlighted YAML for `.yaml`, image preview for assets.
  - Top-right of panel: "Open in editor" + "Copy path" ghost icon buttons.

**Kill Chain panel (right column, ~5/12 grid columns):**
- Horizontal stage strip across the top:
  - 7 stages: `Recon · Weaponize · Deliver · Exploit · Install · C2 · Actions`.
  - Each stage = a small chip with stage glyph + name + count of sub-steps used.
  - Stages used by the test get accent border + glyph; unused stages dim to `--text-faint`.
  - Click a stage → that stage's detail loads below.
- Stage detail (below the strip):
  - List of rows, one per sub-step. Each row:
    - Step number (mono, 10px, `--text-muted`)
    - Command summary (Inter 12px, `--text-primary`)
    - MITRE technique badge if mapped
    - Expected outcome (Inter 11px, `--text-secondary`)
  - Hover: row gets `--accent-subtle` bg + 1px left accent border.
  - Click: expand to show full command + raw stdout snippet.

**Header strip spec:**
- ID badge: mono 11px in a 1px-border 3px-radius pill.
- Title: Orbitron 22px, weight 700, letter-spacing -.01em.
- Severity + category pills follow the table specs above.
- Technique badges: comma-separated `T####` mono pills, each linkable to the MITRE matrix.
- Action row right-aligned: primary `▶ Run` (accent solid), secondary `⋯` (more menu).

## Interactions & Behavior

- **Browse → Detail navigation:** clicking a row navigates to `/tests/:id`. The detail view
  reads from the same `useTests()` hook used by Browse — no separate fetch.
- **Filters:** all filter state lives in the URL (`?sev=high&cat=cyber-hygiene&q=defender`)
  so filters survive refresh and are shareable.
- **Kill Chain stage click:** updates only the stage-detail region; no page navigation.
- **Files tab click:** lazy-loads file content if the test bundle isn't already cached.
- **Run button (header + per-row):** opens the existing run-confirmation dialog from the
  current codebase. Do NOT recreate; reuse.
- **Hover-only affordances:** the per-row run icon and "⋯" menu only appear on row hover.
- **Truncation:** long test names truncate with native title tooltip. Long technique lists
  collapse to `+N` chip with a popover listing the rest on hover.
- **Empty states:** "No tests match these filters" with a `Reset filters` action.

## State Management

- `tests`: list of all tests (from existing service hook).
- `filters`: `{ search, severities[], categories[], techniques[] }` — synced to URL.
- `sort`: `'modified' | 'score' | 'severity' | 'name'`.
- `selectedTestId` (detail page): from route params.
- `activeFile` (detail page): defaults to `README.md`.
- `activeStage` (detail page): defaults to first stage with sub-steps.

## Design Tokens

Reuse the tokens defined in `source/styles.css` and detailed in
`design_handoff_dashboard_v1/README.md` (Colors, Typography, Spacing, Radii, Shadows
sections). No new tokens are introduced by this module.

Module-specific style classes live in `source/tests.css` — port them into the codebase's
styling system as you would the dashboard's `v1.css`.

## Data Model

The prototype uses `window.TESTS_DATA` from `tests-data.js`. Replace each field with the
real source from your existing services. Mapping:

| Mock field | Replace with |
|---|---|
| `tests[]` | Existing `useTests()` / equivalent service hook |
| `test.id`, `test.name`, `test.severity`, `test.category` | Test catalog record |
| `test.techniques[]` | MITRE technique IDs from the catalog record |
| `test.score`, `test.lastRun` | Existing scoring + run-history services |
| `test.files[]` | Test bundle file listing service (likely already exists for current detail view) |
| `test.killChain` | Derived from `test.yaml` step→tactic mapping |

## Assets

- `assets/logo-achilles.svg` — same logo used everywhere. Reuse existing import if present.

## Dev-only files to strip

When porting to production:
- **`design-canvas.jsx`** + **`tests-app.jsx`** — design-tool wrapper.
- **The script-tag bootstrap** in `Tests Module.html`.
- Any `?v=N` cache-busting query strings.
- Mock data files (`tests-data.js`, `data.js`).

## Files in the source bundle

- `Tests Module.html` — entry HTML (script tags only)
- `tests-app.jsx` — design-canvas mount (dev only)
- `tests-shared.jsx` — shell wrapper, severity/category/technique pills, helpers
- `tests-browse.jsx` — Browse All page
- `tests-detail.jsx` — Test Detail page (header + Files panel + Kill Chain)
- `tests-data.js` — mock catalog
- `tests.css` — Tests-module styles
- Plus reused shell files from the dashboard handoff: `shared.jsx`, `data.js`,
  `styles.css`, `shell.css`, `v1.css`
- `design-canvas.jsx` — dev-only wrapper (strip)
- `assets/logo-achilles.svg`
