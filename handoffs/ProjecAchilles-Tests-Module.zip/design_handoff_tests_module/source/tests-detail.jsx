/* global React, Icon, I, TI, TestSyncRow, SevPill, ScoreBadge, PlatformBadge, TechBadge */
const { useState: useStateD, useMemo: useMemoD } = React;

// ─────────────────────────────────────────────────────────────────────────────
// Hero strip — shared by both Detail variants
// ─────────────────────────────────────────────────────────────────────────────
function DetailHero({ test, onBack, condensed }) {
  return (
    <div className={`tm-detail-hero ${condensed ? 'is-condensed' : ''}`}>
      <button className="tm-back" onClick={onBack}>
        <Icon d={TI.back} size={12} />
        <span>Back to tests</span>
      </button>

      <div className="tm-hero-head">
        <h1 className="tm-hero-title">{test.fullName || test.name}</h1>
        <div className="tm-hero-actions">
          <button className="tm-iconbtn-lg" title="Favorite">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
            </svg>
          </button>
          <button className="tm-iconbtn-lg" title="Run">
            <Icon d={TI.play} size={13} fill="currentColor" sw={0} />
          </button>
          <button className="tm-run-btn">
            <Icon d={TI.play} size={11} fill="currentColor" sw={0} />
            <span>Run test</span>
          </button>
          <div className="tm-hero-score">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            <div className="tm-hero-score-val">
              <strong>{test.score.toFixed(1)}</strong>
              <span className="tac-label">Test Score</span>
            </div>
          </div>
        </div>
      </div>

      <div className="tm-hero-meta">
        <SevPill sev={test.severity} />
        <span className="tm-hero-meta-item">
          <Icon d={I.user} size={11} /><span>{test.author}</span>
        </span>
        <span className="tm-hero-meta-item">
          <Icon d={I.clock} size={11} /><span>{test.created}</span>
        </span>
        <span className="tm-hero-meta-item">
          <span className="dot" style={{ background: 'var(--accent)' }} />
          <span>Modified {test.modified}</span>
        </span>
        {test.platforms.map(p => <PlatformBadge key={p} p={p} />)}
        {test.actor && (
          <span className="tm-hero-meta-item tm-hero-actor">
            <Icon d={I.target} size={11} />
            <span>{test.actor}</span>
          </span>
        )}
        <span className="tm-hero-uuid font-mono">{test.fullUuid}</span>
      </div>

      {test.techniques && test.techniques.length > 0 && (
        <div className="tm-hero-techs">
          {test.techniques.map((t, i) => (
            <span key={i} className="tm-hero-tech">
              <span className="tm-hero-tech-id">{t.id}</span>
              <span className="tm-hero-tech-name">{t.name}</span>
              {t.tactic && <span className="tm-hero-tech-tactic">{t.tactic}</span>}
            </span>
          ))}
        </div>
      )}

      {test.description && (
        <p className="tm-hero-desc">{test.description}</p>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// File tree (left rail) — shared
// ─────────────────────────────────────────────────────────────────────────────
const KIND_ICON = {
  md: I.flask, sys: TI.build, go: TI.source, ps1: TI.source,
  kql: TI.detect, elastic: TI.detect, yara: TI.detect, sigma: TI.detect,
  bin: TI.build, viz: TI.viz,
};
const KIND_TAG = {
  kql: { tag: 'KQL', color: '#4f8eff' },
  elastic: { tag: 'ELASTIC', color: '#22d3ee' },
  yara: { tag: 'YARA', color: '#ffaa2e' },
  sigma: { tag: 'SIGMA', color: '#a78bfa' },
};

function FileTree({ groups, activeFile, onSelect }) {
  const groupIcon = {
    'Documentation': TI.fileMd,
    'Build': TI.build,
    'Defense Guidance': TI.defense,
    'References': TI.refs,
    'Source Code': TI.source,
    'Detection Rules': TI.detect,
    'Visualization': TI.viz,
    'Configuration': TI.config,
  };

  // local collapse state
  const [open, setOpen] = useStateD(() => {
    const o = {};
    groups.forEach(g => { o[g.group] = !g.collapsed; });
    return o;
  });
  const toggle = (k) => setOpen({ ...open, [k]: !open[k] });

  return (
    <aside className="tm-tree">
      {groups.map(g => (
        <div key={g.group} className="tm-tree-group">
          <button className={`tm-tree-head ${open[g.group] ? 'is-open' : ''}`} onClick={() => toggle(g.group)}>
            <Icon d={open[g.group] ? TI.collapse : TI.expand} size={10} sw={2.4} />
            <Icon d={groupIcon[g.group] || TI.folder} size={12} />
            <span className="tm-tree-name">{g.group}</span>
            <span className="tm-tree-count">{g.count}</span>
          </button>
          {open[g.group] && g.items.length > 0 && (
            <ul className="tm-tree-items">
              {g.items.map(item => {
                const isActive = item.active || activeFile === item.name;
                const tag = KIND_TAG[item.kind];
                return (
                  <li key={item.name}
                    className={`tm-tree-item ${isActive ? 'is-active' : ''}`}
                    onClick={() => onSelect && onSelect(item.name)}>
                    {tag && <span className="tm-tree-tag" style={{ color: tag.color }}>{tag.tag}</span>}
                    <span className="tm-tree-fn">{item.name}</span>
                  </li>
                );
              })}
            </ul>
          )}
          {open[g.group] && g.extra && (
            <div className="tm-tree-extra">
              <div className="tm-tree-target">
                <span className="tac-label">Target:</span>
                <span className="tm-tree-target-pill">{g.extra.target}</span>
              </div>
              {g.extra.actions.map(a => (
                <button key={a} className={`tm-tree-action ${a === 'Build & Sign' ? 'primary' : ''}`}>
                  {a === 'Upload Binary' && <Icon d={TI.upload} size={11} />}
                  <span>{a}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      ))}
    </aside>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// V1 — Detail with files (Akira)
// ─────────────────────────────────────────────────────────────────────────────
function DetailV1Files({ onBack }) {
  const test = window.TESTS_DETAIL_AKIRA;
  const [activeFile, setActiveFile] = useStateD('README.md');

  return (
    <>
      <DetailHero test={test} onBack={onBack} />

      <div className="tm-detail-shell">
        <FileTree groups={test.files} activeFile={activeFile} onSelect={setActiveFile} />

        <section className="tm-viewer">
          {/* Stage progression strip — visual badge above the README */}
          <div className="tm-viewer-stages">
            {[
              { n: 1, label: 'Privilege Check', state: 'pass' },
              { n: 2, label: 'Drop rwdrv.sys', state: 'pass' },
              { n: 3, label: 'Defender Disable', state: 'run' },
              { n: 4, label: 'Sim Drivers', state: 'idle' },
              { n: 5, label: 'Cleanup', state: 'idle' },
            ].map((s, i, all) => (
              <div key={s.n} className={`tm-stagepill state-${s.state}`}>
                <span className="tm-stagepill-n">{String(s.n).padStart(2, '0')}</span>
                <span className="tm-stagepill-l">{s.label}</span>
                {i < all.length - 1 && <span className="tm-stagepill-arrow">→</span>}
              </div>
            ))}
          </div>

          <div className="tm-viewer-toolbar">
            <div className="tm-viewer-bc">
              <Icon d={TI.fileMd} size={11} style={{ color: 'var(--accent)' }} />
              <span className="font-mono">README.md</span>
              <span className="tm-viewer-bc-sep">·</span>
              <span className="tac-label">2.3 KB · markdown</span>
            </div>
            <div className="tm-viewer-tools">
              <button className="tm-iconbtn-lg" title="Copy">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
              </button>
              <button className="tm-iconbtn-lg" title="Download">
                <Icon d={TI.download} size={13} />
              </button>
              <button className="tm-iconbtn-lg" title="More">
                <Icon d={TI.more} size={13} fill="currentColor" sw={0} />
              </button>
            </div>
          </div>

          <article className="tm-readme">
            <h1>Akira Ransomware BYOVD Attack Chain (Hybrid Testing)</h1>
            <p className="tm-readme-meta"><strong>Test Score:</strong> 8.9/10</p>

            <h2>Overview</h2>
            <p>This VST simulates the Bring Your Own Vulnerable Driver (BYOVD) attack chain used by Akira ransomware to achieve privilege escalation and disable Windows Defender. The test uses a <strong>hybrid approach</strong>: real vulnerable driver for signature detection testing followed by safe simulated drivers for behavioral detection.</p>

            <h2>How</h2>
            <blockquote className="tm-callout tm-callout-safety">
              <span className="tac-label">SAFETY</span>
              <p><strong>Hybrid Safety Model:</strong> Uses real vulnerable driver only for signature detection (3 seconds), then switches to simulated drivers for all behavioral testing to maintain safety while maximizing detection coverage.</p>
            </blockquote>

            <p className="tm-readme-step-intro">Steps:</p>
            <ol className="tm-readme-steps">
              <li>Check for administrator privileges. If not running as admin, exit <code>NOTRELEVANT</code></li>
              <li><strong>Phase 1:</strong> Drop real <code>rwdrv.sys</code> vulnerable driver for signature detection test</li>
              <li><strong>Phase 2:</strong> Remove real driver and use simulated drivers for behavioral testing</li>
              <li><strong>Phase 3:</strong> Create Windows services (<code>mgdsrv</code> and <code>KMHLPSVC</code>) pointing to simulated drivers</li>
              <li><strong>Phase 4:</strong> Execute PowerShell script to attempt Windows Defender registry manipulation</li>
              <li>Monitor defensive responses at each phase and determine protection status</li>
              <li>Clean up created services, files, and registry modifications (including safety check for real driver)</li>
            </ol>

            <h2>Attack Phases</h2>
            <h3>Phase 1: Signature Detection Test</h3>
            <ul className="tm-readme-bullets">
              <li>Drops real <code>rwdrv.sys</code> vulnerable driver (actual malicious binary)</li>
              <li>Monitors for signature-based quarantine by AV/EDR solutions</li>
              <li><strong>Early exit on detection:</strong> If quarantined → System is <span className="tm-badge-pass">PROTECTED</span></li>
              <li><strong>Safety pivot:</strong> If not detected → Remove real driver immediately</li>
            </ul>
          </article>
        </section>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// V1 — Detail with Kill Chain (APT34)
// ─────────────────────────────────────────────────────────────────────────────
function DetailV1Killchain({ onBack }) {
  const test = window.TESTS_DETAIL_APT34;
  const [activeFile, setActiveFile] = useStateD('Kill Chain Diagram');

  return (
    <>
      <DetailHero test={test} onBack={onBack} condensed />

      <div className="tm-detail-shell">
        <FileTree groups={test.files} activeFile={activeFile} onSelect={setActiveFile} />

        <section className="tm-viewer">
          {/* Headline + score panel */}
          <div className="tm-kc-head-panel">
            <div className="tm-kc-actor">{test.name}</div>
            <p className="tm-kc-subtitle">{test.fullName}</p>
            <div className="tm-kc-actor-row">
              <ScoreBadge score={test.score} size="lg" />
              <SevPill sev={test.severity} size="md" />
              <span className="tm-kc-uuid font-mono">{test.fullUuid}</span>
            </div>
          </div>

          {/* Technique chip strip */}
          <div className="tm-kc-tech-strip">
            {test.techniques.map(t => (
              <div key={t.id} className="tm-kc-tech-card">
                <span className="tm-kc-tech-id">{t.id}</span>
                <span className="tm-kc-tech-name">{t.name}</span>
                <span className="tac-label tm-kc-tech-tactic">{t.tactic}</span>
              </div>
            ))}
          </div>

          {/* Kill Chain diagram */}
          <KillChainDiagram chain={test.killChain} />

          {/* Stage cards */}
          <div className="tm-kc-stages">
            {test.stageCards.map(s => (
              <div key={s.n} className="tm-kc-stage" style={{ '--stage-color': s.color }}>
                <div className="tm-kc-stage-head">
                  <span className="tm-kc-stage-n" style={{ background: s.color }}>{s.n}</span>
                  <span className="tm-kc-stage-name">{s.name}</span>
                </div>
                <div className="tm-kc-stage-tech">
                  <span className="tm-tech tm-tech-stage" style={{ '--tt-color': s.color }}>{s.tid}</span>
                  <span className="tm-kc-stage-tactic">{s.tactic}</span>
                </div>
                <p className="tm-kc-stage-desc">{s.desc}</p>
                <div className="tm-kc-stage-tags">
                  {s.tags.map(tag => <span key={tag} className="tm-kc-stage-tag">{tag}</span>)}
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Native SVG kill-chain diagram (replaces iframe)
// ─────────────────────────────────────────────────────────────────────────────
function KillChainDiagram({ chain }) {
  // Layout: deploy → extract → [stages 1-4 as branching boxes with blocked branches]
  // → exit. Stages are stacked horizontally; each has a "blocked" branch dropping down.
  const W = 920, H = 280;
  const cellW = 110, cellH = 60;
  const startX = 30;
  const stageY = 90;
  const blockedY = 200;
  const exitY = 60;

  // Compute stage box positions
  const stagesX = chain.stages.map((_, i) => startX + 200 + i * (cellW + 30));
  const exitX = startX + 200 + chain.stages.length * (cellW + 30);

  return (
    <div className="tm-kc-card">
      <div className="tm-kc-card-head">
        <div className="tm-kc-card-title">
          <span className="accent-dot" />KILL CHAIN — STAGE PROGRESSION
        </div>
        <div className="tm-kc-card-legend">
          <span><span className="kc-legend-sw" style={{ background: '#a78bfa' }} />Stage</span>
          <span><span className="kc-legend-sw" style={{ background: '#00e68a' }} />Protected</span>
          <span><span className="kc-legend-sw" style={{ background: '#ff3b5c' }} />Unprotected</span>
        </div>
      </div>

      <svg className="tm-kc-svg" viewBox={`0 0 ${W} ${H}`}>
        <defs>
          <marker id="kc-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M0,0 L10,5 L0,10 Z" fill="rgba(255,255,255,.4)"/>
          </marker>
          <marker id="kc-arrow-red" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M0,0 L10,5 L0,10 Z" fill="#ff3b5c"/>
          </marker>
          <marker id="kc-arrow-grn" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M0,0 L10,5 L0,10 Z" fill="#00e68a"/>
          </marker>
        </defs>

        {/* DEPLOY box */}
        <g>
          <rect x={startX} y={stageY} width={cellW * 0.7} height={cellH} rx="2"
            fill="rgba(0,230,138,.06)" stroke="rgba(0,230,138,.4)"/>
          <text x={startX + cellW*0.35} y={stageY + 26} textAnchor="middle" className="kc-text-l">DEPLOY</text>
          <text x={startX + cellW*0.35} y={stageY + 42} textAnchor="middle" className="kc-text-s">{chain.deploy.label}</text>
          <text x={startX + cellW*0.35} y={stageY + 54} textAnchor="middle" className="kc-text-xs">{chain.deploy.detail}</text>
        </g>
        <line x1={startX + cellW*0.7} y1={stageY + cellH/2} x2={startX + cellW*0.7 + 18} y2={stageY + cellH/2}
          stroke="rgba(255,255,255,.4)" strokeWidth="1.2" markerEnd="url(#kc-arrow)"/>

        {/* EXTRACT box */}
        <g>
          <rect x={startX + cellW*0.7 + 22} y={stageY} width={cellW * 0.7} height={cellH} rx="2"
            fill="rgba(0,230,138,.06)" stroke="rgba(0,230,138,.4)"/>
          <text x={startX + cellW*0.7 + 22 + cellW*0.35} y={stageY + 26} textAnchor="middle" className="kc-text-l">EXTRACT</text>
          <text x={startX + cellW*0.7 + 22 + cellW*0.35} y={stageY + 44} textAnchor="middle" className="kc-text-s">{chain.extract.detail}</text>
        </g>
        <line x1={startX + cellW*0.7 + 22 + cellW*0.7} y1={stageY + cellH/2}
          x2={stagesX[0]} y2={stageY + cellH/2}
          stroke="rgba(255,255,255,.4)" strokeWidth="1.2" markerEnd="url(#kc-arrow)"/>

        {/* Stages 1..N */}
        {chain.stages.map((s, i) => {
          const x = stagesX[i];
          const isUnprotected = s.protected === 'unprotected';
          return (
            <g key={s.id}>
              {/* Stage box */}
              <rect x={x} y={stageY} width={cellW} height={cellH} rx="2"
                fill={`${s.color}22`} stroke={s.color} strokeWidth="1.2"/>
              <text x={x + cellW/2} y={stageY + 18} textAnchor="middle" className="kc-text-stage-n">STAGE {s.id}</text>
              <text x={x + cellW/2} y={stageY + 34} textAnchor="middle" className="kc-text-l">{s.name}</text>
              <text x={x + cellW/2} y={stageY + 50} textAnchor="middle" className="kc-text-s">{s.technique}</text>

              {/* Blocked branch (green) */}
              {s.blockers.map((b, j) => (
                <g key={j}>
                  <line x1={x + cellW/2} y1={stageY + cellH}
                    x2={x + cellW/2} y2={blockedY}
                    stroke="#00e68a" strokeWidth="1.2" strokeDasharray="3 3"/>
                  <rect x={x + 10} y={blockedY} width={cellW - 20} height={28} rx="2"
                    fill="rgba(0,230,138,.08)" stroke="rgba(0,230,138,.5)"/>
                  <text x={x + cellW/2} y={blockedY + 18} textAnchor="middle" className="kc-text-blocked">{b.label}</text>
                </g>
              ))}

              {/* Arrow forward */}
              <line x1={x + cellW} y1={stageY + cellH/2}
                x2={i < chain.stages.length - 1 ? stagesX[i+1] : exitX}
                y2={isUnprotected ? exitY + 30 : stageY + cellH/2}
                stroke={isUnprotected ? '#22d3ee' : 'rgba(255,255,255,.4)'} strokeWidth="1.2"
                markerEnd={isUnprotected ? 'url(#kc-arrow)' : 'url(#kc-arrow)'}/>
            </g>
          );
        })}

        {/* EXIT 101 box (red, unprotected) */}
        <g>
          <rect x={exitX} y={exitY} width={cellW * 0.9} height={cellH} rx="2"
            fill="rgba(255,59,92,.15)" stroke="#ff3b5c" strokeWidth="1.4"/>
          <text x={exitX + cellW*0.45} y={exitY + 26} textAnchor="middle" className="kc-text-l" fill="#ff7a8f">EXIT 101</text>
          <text x={exitX + cellW*0.45} y={exitY + 44} textAnchor="middle" className="kc-text-s" fill="#ff7a8f">UNPROTECTED</text>
        </g>
      </svg>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// V2 — Detail with files (Tabs + condensed sticky hero)
// ─────────────────────────────────────────────────────────────────────────────
function DetailV2Files({ onBack }) {
  const test = window.TESTS_DETAIL_AKIRA;
  const [activeTab, setActiveTab] = useStateD('readme');
  const [activeFile, setActiveFile] = useStateD('README.md');

  return (
    <>
      <DetailHero test={test} onBack={onBack} />

      {/* Tab strip below the hero */}
      <div className="tm-detail-tabs">
        {[
          { id: 'readme',     icon: TI.fileMd, label: 'Overview' },
          { id: 'source',     icon: TI.source, label: 'Source',     count: 5 },
          { id: 'detection',  icon: TI.detect, label: 'Detection',  count: 4 },
          { id: 'defense',    icon: TI.defense,label: 'Defense',    count: 2 },
          { id: 'killchain',  icon: TI.viz,    label: 'Kill Chain' },
          { id: 'refs',       icon: TI.refs,   label: 'References', count: 1 },
        ].map(t => (
          <button key={t.id} className={`tm-dtab ${activeTab === t.id ? 'is-active' : ''}`}
            onClick={() => setActiveTab(t.id)}>
            <Icon d={t.icon} size={11} />
            <span>{t.label}</span>
            {t.count != null && <span className="tm-dtab-count">{t.count}</span>}
          </button>
        ))}
      </div>

      <div className="tm-detail-shell tm-detail-v2">
        <FileTree
          groups={test.files.filter(g => ['Documentation', 'Build', 'Source Code', 'References'].includes(g.group))}
          activeFile={activeFile} onSelect={setActiveFile} />

        <section className="tm-viewer">
          <div className="tm-viewer-toolbar">
            <div className="tm-viewer-bc">
              <Icon d={TI.fileMd} size={11} style={{ color: 'var(--accent)' }} />
              <span className="font-mono">README.md</span>
              <span className="tm-viewer-bc-sep">·</span>
              <span className="tac-label">2.3 KB · markdown</span>
            </div>
            <div className="tm-viewer-tools">
              <button className="tm-iconbtn-lg" title="Copy">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
              </button>
              <button className="tm-iconbtn-lg" title="Download"><Icon d={TI.download} size={13} /></button>
            </div>
          </div>

          <article className="tm-readme">
            <h1>Akira Ransomware BYOVD Attack Chain (Hybrid Testing)</h1>
            <p className="tm-readme-meta"><strong>Test Score:</strong> 8.9/10</p>

            <h2>Overview</h2>
            <p>This VST simulates the Bring Your Own Vulnerable Driver (BYOVD) attack chain used by Akira ransomware to achieve privilege escalation and disable Windows Defender.</p>

            <blockquote className="tm-callout tm-callout-safety">
              <span className="tac-label">SAFETY</span>
              <p><strong>Hybrid Safety Model:</strong> Uses real vulnerable driver only for signature detection (3 seconds), then switches to simulated drivers for all behavioral testing.</p>
            </blockquote>

            <h2>Phase summary</h2>
            <div className="tm-readme-phasegrid">
              {[
                { n: 1, name: 'Privilege Check', state: 'pass', desc: 'Verify admin context; abort with NOTRELEVANT otherwise.' },
                { n: 2, name: 'Drop rwdrv.sys', state: 'pass', desc: 'Real vulnerable driver staged for signature detection.' },
                { n: 3, name: 'Defender Disable', state: 'run', desc: 'Registry manipulation via PowerShell.' },
                { n: 4, name: 'Sim Drivers', state: 'idle', desc: 'mgdsrv + KMHLPSVC services pointing at simulated drivers.' },
              ].map(p => (
                <div key={p.n} className={`tm-phase-card state-${p.state}`}>
                  <div className="tm-phase-head">
                    <span className="tm-phase-n">{String(p.n).padStart(2, '0')}</span>
                    <span className="tm-phase-name">{p.name}</span>
                    <span className={`tm-phase-state state-${p.state}`}>
                      {p.state === 'pass' ? '✓ pass' : p.state === 'run' ? '● running' : '— idle'}
                    </span>
                  </div>
                  <p className="tm-phase-desc">{p.desc}</p>
                </div>
              ))}
            </div>
          </article>
        </section>

        <aside className="tm-meta-rail">
          <div className="dash-card tm-meta-card">
            <div className="dash-card-head">
              <div className="dash-card-title"><span className="accent-dot" />Quick stats</div>
            </div>
            <div className="tm-meta-stats">
              {[
                { l: 'Stages',     v: '5' },
                { l: 'Phases',     v: '4' },
                { l: 'Techniques', v: '2' },
                { l: 'Files',      v: '15' },
                { l: 'Detections', v: '4' },
                { l: 'Platforms',  v: 'Windows' },
              ].map(s => (
                <div key={s.l} className="tm-meta-stat">
                  <span className="mono-label">{s.l}</span>
                  <span className="tm-meta-stat-v">{s.v}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="dash-card tm-meta-card">
            <div className="dash-card-head">
              <div className="dash-card-title"><span className="accent-dot" />Detection coverage</div>
            </div>
            <div className="tm-detect-list">
              {[
                { kind: 'KQL',     n: 1, color: '#4f8eff' },
                { kind: 'Elastic', n: 1, color: '#22d3ee' },
                { kind: 'YARA',    n: 1, color: '#ffaa2e' },
                { kind: 'Sigma',   n: 1, color: '#a78bfa' },
              ].map(d => (
                <div key={d.kind} className="tm-detect-row">
                  <span className="tm-detect-tag" style={{ color: d.color }}>{d.kind}</span>
                  <span className="tm-detect-bar"><span style={{ width: '78%', background: d.color }} /></span>
                  <span className="tm-detect-n">{d.n} rule</span>
                </div>
              ))}
            </div>
          </div>

          <div className="dash-card tm-meta-card">
            <div className="dash-card-head">
              <div className="dash-card-title"><span className="accent-dot" />Build</div>
            </div>
            <div className="tm-build-block">
              <div className="tm-build-row">
                <span className="tac-label">Target</span>
                <span className="tm-tree-target-pill">windows/amd64</span>
              </div>
              <div className="tm-build-row">
                <span className="tac-label">Binary</span>
                <span className="font-mono tm-build-bin">rwdrv.sys</span>
              </div>
              <div className="tm-build-row">
                <span className="tac-label">Status</span>
                <span className="tm-build-status">
                  <span className="dot dot-pulse" style={{ background: 'var(--accent)' }} />
                  signed · ready
                </span>
              </div>
              <button className="tm-tree-action primary" style={{ marginTop: 8, width: '100%' }}>Build & Sign</button>
            </div>
          </div>
        </aside>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// V2 — Detail with Kill Chain (vertical timeline, no separate stage cards)
// ─────────────────────────────────────────────────────────────────────────────
function DetailV2Killchain({ onBack }) {
  const test = window.TESTS_DETAIL_APT34;
  const [activeFile, setActiveFile] = useStateD('Kill Chain Diagram');

  return (
    <>
      <DetailHero test={test} onBack={onBack} condensed />

      <div className="tm-detail-tabs">
        {[
          { id: 'overview',  icon: TI.fileMd, label: 'Overview' },
          { id: 'killchain', icon: TI.viz,    label: 'Kill Chain', active: true },
          { id: 'source',    icon: TI.source, label: 'Source',     count: 6 },
          { id: 'detection', icon: TI.detect, label: 'Detection',  count: 4 },
          { id: 'defense',   icon: TI.defense,label: 'Defense',    count: 2 },
        ].map(t => (
          <button key={t.id} className={`tm-dtab ${t.active ? 'is-active' : ''}`}>
            <Icon d={t.icon} size={11} />
            <span>{t.label}</span>
            {t.count != null && <span className="tm-dtab-count">{t.count}</span>}
          </button>
        ))}
      </div>

      <div className="tm-detail-shell tm-detail-v2-kc">
        {/* Left: vertical timeline of stages */}
        <aside className="tm-kc-timeline">
          <div className="tm-kc-timeline-head">
            <span className="tac-label">Kill Chain · 4 stages</span>
          </div>
          {test.stageCards.map((s, i) => {
            const stage = test.killChain.stages[i];
            return (
              <div key={s.n} className="tm-kc-tl-row" style={{ '--stage-color': s.color }}>
                <div className="tm-kc-tl-spine">
                  <span className="tm-kc-tl-n" style={{ background: s.color }}>{s.n}</span>
                  {i < test.stageCards.length - 1 && <span className="tm-kc-tl-line" />}
                </div>
                <div className="tm-kc-tl-body">
                  <div className="tm-kc-tl-head">
                    <span className="tm-kc-tl-name">{s.name}</span>
                    <span className={`tm-kc-tl-state state-${stage.protected}`}>
                      {stage.protected === 'protected' ? '✓ blocked' : '⨯ unprotected'}
                    </span>
                  </div>
                  <div className="tm-kc-tl-tech">
                    <span className="tm-tech tm-tech-stage" style={{ '--tt-color': s.color }}>{s.tid}</span>
                    <span className="tm-kc-tl-tactic">{s.tactic}</span>
                  </div>
                  <p className="tm-kc-tl-desc">{s.desc}</p>
                  <div className="tm-kc-tl-tags">
                    {s.tags.map(tag => <span key={tag} className="tm-kc-stage-tag">{tag}</span>)}
                  </div>
                </div>
              </div>
            );
          })}
        </aside>

        {/* Right: native diagram + summary */}
        <section className="tm-viewer tm-kc-viewer">
          <div className="tm-kc-summary">
            <div className="tm-kc-summary-stat">
              <span className="tac-label">Outcome</span>
              <span className="tm-kc-summary-val tm-unprotected">UNPROTECTED · EXIT 101</span>
            </div>
            <div className="tm-kc-summary-stat">
              <span className="tac-label">Stages blocked</span>
              <span className="tm-kc-summary-val">3 / 4</span>
            </div>
            <div className="tm-kc-summary-stat">
              <span className="tac-label">Weak point</span>
              <span className="tm-kc-summary-val tm-warn">Stage 3 · Password Filter</span>
            </div>
            <div className="tm-kc-summary-stat">
              <span className="tac-label">Tactics covered</span>
              <span className="tm-kc-summary-val">4</span>
            </div>
          </div>

          <KillChainDiagram chain={test.killChain} />

          <div className="tm-kc-tech-strip tm-kc-tech-strip-v2">
            {test.techniques.map(t => (
              <div key={t.id} className="tm-kc-tech-card">
                <span className="tm-kc-tech-id">{t.id}</span>
                <span className="tm-kc-tech-name">{t.name}</span>
                <span className="tac-label tm-kc-tech-tactic">{t.tactic}</span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  );
}

window.DetailV1Files = DetailV1Files;
window.DetailV1Killchain = DetailV1Killchain;
window.DetailV2Files = DetailV2Files;
window.DetailV2Killchain = DetailV2Killchain;