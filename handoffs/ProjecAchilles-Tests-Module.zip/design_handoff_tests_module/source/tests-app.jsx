/* global React, ReactDOM, DesignCanvas, DCSection, DCArtboard,
   TestShell, BrowseGrid, BrowseList, DetailV1Files, DetailV1Killchain,
   DetailV2Files, DetailV2Killchain */
const { createRoot: createRootT } = ReactDOM;
const { useState: useStateT } = React;

// Each artboard wraps a stateful Test page that can navigate within itself
// (Browse → Detail) so users can click cards and see the flow.
function TestModule({ initialPage, initialView }) {
  const [page, setPage] = useStateT(initialPage); // 'browse' | 'detail-files' | 'detail-kc'
  const handleOpen = (test) => {
    // Route by content shape — kill-chain detail for APT34/multi-stage tests
    if (test && test.uuid === 'e7f8-apt34') setPage('detail-kc');
    else setPage('detail-files');
  };
  const goBack = () => setPage(initialPage);

  if (page === 'browse') {
    if (initialView === 'list') {
      return (
        <TestShell activeKey="tests:browse" title="Tests · Browse">
          <BrowseList onOpen={handleOpen} />
        </TestShell>
      );
    }
    return (
      <TestShell activeKey="tests:browse" title="Tests · Browse">
        <BrowseGrid onOpen={handleOpen} />
      </TestShell>
    );
  }

  if (page === 'detail-files') {
    return (
      <TestShell activeKey="tests:browse" title="Tests · Detail">
        {initialView === 'v2'
          ? <DetailV2Files onBack={goBack} />
          : <DetailV1Files onBack={goBack} />}
      </TestShell>
    );
  }

  if (page === 'detail-kc') {
    return (
      <TestShell activeKey="tests:browse" title="Tests · Kill Chain">
        {initialView === 'v2'
          ? <DetailV2Killchain onBack={goBack} />
          : <DetailV1Killchain onBack={goBack} />}
      </TestShell>
    );
  }
  return null;
}

function TestApp() {
  return (
    <DesignCanvas
      title="Achilles · Tests Module Redesign"
      subtitle="Browse + Detail · 3 surfaces · click any card to drill in."
      backgroundColor="#02040a"
    >
      <DCSection id="browse" title="Browse Tests · Faceted List">
        <DCArtboard id="browse-list" label="Browse — Faceted List" width={1440} height={1100} background="var(--bg-deep)">
          <TestModule initialPage="browse" initialView="list" />
        </DCArtboard>
      </DCSection>

      <DCSection id="detail-files" title="Test Detail · README & Files">
        <DCArtboard id="detail-files-v1" label="File Tree + Stage Pipeline + Markdown" width={1440} height={1100} background="var(--bg-deep)">
          <TestModule initialPage="detail-files" initialView="v1" />
        </DCArtboard>
      </DCSection>

      <DCSection id="detail-kc" title="Test Detail · Kill Chain (APT34 OilRig)">
        <DCArtboard id="detail-kc-v2" label="Vertical Timeline + Outcome Summary" width={1440} height={1100} background="var(--bg-deep)">
          <TestModule initialPage="detail-kc" initialView="v2" />
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

createRootT(document.getElementById('root')).render(<TestApp />);