/* global React, Icon, I, TI, TestShell, TestSyncRow, PageTabs, FilterDropdown, ViewToggle, SevPill, ScoreBadge, PlatformBadge, TechBadge */
const { useState: useStateB, useMemo: useMemoB } = React;

// ─────────────────────────────────────────────────────────────────────────────
// Test Card (V1 — polished tactical)
// ─────────────────────────────────────────────────────────────────────────────
function TestCardV1({ test, onOpen, fav, onFav }) {
  return (
    <div className="tm-card" onClick={() => onOpen && onOpen(test)}>
      <div className="tm-card-top">
        <h3 className="tm-card-title">{test.name}</h3>
        <div className="tm-card-actions">
          <button className="tm-iconbtn" title={fav ? 'Unfavorite' : 'Favorite'}
            onClick={(e) => { e.stopPropagation(); onFav && onFav(test); }}>
            <svg width="13" height="13" viewBox="0 0 24 24"
              fill={fav ? '#ff7a8f' : 'none'} stroke={fav ? '#ff7a8f' : 'currentColor'} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
            </svg>
          </button>
          <button className="tm-iconbtn" title="Run test" onClick={(e) => e.stopPropagation()}>
            <Icon d={TI.play} size={12} fill="currentColor" sw={0} />
          </button>
          <ScoreBadge score={test.score} />
        </div>
      </div>

      <div className="tm-card-meta">
        <SevPill sev={test.severity} />
        <span className="tm-meta-divider" />
        <span className="tm-meta-stages">
          <Icon d={TI.layers} size={11} />
          <span>{test.stages} stage{test.stages > 1 ? 's' : ''}</span>
        </span>
        {test.platforms.slice(0, 3).map(p => <PlatformBadge key={p} p={p} />)}
        {test.platforms.length > 3 && <span className="tm-meta-more">+{test.platforms.length - 3}</span>}
      </div>

      {test.description && (
        <p className="tm-card-desc">{test.description}</p>
      )}

      <div className="tm-card-techs">
        {test.techniques.slice(0, 4).map(t => <TechBadge key={t} t={t} />)}
        {test.techniques.length > 4 && <span className="tm-tech tm-tech-more">+{test.techniques.length - 4} more</span>}
      </div>

      <div className="tm-card-foot">
        {test.tags.map((tag, i) => (
          <span key={i} className={`tm-tag tm-tag-${tag.toLowerCase().replace(/\s+/g, '')}`}>
            <span className="tm-tag-dot" />{tag}
          </span>
        ))}
        <span className="tm-card-when">mod {test.modified}</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Filter / sort bar shared between V1 and V2
// ─────────────────────────────────────────────────────────────────────────────
function BrowseToolbar({ data, viewMode, onViewMode, sort, onSort, total, nry, onNry }) {
  return (
    <div className="tm-toolbar">
      <FilterDropdown label="All Categories" />
      <FilterDropdown label="All Severities" />
      <FilterDropdown label="All Platforms" />
      <FilterDropdown label="All Actors" />

      <div className="tm-toolbar-divider" />

      <label className="tm-nry">
        <span className={`tm-switch ${nry ? 'is-on' : ''}`} onClick={() => onNry && onNry(!nry)}>
          <span className="tm-switch-knob" />
        </span>
        <span className="tm-nry-label">Not run yet</span>
      </label>

      <div className="tm-toolbar-spacer" />

      <button className="tm-sort">
        <span className="tac-label">Sort</span>
        <span className="tm-sort-field">{sort}</span>
        <Icon d={I.arrow} size={10} sw={2} style={{ transform: 'rotate(90deg)' }} />
      </button>
      <button className="tm-iconbtn-lg" title="Sort direction">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M3 6h13"/><path d="M3 12h9"/><path d="M3 18h6"/>
          <path d="M16 16l4 4 4-4"/><path d="M20 4v16"/>
        </svg>
      </button>

      <ViewToggle mode={viewMode} onChange={onViewMode} />

      <button className="tm-iconbtn-lg tm-select-btn">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <rect x="3" y="3" width="18" height="18" rx="2"/><polyline points="9 11 12 14 22 4"/>
        </svg>
        <span>Select</span>
      </button>

      <span className="tm-total">{total} of 53 tests</span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// V1 — Browse Grid
// ─────────────────────────────────────────────────────────────────────────────
function BrowseGrid({ onOpen }) {
  const D = window.TESTS_DATA;
  const [viewMode, setViewMode] = useStateB('grid');
  const [sort, setSort] = useStateB('Created');
  const [nry, setNry] = useStateB(false);
  const [favs, setFavs] = useStateB(new Set(['d4e5-bluehammer', 'b8c9-unkrobot']));
  const toggleFav = (t) => {
    const next = new Set(favs);
    if (next.has(t.uuid)) next.delete(t.uuid); else next.add(t.uuid);
    setFavs(next);
  };

  return (
    <>
      <TestSyncRow />
      <PageTabs
        active="browse"
        tabs={[
          { id: 'overview', icon: I.layout, label: 'Overview' },
          { id: 'browse',   icon: I.grid,   label: 'Browse', count: 53 },
        ]}
      />

      <div className="tm-search-row">
        <div className="tm-search-input">
          <Icon d={I.search} size={14} />
          <input placeholder="Search by name, UUID, technique, or description…" />
        </div>
      </div>

      <BrowseToolbar
        viewMode={viewMode} onViewMode={setViewMode}
        sort={sort} onSort={setSort}
        total={D.tests.length}
        nry={nry} onNry={setNry}
      />

      <div className="tm-cardgrid">
        {D.tests.map(t => (
          <TestCardV1 key={t.uuid} test={t} onOpen={onOpen}
            fav={favs.has(t.uuid)} onFav={toggleFav} />
        ))}
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// V2 — Browse List (dense table-style with faceted filters in left rail)
// ─────────────────────────────────────────────────────────────────────────────
function BrowseList({ onOpen }) {
  const D = window.TESTS_DATA;
  const [viewMode, setViewMode] = useStateB('list');
  const [sort, setSort] = useStateB('Score');
  const [nry, setNry] = useStateB(false);
  const [activeFacet, setActiveFacet] = useStateB({ category: 'all', severity: 'all' });

  return (
    <>
      <TestSyncRow />
      <PageTabs
        active="browse"
        tabs={[
          { id: 'overview', icon: I.layout, label: 'Overview' },
          { id: 'browse',   icon: I.grid,   label: 'Browse', count: 53 },
        ]}
      />

      <div className="tm-list-shell">
        {/* Left facet rail */}
        <aside className="tm-facets">
          <div className="tm-facet-head">
            <span className="tac-label">Filters</span>
            <button className="tm-facet-clear">Clear all</button>
          </div>

          <div className="tm-facet-group">
            <div className="tm-facet-title">Category</div>
            {D.filters.categories.map(c => (
              <button key={c.id}
                className={`tm-facet-row ${activeFacet.category === c.id ? 'is-active' : ''}`}
                onClick={() => setActiveFacet({ ...activeFacet, category: c.id })}>
                <span className="tm-facet-label">{c.label}</span>
                <span className="tm-facet-count">{c.count}</span>
              </button>
            ))}
          </div>

          <div className="tm-facet-group">
            <div className="tm-facet-title">Severity</div>
            {D.filters.severities.map(s => (
              <button key={s.id}
                className={`tm-facet-row ${activeFacet.severity === s.id ? 'is-active' : ''}`}
                onClick={() => setActiveFacet({ ...activeFacet, severity: s.id })}>
                {s.id !== 'all' && <span className={`tm-facet-dot sev-bg-${s.id}`} />}
                <span className="tm-facet-label">{s.label}</span>
                <span className="tm-facet-count">{s.count}</span>
              </button>
            ))}
          </div>

          <div className="tm-facet-group">
            <div className="tm-facet-title">Platform</div>
            {D.filters.platforms.slice(1).map(p => (
              <button key={p.id} className="tm-facet-row">
                <span className="tm-facet-label">{p.label}</span>
                <span className="tm-facet-count">{p.count}</span>
              </button>
            ))}
          </div>

          <div className="tm-facet-group">
            <div className="tm-facet-title">Threat Actor</div>
            {D.filters.actors.slice(1, 6).map(a => (
              <button key={a.id} className="tm-facet-row">
                <span className="tm-facet-label">{a.label}</span>
              </button>
            ))}
            <button className="tm-facet-more">+ 3 more actors</button>
          </div>
        </aside>

        {/* Right list pane */}
        <section className="tm-list-pane">
          <div className="tm-search-row">
            <div className="tm-search-input">
              <Icon d={I.search} size={14} />
              <input placeholder="Search by name, UUID, technique, or description…" />
            </div>
          </div>

          <div className="tm-toolbar tm-toolbar-list">
            <label className="tm-nry">
              <span className={`tm-switch ${nry ? 'is-on' : ''}`} onClick={() => setNry(!nry)}>
                <span className="tm-switch-knob" />
              </span>
              <span className="tm-nry-label">Not run yet</span>
            </label>
            <div className="tm-toolbar-spacer" />
            <button className="tm-sort">
              <span className="tac-label">Sort</span>
              <span className="tm-sort-field">{sort}</span>
              <Icon d={I.arrow} size={10} sw={2} style={{ transform: 'rotate(90deg)' }} />
            </button>
            <ViewToggle mode={viewMode} onChange={setViewMode} />
            <span className="tm-total">{D.tests.length} of 53</span>
          </div>

          <div className="tm-list">
            <div className="tm-list-head">
              <div className="tm-col-name">Test</div>
              <div className="tm-col-sev">Severity</div>
              <div className="tm-col-plat">Platform</div>
              <div className="tm-col-tech">Top Techniques</div>
              <div className="tm-col-mod">Modified</div>
              <div className="tm-col-score">Score</div>
              <div className="tm-col-actions" />
            </div>
            {D.tests.map((t, idx) => (
              <div key={t.uuid} className="tm-list-row" onClick={() => onOpen && onOpen(t)}>
                <div className="tm-col-name">
                  <span className="tm-list-rank">{String(idx + 1).padStart(2, '0')}</span>
                  <div className="tm-list-name-stack">
                    <div className="tm-list-name">{t.name}</div>
                    <div className="tm-list-sub">
                      <span className="font-mono">{t.uuid}</span>
                      <span>·</span>
                      <span>{t.category}</span>
                      <span>·</span>
                      <span>
                        <Icon d={TI.layers} size={10} style={{ marginRight: 3, verticalAlign: -1 }} />
                        {t.stages} stage{t.stages > 1 ? 's' : ''}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="tm-col-sev"><SevPill sev={t.severity} /></div>
                <div className="tm-col-plat">
                  {t.platforms.slice(0, 2).map(p => <PlatformBadge key={p} p={p} />)}
                  {t.platforms.length > 2 && <span className="tm-meta-more">+{t.platforms.length - 2}</span>}
                </div>
                <div className="tm-col-tech">
                  {t.techniques.slice(0, 3).map(tech => <TechBadge key={tech} t={tech} />)}
                  {t.techniques.length > 3 && <span className="tm-tech tm-tech-more">+{t.techniques.length - 3}</span>}
                </div>
                <div className="tm-col-mod">{t.modified}</div>
                <div className="tm-col-score"><ScoreBadge score={t.score} /></div>
                <div className="tm-col-actions">
                  <button className="tm-iconbtn" onClick={(e) => e.stopPropagation()}>
                    <Icon d={TI.play} size={11} fill="currentColor" sw={0} />
                  </button>
                  <button className="tm-iconbtn" onClick={(e) => e.stopPropagation()}>
                    <Icon d={TI.more} size={13} fill="currentColor" sw={0} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  );
}

window.BrowseGrid = BrowseGrid;
window.BrowseList = BrowseList;