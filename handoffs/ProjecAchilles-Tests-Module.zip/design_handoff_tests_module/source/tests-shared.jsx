/* global React, Icon, I */
const { useState, useMemo, useCallback } = React;

// ── Icons specific to the Test Module ────────────────────────────────────────
const TI = {
  heart:   <><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></>,
  play:    <><polygon points="6 4 20 12 6 20 6 4"/></>,
  layers:  <><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></>,
  back:    <><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></>,
  fav:     <><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></>,
  fileMd:  <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></>,
  folder:  <><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"/></>,
  build:   <><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></>,
  refs:    <><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></>,
  source:  <><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></>,
  detect:  <><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></>,
  defense: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></>,
  viz:     <><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></>,
  config:  <><path d="M4 21v-7"/><path d="M4 10V3"/><path d="M12 21V12"/><path d="M12 8V3"/><path d="M20 21v-5"/><path d="M20 12V3"/><path d="M1 14h6"/><path d="M9 8h6"/><path d="M17 16h6"/></>,
  upload:  <><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></>,
  collapse:<><polyline points="6 9 12 15 18 9"/></>,
  expand:  <><polyline points="9 18 15 12 9 6"/></>,
  list:    <><line x1="8" y1="6"  x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></>,
  exit:    <><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></>,
  download:<><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></>,
  more:    <><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></>,
};

// ── Sidebar adjusted for Tests as the active module ────────────────────────
function TestSidebar({ activeKey, onNav }) {
  const items = [
    { group: 'Tests', icon: I.flask, expanded: true, items: [
      { key: 'tests:dashboard', icon: I.layout, label: 'Dashboard' },
      { key: 'tests:browse',    icon: I.grid,   label: 'Browse All' },
      { key: 'tests:favorites', icon: I.star,   label: 'Favorites' },
    ]},
    { group: 'Analytics', icon: I.chart, items: [
      { key: 'analytics:dashboard',  icon: I.layout, label: 'Dashboard' },
      { key: 'analytics:executions', icon: I.play,   label: 'Executions' },
    ]},
    { group: 'Endpoints', icon: I.monitor, items: [
      { key: 'endpoints:dashboard', icon: I.layout, label: 'Dashboard' },
      { key: 'endpoints:agents',    icon: I.bot,    label: 'Agents' },
      { key: 'endpoints:tasks',     icon: I.task,   label: 'Tasks' },
    ]},
  ];
  return (
    <aside className="dash-sidebar" style={{ '--side-accent': 'var(--accent)' }}>
      <div className="dash-sidebar-logo">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L4 6v6c0 5 3.5 9 8 10 4.5-1 8-5 8-10V6l-8-4z"
            stroke="var(--accent)" strokeWidth="1.8"/>
          <path d="M9 12l2 2 4-4" stroke="var(--accent)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        <span className="dash-sidebar-brand">ACHILLES</span>
      </div>

      <div className="dash-sidebar-section-title">Modules</div>
      {items.map(g => (
        <div key={g.group} className="dash-sidebar-group">
          <div className="dash-sidebar-group-head">
            <Icon d={g.icon} size={14} />
            <span>{g.group}</span>
          </div>
          <ul>
            {g.items.map(it => {
              const active = activeKey === it.key;
              return (
                <li key={it.key} className={active ? 'is-active' : ''}
                    onClick={() => onNav && onNav(it.key)}>
                  <Icon d={it.icon} size={14} />
                  <span>{it.label}</span>
                  {active && <span className="dash-sidebar-active-bar" />}
                </li>
              );
            })}
          </ul>
        </div>
      ))}

      <div className="dash-sidebar-foot">
        <button className="dash-sidebar-settings">
          <Icon d={I.cog} size={14} />
          <span>Settings</span>
        </button>
      </div>
    </aside>
  );
}

// ── Severity pill ──────────────────────────────────────────────────────────
function SevPill({ sev, size = 'sm' }) {
  return <span className={`sev-pill sev-bg-${sev} sev-${size}`}>{sev}</span>;
}

// ── Score badge (gold trophy + score) ──────────────────────────────────────
function ScoreBadge({ score, size = 'sm' }) {
  return (
    <span className={`tm-score-badge tm-score-${size}`}>
      <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
      <span>{score.toFixed(1)}</span>
    </span>
  );
}

// ── Platform badge ─────────────────────────────────────────────────────────
function PlatformBadge({ p }) {
  const map = {
    win:   { label: 'Win',     icon: '⊞', color: '#4f8eff' },
    lin:   { label: 'Linux',   icon: '◯', color: '#ffc857' },
    mac:   { label: 'macOS',   icon: '◇', color: '#f0f2f5' },
    ad:    { label: 'AD',      icon: '◎', color: '#a78bfa' },
    aws:   { label: 'AWS',     icon: '◬', color: '#ffaa2e' },
    gcp:   { label: 'GCP',     icon: '◬', color: '#22d3ee' },
    azure: { label: 'Azure',   icon: '◬', color: '#4f8eff' },
    entra: { label: 'Entra',   icon: '◎', color: '#a78bfa' },
  };
  const m = map[p] || { label: p, icon: '◯', color: 'var(--text-muted)' };
  return (
    <span className="tm-plat" title={m.label}>
      <span className="tm-plat-glyph" style={{ color: m.color }}>{m.icon}</span>
      <span>{m.label}</span>
    </span>
  );
}

// ── Technique badge ────────────────────────────────────────────────────────
function TechBadge({ t, color = 'var(--accent)' }) {
  return <span className="tm-tech" style={{ '--tt-color': color }}>{t}</span>;
}

// ── Top bar specific to Tests pages ────────────────────────────────────────
function TestTopBar({ title }) {
  return (
    <header className="dash-topbar">
      <div className="dash-topbar-left">
        <div className="dash-topbar-title">{title}</div>
        <div className="dash-topbar-search">
          <Icon d={I.search} size={14} />
          <input placeholder="Search tests, agents, tasks…" />
          <span className="dash-topbar-kbd">⌘K</span>
        </div>
      </div>
      <div className="dash-topbar-right">
        <button className="dash-icon-btn"><Icon d={I.bell} size={16} /></button>
        <button className="dash-icon-btn"><Icon d={I.cmd} size={16} /></button>
        <div className="dash-theme-pill">Tactical Dark ▾</div>
        <div className="dash-user-chip">
          <span className="tac-label" style={{ color: 'var(--accent)' }}>Administrator</span>
          <div className="dash-user-avatar">J</div>
        </div>
      </div>
    </header>
  );
}

// ── Sync row (branch + sync now) shared across all Tests pages ─────────────
function TestSyncRow() {
  const D = window.TESTS_DATA;
  return (
    <div className="tm-syncrow">
      <div className="tm-sync-left">
        <span className="dot dot-pulse" style={{ background: 'var(--accent)', color: 'var(--accent)' }} />
        <span className="font-mono tm-sync-branch">main</span>
        <span className="font-mono tm-sync-sha">({D.commit})</span>
        <Icon d={I.clock} size={11} style={{ color: 'var(--text-muted)' }} />
        <span className="font-mono tm-sync-when">{D.syncedAgo}</span>
      </div>
      <button className="dash-quick-btn primary tm-sync-btn">
        <Icon d={I.sync} size={12} /><span>Sync</span>
      </button>
    </div>
  );
}

// ── Tabs (Overview / Browse) ───────────────────────────────────────────────
function PageTabs({ tabs, active, onChange }) {
  return (
    <div className="tm-tabs">
      {tabs.map(t => (
        <button key={t.id}
          className={`tm-tab ${active === t.id ? 'is-active' : ''}`}
          onClick={() => onChange && onChange(t.id)}>
          <Icon d={t.icon} size={12} />
          <span>{t.label}</span>
          {t.count != null && <span className="tm-tab-count">{t.count}</span>}
        </button>
      ))}
    </div>
  );
}

// ── Filter dropdown (visual only) ──────────────────────────────────────────
function FilterDropdown({ label, value, count }) {
  return (
    <button className="tm-filter">
      <span className="tm-filter-label">{label}</span>
      {count != null && <span className="tm-filter-count">{count}</span>}
      <Icon d={I.arrow} size={10} sw={2} style={{ transform: 'rotate(90deg)' }} />
    </button>
  );
}

// ── View mode toggle (grid | list) ─────────────────────────────────────────
function ViewToggle({ mode, onChange }) {
  return (
    <div className="tm-viewtoggle">
      <button className={`tm-vt ${mode === 'grid' ? 'is-active' : ''}`} onClick={() => onChange && onChange('grid')} title="Grid">
        <Icon d={I.grid} size={13} />
      </button>
      <button className={`tm-vt ${mode === 'list' ? 'is-active' : ''}`} onClick={() => onChange && onChange('list')} title="List">
        <Icon d={TI.list} size={13} />
      </button>
    </div>
  );
}

// ── Common page shell wrapper ──────────────────────────────────────────────
function TestShell({ activeKey, title, onNav, children, label }) {
  return (
    <div className="dash-shell" data-screen-label={label || title}>
      <TestSidebar activeKey={activeKey} onNav={onNav} />
      <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <TestTopBar title={title} />
        <main className="tm-main">
          {children}
        </main>
      </div>
    </div>
  );
}

Object.assign(window, {
  TI, TestSidebar, SevPill, ScoreBadge, PlatformBadge, TechBadge,
  TestTopBar, TestSyncRow, PageTabs, FilterDropdown, ViewToggle, TestShell,
});