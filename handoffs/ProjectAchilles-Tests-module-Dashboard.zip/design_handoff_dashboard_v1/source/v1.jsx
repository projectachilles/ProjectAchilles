/* global React, D, Sidebar, TopBar, BranchPill, QuickActions, Sparkline, TerminalPanel, Icon, I */
const { useState, useMemo } = React;

// ─────────────────────────────────────────────────────────────────────────────
// VARIATION 1 — TACTICAL GREEN · COMMAND CENTER
// ─────────────────────────────────────────────────────────────────────────────
function MitreMatrix({ accent = '#00e68a' }) {
  const [filter, setFilter] = useState('all');
  // Build deterministic cells per tactic
  const cells = (t) => {
    const arr = [];
    for (let i = 0; i < t.techniques; i++) {
      const seed = (t.id.charCodeAt(0) + i * 7) % 100;
      let kind = 'gap';
      if (i < t.covered) kind = 'covered';else
      if (seed > 70) kind = 'partial';
      arr.push(kind);
    }
    return arr;
  };
  const visible = (kind) => {
    if (filter === 'all') return true;
    if (filter === 'covered') return kind === 'covered';
    if (filter === 'gaps') return kind === 'gap' || kind === 'partial';
    return true;
  };

  return (
    <div className="v1-mitre">
      <div className="v1-mitre-head">
        <div className="v1-mitre-title-row">
          <div className="v1-mitre-title">MITRE ATT&CK · COVERAGE</div>
          <div className="v1-mitre-stats">
            <div className="v1-mitre-stat"><strong>116</strong> techniques</div>
            <div className="v1-mitre-stat"><strong>12 / 14</strong> tactics</div>
            <div className="v1-mitre-stat"><strong>53</strong> mapped</div>
          </div>
        </div>
        <div className="v1-mitre-chips">
          {['all', 'covered', 'gaps'].map((k) =>
          <button key={k} className={`v1-chip ${filter === k ? 'active' : ''}`} onClick={() => setFilter(k)}>
              {k}
            </button>
          )}
        </div>
      </div>

      <div className="v1-matrix">
        {D.tactics_data.map((t) => {
          const pct = Math.round(t.covered / t.techniques * 100);
          return (
            <div key={t.id} className="v1-matrix-col">
              <div className="v1-matrix-head">
                {t.id}
                <span className="pct">{pct}%</span>
              </div>
              <div className="cells">
                {cells(t).map((k, i) =>
                <div key={i}
                className={`v1-matrix-cell ${k}`}
                style={{ opacity: visible(k) ? undefined : 0.15 }}
                title={`${t.name} — ${k}`} />

                )}
              </div>
            </div>);

        })}
      </div>

      <div className="v1-mitre-legend">
        <div className="v1-mitre-legend-item">
          <span className="v1-mitre-legend-sw" style={{ background: accent, opacity: .9 }} /> covered
        </div>
        <div className="v1-mitre-legend-item">
          <span className="v1-mitre-legend-sw" style={{ background: accent, opacity: .35 }} /> partial
        </div>
        <div className="v1-mitre-legend-item">
          <span className="v1-mitre-legend-sw" style={{ background: 'rgba(255,59,92,.2)' }} /> gap
        </div>
        <div style={{ marginLeft: 'auto', color: 'var(--text-faint)' }}>click a column to drill into a tactic →</div>
      </div>
    </div>);

}

function GapsPanel() {
  return (
    <div className="v1-gaps">
      <div className="v1-gaps-head">
        <Icon d={I.alert} size={14} style={{ color: '#ff7a8f' }} />
        <div className="v1-gaps-title">Coverage gap · 3 weakest tactics</div>
      </div>
      {D.gaps.map((g) =>
      <div key={g.id} className="v1-gap-row">
          <div className="v1-gap-id">{g.id}</div>
          <div className="v1-gap-name">{g.name}</div>
          <div className="v1-gap-bar"><div style={{ width: `${g.pct}%` }} /></div>
          <div className="v1-gap-pct">{g.pct}%</div>
        </div>
      )}
    </div>);

}

function SeverityCard() {
  const total = D.critical + D.high + D.medium + D.low;
  const segs = [
  { k: 'critical', n: D.critical, c: 'var(--danger)' },
  { k: 'high', n: D.high, c: 'var(--warn-bright)' },
  { k: 'medium', n: D.medium, c: 'var(--signal)' },
  { k: 'low', n: D.low, c: 'rgba(255,255,255,.18)' }];

  return (
    <div className="dash-card">
      <div className="dash-card-head">
        <div className="dash-card-title"><span className="accent-dot" />Severity Distribution</div>
        <div className="mono-label">{total} tests</div>
      </div>
      <div className="v1-sev-bar-wrap">
        {segs.map((s) =>
        <div key={s.k} className="v1-sev-bar"
        style={{ width: `${s.n / total * 100}%`, background: s.c }}>
            {s.n}
          </div>
        )}
      </div>
      <div className="v1-sev-rows" style={{ marginTop: 14 }}>
        {segs.map((s) =>
        <div key={s.k} className="v1-sev-row">
            <span className="sw" style={{ background: s.c }} />
            <span className="label">{s.k}</span>
            <span className="num">{s.n}</span>
          </div>
        )}
      </div>
    </div>);

}

function CategoryDonut() {
  const total = D.category_data.reduce((s, c) => s + c.count, 0);
  const r = 38,c = 2 * Math.PI * r;
  let off = 0;
  return (
    <div className="dash-card">
      <div className="dash-card-head">
        <div className="dash-card-title"><span className="accent-dot" />Category Breakdown</div>
        <div className="mono-label">{D.categories} cats</div>
      </div>
      <div className="v1-donut-wrap">
        <svg width="110" height="110" viewBox="0 0 110 110">
          <circle cx="55" cy="55" r={r} fill="none" stroke="rgba(255,255,255,.05)" strokeWidth="14" />
          {D.category_data.map((cat, i) => {
            const len = cat.count / total * c;
            const dash = `${len} ${c - len}`;
            const el =
            <circle key={cat.id} cx="55" cy="55" r={r} fill="none"
            stroke={cat.color} strokeWidth="14"
            strokeDasharray={dash} strokeDashoffset={-off}
            transform="rotate(-90 55 55)"
            style={{ transition: 'all .8s' }} />;

            off += len;
            return el;
          })}
          <text x="55" y="58" textAnchor="middle"
          fontFamily="var(--font-display)" fontWeight="700"
          fontSize="20" fill="var(--text-primary)">{total}</text>
        </svg>
        <div className="v1-donut-legend">
          {D.category_data.map((cat) =>
          <div key={cat.id} className="v1-donut-row">
              <div className="lhs">
                <span className="sw" style={{ background: cat.color }} />
                <span className="name">{cat.name}</span>
              </div>
              <span className="val">{cat.count}</span>
            </div>
          )}
        </div>
      </div>
    </div>);

}

function KPI({ icon, label, value, trend, foot, sparkColor, sparkData }) {
  return (
    <div className="v1-kpi">
      <div className="v1-kpi-head">
        <div className="v1-kpi-label">
          <span className="iconbox"><Icon d={icon} size={12} /></span>
          <span>{label}</span>
        </div>
        <div className="v1-kpi-trend"><Icon d={I.arrowU} size={10} sw={2.4} />{trend}</div>
      </div>
      <div className="v1-kpi-value">{value}</div>
      <div className="v1-kpi-foot">
        <span>{foot}</span>
        <Sparkline data={sparkData} color={sparkColor} w={80} h={22} />
      </div>
    </div>);

}

function TopRated() {
  return (
    <div className="dash-card">
      <div className="dash-card-head">
        <div className="dash-card-title"><Icon d={I.star} size={12} />Top Rated</div>
        <div className="mono-label">last 30d</div>
      </div>
      {D.topRated.slice(0, 6).map((t, i) =>
      <div key={t.id} className="v1-test-row">
          <span className="v1-test-rank">{String(i + 1).padStart(2, '0')}</span>
          <span className="v1-test-name">{t.name}</span>
          <span className={`sev-pill sev-bg-${t.severity}`}>{t.severity}</span>
          <span className="v1-test-score">{t.score}</span>
        </div>
      )}
    </div>);

}

function RecentlyMod() {
  return (
    <div className="dash-card">
      <div className="dash-card-head">
        <div className="dash-card-title"><Icon d={I.clock} size={12} />Recently Modified</div>
        <div className="mono-label">today</div>
      </div>
      {D.recentlyModified.slice(0, 6).map((t) =>
      <div key={t.id} className="v1-test-row">
          <span className="v1-test-rank">›</span>
          <span className="v1-test-name">{t.name}</span>
          <span className={`sev-pill sev-bg-${t.severity}`}>{t.severity}</span>
          <span className="v1-test-when">{t.when}</span>
        </div>
      )}
    </div>);

}

function Variation1() {
  return (
    <div className="dash-shell" data-screen-label="V1 Tactical Green">
      <Sidebar accentColor="var(--accent)" />
      <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <TopBar />
        <main className="v1-content">
          <BranchPill />
          <QuickActions />

          <div className="v1-grid v1-row-kpis">
            <KPI icon={I.flask} label="Total Tests" value="53"
            trend="+5" foot="↑ 12% wk-over-wk"
            sparkColor="#00e68a" sparkData={D.trends.tests} />
            <KPI icon={I.target} label="MITRE Techniques" value="116"
            trend="+8" foot="across 12 tactics"
            sparkColor="#00e68a" sparkData={D.trends.techniques} />
            <KPI icon={I.grid} label="Categories" value="3"
            trend="—" foot="cyber-hygiene · intel · top10"
            sparkColor="#22d3ee" sparkData={D.trends.categories} />
            <KPI icon={I.star} label="Avg Score" value="8.72"
            trend="+0.2" foot="across 53 scored tests"
            sparkColor="#00ffaa" sparkData={D.trends.score} />
          </div>

          <div className="v1-grid v1-row-main">
            <div className="v1-cell-mitre"><MitreMatrix /></div>
            <div className="v1-cell-side v1-col-stretch">
              <TopRated />
              <div className="v1-grid2 v1-grid2-stretch">
                <SeverityCard />
                <CategoryDonut />
              </div>
            </div>
          </div>

          <div className="v1-grid v1-row-tests">
            <div className="v1-cell-mitre"><RecentlyMod /></div>
            <div className="v1-cell-side dash-card">
              <div className="dash-card-head">
                <div className="dash-card-title"><Icon d={I.play} size={12} />Run Queue</div>
                <div className="mono-label">3 in progress</div>
              </div>
              {[
              { n: 'MDE Process Injection and API Auth Bypass', s: 'critical', p: 78 },
              { n: 'ESXi Hypervisor Ransomware Kill Chain', s: 'critical', p: 62 },
              { n: 'Volt Typhoon LotL WMIC Discovery Chain', s: 'high', p: 34 },
              { n: 'Kerberoasting + AS-REP Roast Workflow', s: 'high', p: 0 },
              { n: 'Entra ID Tenant Hygiene Bundle', s: 'critical', p: 0 }].
              map((q, i) =>
              <div key={i} className="v1-test-row" style={{ gap: 8 }}>
                  <span className="v1-test-rank">{String(i + 1).padStart(2, '0')}</span>
                  <span className="v1-test-name" title={q.n}>{q.n}</span>
                  <div style={{ width: 50, height: 4, background: 'rgba(255,255,255,.06)', borderRadius: 2, overflow: 'hidden', flexShrink: 0 }}>
                    <div style={{ width: `${q.p}%`, height: '100%', background: q.p ? 'var(--accent)' : 'transparent' }} />
                  </div>
                  <span className="v1-test-when" style={{ minWidth: 36, textAlign: 'right' }}>{q.p ? `${q.p}%` : 'queued'}</span>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>);

}

window.Variation1 = Variation1;