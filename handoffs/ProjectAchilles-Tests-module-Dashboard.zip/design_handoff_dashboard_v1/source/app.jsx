/* global React, ReactDOM, DesignCanvas, DCSection, DCArtboard, Variation1 */
const { createRoot } = ReactDOM;

function App() {
  return (
    <DesignCanvas
      title="Achilles · Dashboard Redesign"
      subtitle="V1 · Tactical Green — selected direction for implementation."
      backgroundColor="#02040a"
    >
      <DCSection id="dashboards" title="Dashboard">
        <DCArtboard id="v1" label="V1 · Tactical Green · Command Center" width={1440} height={980} background="#02040a">
          <Variation1 />
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

createRoot(document.getElementById('root')).render(<App />);
