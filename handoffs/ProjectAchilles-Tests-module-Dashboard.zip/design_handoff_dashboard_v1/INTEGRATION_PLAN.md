# Integration Plan — Dashboard V1 (Tactical Green)

This is the step-by-step plan for porting the V1 Dashboard design from
`source/` into the existing `frontend/` codebase. Read `README.md` first.

## Phase 0 — Branch + setup

1. Cut a new branch from `main`:
   ```
   git checkout -b redesign/dashboard-v1-tactical-green
   ```
2. Open `frontend/src/pages/browser/BrowserHomePage.tsx` and skim the existing
   implementation. Note:
   - Where it lives in the route tree (likely `/` or `/tests`)
   - Which layout shell wraps it (probably from `frontend/src/components/layout/`)
   - Which data hooks it calls (`frontend/src/services/`, `frontend/src/hooks/`)
   - Which styling system it uses (Tailwind / CSS modules / global styles)
3. Open one or two other pages (e.g. `AnalyticsDashboardPage.tsx`) for convention
   reference.

## Phase 1 — Verify the design tokens are loaded

The landing page handoff (`frontend/design_handoff_achilles_landing/`) already
specifies these tokens in `:root`. If that handoff has been merged, the tokens
exist in the codebase already — **reuse them**, don't redefine.

If they have NOT been merged yet:
1. Copy the `:root` block from `source/styles.css` into the codebase's global
   stylesheet (or wherever theme tokens live).
2. Add the Google Fonts import for **Orbitron, Rajdhani, Inter, JetBrains Mono**
   to `index.html` (or wherever fonts are declared).

Verify by inspecting `getComputedStyle(document.body).getPropertyValue('--accent')`
in the browser — it should return `#00e68a`.

## Phase 2 — Port the shell (Sidebar + TopBar)

The Sidebar and TopBar in `source/shared.jsx` are likely **shared shell** that
will be used by every page in the redesign, not just the dashboard. Treat them
as a layout primitive.

1. Create `frontend/src/components/layout/AchillesShell/`:
   ```
   AchillesShell/
   ├── AchillesShell.tsx      ← <Sidebar /> + <TopBar /> + <main>{children}</main>
   ├── Sidebar.tsx
   ├── TopBar.tsx
   ├── BranchPill.tsx
   ├── QuickActions.tsx
   └── shell.module.css       ← lift from source/shell.css if not using Tailwind
   ```
2. Port `Sidebar` from `source/shared.jsx` (lines defining `Sidebar`):
   - Replace the hardcoded active route prop with React Router's
     `useLocation()` so the active state is derived.
   - Wire each nav link to the existing routes. Keep the icons from `shared.jsx`'s
     icon set, or swap to your existing icon library if the shapes match.
3. Port `TopBar`:
   - Wire the search box to the existing test search service.
   - Wire the env switcher to the existing env state (or stub for now and
     note it in the PR).
   - Pull the build version + commit hash from `import.meta.env` /
     existing build-info utility.
4. Port `BranchPill` and `QuickActions` as small standalone components.

## Phase 3 — Port the dashboard page

1. Replace the current `BrowserHomePage.tsx` (or create a new
   `DashboardPage.tsx` and update the route — your call):

   ```tsx
   <AchillesShell>
     <BranchPill {...syncState} />
     <QuickActions onRunAll={...} onAddTest={...} ... />
     <KpiRow data={kpiData} />
     <MainRow><MitreMatrix ... /><RightColumn ... /></MainRow>
     <TestsRow><RecentlyModified ... /><RunQueue ... /></TestsRow>
   </AchillesShell>
   ```

2. Create one component per card. Suggested split (one file each):
   ```
   frontend/src/pages/browser/dashboard/
   ├── DashboardPage.tsx
   ├── KpiRow.tsx                  ← contains 4× <KpiCard>
   ├── KpiCard.tsx
   ├── MitreMatrix.tsx
   ├── TopRated.tsx
   ├── SeverityCard.tsx
   ├── CategoryDonut.tsx
   ├── RecentlyModified.tsx
   ├── RunQueue.tsx
   └── dashboard.module.css        ← lift from source/v1.css
   ```
3. Port each card. For each:
   - Add explicit prop types — every card takes structured data, no `any`.
   - Replace mock arrays with real data from existing services (see
     `README.md` § Data Model for the field-by-field mapping).
   - Replace inline `style={{...}}` with the codebase's styling convention
     (Tailwind utilities, CSS modules, etc.).
   - Replace CSS class strings (`className="kpi-card"`) appropriately.
   - Convert `useState` / `useEffect` / `useRef` to ESM imports
     (`import { useState } from 'react'`) — the source uses `const { useState } = React;`.

## Phase 4 — Port the styles

`source/v1.css` is ~250 lines, `source/shell.css` ~150 lines. Walk them card by
card. Most rules map cleanly to utility classes; the trickier ones are listed
below — keep these as raw CSS in a module or `@layer components`.

**Don't lose:**
- The 12-column unified grid (`.v1-grid` + `.v1-row-kpis` / `.v1-cell-mitre` /
  `.v1-cell-side`). Vertical column gridlines must align across all rows.
- The pulsing dot keyframe (`@keyframes pulse` in `styles.css`).
- The `font-variant-numeric: tabular-nums` on score / KPI numbers.
- The truncation rules with title-tooltips on test names (rows must not wrap).

**Don't carry over:**
- Cache-bust query strings (`?v=8`) on the source `<link>` tags.
- The `.design-canvas` styles — that's the dev-only wrapper.
- The MITRE matrix's exact 12-column flex layout if your container width
  is different — re-tune cell widths to match. Aim for: tactic column =
  `1fr`, cell stack = 16 cells × 6px tall.

## Phase 5 — Wire data + state

For each card, replace the mock `window.DASHBOARD_DATA` access with:

| Card | Source |
|---|---|
| KPIs | Aggregate over the test catalog query — `useTestCatalog()` or similar |
| MITRE Matrix | New aggregation: group tests by `mitre_tactic`, count covered |
| Severity Distribution | Group by `severity`, count per bucket |
| Category Breakdown | Group by `category`, count per bucket |
| Top Rated | Top 5 by `score` desc, from the existing test list |
| Recently Modified | Top 5 by `updated_at` desc, last 24h |
| Run Queue | Existing runs service — active + queued |
| Branch / commit | Existing git/sync state shown in current `BrowserHomePage` |
| Agent status | Existing agent service hook |

Where an aggregation doesn't exist yet, prefer adding it to the existing
service over computing in the component. Keep the components dumb.

## Phase 6 — Strip dev-only code

Before opening the PR:
- Remove anything related to `design-canvas.jsx`, `<DesignCanvas>`,
  `<DCArtboard>`, the `app.jsx` wrapper.
- Remove any `?v=N` cache-busters on script/link tags.
- Remove all `console.log` / scratch state from the prototype.

## Phase 7 — Verify

Run, in order:

1. `tsc --noEmit` (or whatever typechecks the frontend) — fix any type errors.
2. The dev build (`npm run dev` / `vite`) — load the dashboard, click through
   every nav link, run the env switcher, verify the agent status pulses.
3. The production build (`npm run build`) — confirm it compiles without
   warnings about missing fonts, assets, or unused imports.
4. **Visual diff** — open `source/Achilles Dashboard.html` in a browser
   side-by-side with the integrated page. Look for:
   - Color drift (tokens mapped wrong)
   - Font fallback (Orbitron / Rajdhani / JetBrains Mono not loading)
   - Spacing differences (gap, padding)
   - **Column gridlines NOT lining up across rows** (most common regression
     when porting the 12-col grid)
   - Numbers not using tabular-nums (causes wobble in KPI scores)

Fix all of the above before opening a PR.

## Phase 8 — PR hygiene

- One commit per phase, or one commit per card component.
- PR description should link to this handoff folder and call out anything
  you deviated from (e.g. "used existing `<Card>` wrapper instead of
  duplicating the container styles").
- Include a screenshot of the new dashboard in the PR description.
- Tag whoever owns `BrowserHomePage.tsx` for review.

## Common Pitfalls

1. **Breaking the 12-column grid.** If rows use different column counts,
   nothing lines up. Use a single grid container per row with
   `repeat(12, minmax(0,1fr))`.
2. **Missing `font-variant-numeric: tabular-nums`** on KPI numbers and scores
   — without it, digits jitter.
3. **Forgetting Rajdhani.** Card titles fall back to system sans and look
   completely off-brand.
4. **Letting card heights drift independently.** The MITRE / Right column
   row should have both children fill the row height; same for Recently
   Modified / Run Queue.
5. **Hardcoding mock data into components.** Keep the components data-driven
   — pass props from a data layer, don't import `data.js`.
6. **Skipping the truncation rules.** Test names overflow without
   `min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap`
   on the right cell of every list row.

## Asking for help

If you hit anything ambiguous (an existing component conflicts with the new
design, a token doesn't have an obvious mapping, an aggregation doesn't exist
in the services layer), **stop and ask** rather than guessing. The README
has the design intent; the codebase has the conventions. When they disagree,
the human needs to arbitrate.
