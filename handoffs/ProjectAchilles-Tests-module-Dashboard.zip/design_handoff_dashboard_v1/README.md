# Handoff: Dashboard V1 — Tactical Green

## Overview

This is a redesign of the Achilles **Test Catalog Dashboard** (current implementation:
`frontend/src/pages/browser/BrowserHomePage.tsx`). The redesign — internally codenamed
**V1 · Tactical Green · Command Center** — reframes the dashboard from a list-first browse
view into a single-glance command-center with KPI strip, MITRE ATT&CK coverage matrix,
severity distribution, top-rated tests, recently modified, and run queue panels.

The visual language is borrowed directly from the existing Achilles landing page (see
`frontend/design_handoff_achilles_landing/`): tactical green accent on near-black
surface, Orbitron display + Rajdhani tactical labels + JetBrains Mono micro-text +
Inter body, sharp corners (4–8px radii max), thin lines, single-pulse green dot accents,
sev-coded chips and bars.

## About the Design Files

The files in `source/` are **design references created in HTML/JSX** — a high-fidelity
prototype demonstrating the intended look, layout, behavior, copy, and interactions for
the new dashboard. They use React 18 from a CDN with in-browser Babel transpilation and
mock data from `data.js`.

**Your job is not to ship this HTML directly.** Your job is to **recreate this design
in the existing Fortika `frontend/` codebase** (React + TypeScript + the existing
component library used by `BrowserHomePage.tsx` and the rest of `frontend/src/pages/`)
using its established patterns: TSX components, the existing styling system (Tailwind /
CSS modules / whatever `BrowserHomePage.tsx` already uses), the existing data hooks
and services in `frontend/src/services/` and `frontend/src/hooks/`, and the existing
auth/layout shells in `frontend/src/components/layout/`.

The HTML prototype is the source of truth for **visual design, copy, layout, and
interaction** — but the implementation should match the conventions of the target
codebase.

> **Branch.** Implement on a new branch — suggested name: `redesign/dashboard-v1-tactical-green`.

## Fidelity

**High-fidelity (hifi).** All colors, typography, spacing, copy, and interaction details
are final. Recreate pixel-perfectly.

- Exact hex values, font stacks, border radii, and shadow values are specified in
  `source/styles.css` `:root` and `source/v1.css`.
- All copy in the design is finalized (English only — no i18n on this page yet).
- Layout uses a **unified 12-column grid** so vertical column gridlines line up across
  all rows. This must be preserved exactly — see *Layout Grid* below.

## File Map

```
design_handoff_dashboard_v1/
├── README.md                       ← you are here
├── INTEGRATION_PLAN.md             ← step-by-step implementation plan for Claude Code
└── source/
    ├── Achilles Dashboard.html     ← entry point (just script tags)
    ├── app.jsx                     ← root mount + design-canvas wrapper (strip in prod)
    ├── shared.jsx                  ← Sidebar, TopBar, BranchPill, QuickActions,
    │                                  Sparkline, Icon set
    ├── v1.jsx                      ← all dashboard cards + page composition (~310 lines)
    ├── data.js                     ← mock data (window.DASHBOARD_DATA)
    ├── styles.css                  ← design tokens (lifted from landing)
    ├── shell.css                   ← Sidebar / TopBar / generic .dash-card
    ├── v1.css                      ← V1-specific page + card styles
    ├── design-canvas.jsx           ← DEV ONLY canvas wrapper — strip for prod
    └── assets/
        └── logo-achilles.svg       ← brand mark used in the sidebar header
```

## Page Anatomy

The dashboard fills the full viewport (no max-width on `<main>`). It is composed of
three structural regions:

```
┌──────────┬───────────────────────────────────────────────────────────┐
│          │  TopBar  (search, env switcher, agent status, profile)    │
│ Sidebar  ├───────────────────────────────────────────────────────────┤
│          │  BranchPill + QuickActions row                            │
│ (224px,  │                                                            │
│  fixed   │  ROW 1 — KPI strip   (4 KPIs, equal width)                │
│  width,  │  ─────────────────────────────────────────────────────    │
│  vert.   │  ROW 2 — MAIN  (8-col MITRE matrix | 4-col right column)  │
│  scroll) │                  └ right col: Top Rated  /  Sev + Cat row │
│          │  ─────────────────────────────────────────────────────    │
│          │  ROW 3 — TESTS (8-col Recently Modified | 4-col Run Queue)│
└──────────┴───────────────────────────────────────────────────────────┘
```

### Layout Grid (critical — see `v1.css` `.v1-grid` block)

All three content rows use the **same** 12-column CSS grid with **`gap: 14px`**:

```css
.v1-grid { display: grid; grid-template-columns: repeat(12, 1fr); gap: 14px; }
.v1-row-kpis > * { grid-column: span 3; }   /* 4 × 3 = 12 */
.v1-cell-mitre   { grid-column: span 8; }   /* MITRE / Recently Mod */
.v1-cell-side    { grid-column: span 4; }   /* Right column / Run Queue */
```

Inside the right column the Severity + Category cards split it 50/50 (using a
nested 2-column grid via `.v1-grid2-stretch`). This keeps every vertical column
gridline perfectly aligned at any viewport width.

**Do not regress this** — the alignment was the most-requested polish from the
design review. If you switch to a CSS framework that doesn't expose 12-column
tracks (e.g. Tailwind without arbitrary `grid-cols-12`), use
`grid-template-columns: repeat(12, minmax(0, 1fr))` explicitly.

## Components & Cards

### Sidebar (`shared.jsx` → `Sidebar`)
- 224px fixed width, full viewport height, `var(--bg-surface)` background, 1px right border.
- Header: `<AchillesLogo>` + "ACHILLES" wordmark in Orbitron, plus a "v2.0" mono tag.
- Nav sections: **MAIN** (Dashboard, Tests, Endpoints, Runs, Reports), **MONITORING**
  (Activity, Findings), **CONFIG** (Integrations, Settings). Each link: 40px tall,
  Rajdhani 12px uppercase tracked .12em, accent left-bar on active, hover row tint.
- Footer: agent status pill (pulsing green dot + "AGENT ONLINE" + tactical label).

### TopBar (`shared.jsx` → `TopBar`)
- 56px tall, full width minus sidebar, 1px bottom border.
- Left: search box (mono placeholder "search tests, techniques, runs…", 320px wide).
- Right: env switcher (`prod / staging / local` segmented, mono), build pill
  (`v2.0.4 · 4238c50`), profile (avatar circle + email tooltip).

### BranchPill (`shared.jsx` → `BranchPill`)
- Inline group: branch icon + `main` + commit hash + "synced 6m ago".
- Mono, 11px, accent dot before the branch name.

### QuickActions (`shared.jsx` → `QuickActions`)
- Right-aligned button row: **Run all**, **Add test**, **Filter**, **Sort**, **Export**.
- Primary (Run all): solid green-on-black, Orbitron 11px tracked .14em.
- Secondary: outlined, hover-fills with `--accent-subtle`.

### KPI cards (`v1.jsx` → `KPI`)
Four equal cards. Each:
- Top: small icon in a 22px square `--accent-subtle` chip + tactical label
  (Rajdhani 10px) on the left; trend tag on the right (`+5`, `↑ 12% wk-over-wk`).
- Big number: Orbitron 38px, weight 700, letter-spacing -.02em.
- Foot row: secondary-text caption + tiny inline sparkline (12-pt path, accent stroke).

KPIs in order: **Total Tests · MITRE Techniques · Categories · Avg Score**.

### MITRE Matrix card (`v1.jsx` → `MitreMatrix`)
- Card head: dot + "MITRE ATT&CK Coverage" title, right-side stat chips
  (`12 tactics`, `116 techniques`, `82% coverage`), filter chips below the title row
  (`All / Critical / Hi-impact`).
- Body: 12-column flex row, one column per tactic. Each column renders the tactic
  ID badge (`IA`, `EX`, etc.), name, and a vertical stack of 16 cells coded
  `covered / partial / gap` proportional to that tactic's coverage percentage.
- Foot legend: 3 swatches (covered / partial / gap) — small 10px mono.

### Top Rated card (`v1.jsx` → `TopRated`)
- Card head: dot + "Top Rated Tests" + mono `5 of 53`.
- Body: 5 rows. Each row = `rank (mono 10px) · test name (truncate w/ tooltip) ·
  severity pill · score (Orbitron tabular-nums, accent-bright)`.

### Severity Distribution card (`v1.jsx` → `SeverityCard`)
- Card head: dot + "Severity Distribution" + total tests count.
- Top: a single full-width segmented bar (28–36px tall, 1px line border, 3px radius).
  Segments are sized by count. Severity colors: critical=`--danger`, high=`--warn-bright`,
  medium=`--signal`, low=`rgba(255,255,255,.18)`.
- Below: a 2-column grid of legend rows (color swatch + label + count).

### Category Breakdown card (`v1.jsx` → `CategoryDonut`)
- Card head: dot + "Category Breakdown" + mono `3 cats`.
- Body in narrow column: 84px donut (auto / 1fr grid) with total count in the center
  (Orbitron 20px), and a compact legend (max 9ch, ellipsis) on the right.
- Categories: `cyber-hygiene` (`#4f8eff`), `intel-driven` (`#a78bfa`), `mitre-top10`
  (`#22d3ee`).

### Recently Modified card (`v1.jsx` → `RecentlyMod`)
- Card head: dot + "Recently Modified" + mono `last 24h`.
- Rows: `time (mono) · test ID badge · test name (truncate) · severity pill ·
  state pill (PASS / MOD)`.

### Run Queue card (inline in `v1.jsx`)
- Card head: dot + "Run Queue" + mono `3 in progress`.
- Rows: `rank · test name (truncate w/ title) · 50px progress bar · percent or "queued"`.
- Progress bar is 50px wide, 4px tall, 2px radius, fill = `--accent`.

## Design Tokens

All tokens are in `source/styles.css` (lifted from the landing page). Reuse the same
values; do not introduce new ones.

### Colors
| Token | Value | Use |
|---|---|---|
| `--accent` | `#00e68a` | Primary green accent |
| `--accent-bright` | `#00ffaa` | Score / number emphasis |
| `--accent-dim` | `rgba(0,230,138,.5)` | Border on accent surfaces |
| `--accent-glow` | `rgba(0,230,138,.35)` | Pulsing dot shadow |
| `--accent-subtle` | `rgba(0,230,138,.08)` | Icon chip / hover fill |
| `--gold` | `#d4a443` | Reserved for landing — not used in V1 |
| `--signal` | `#4f8eff` | Medium severity |
| `--violet` | `#a78bfa` | Category: intel-driven |
| `--cyan` | `#22d3ee` | Category: mitre-top10 |
| `--danger` | `#ff3b5c` | Critical severity / gaps |
| `--warn-bright` | `#ffc857` | High severity |
| `--bg-deep` | `#050810` | Page background body |
| `--bg-surface` | `#080c18` | Sidebar / TopBar |
| `--bg-elevated` | `#0d1326` | (reserved) |
| `--bg-card` | `rgba(15,21,40,.55)` | All cards |
| `--text-primary` | `#f0f2f5` | Body text |
| `--text-secondary` | `rgba(240,242,245,.72)` | Card body text |
| `--text-muted` | `#6b7388` | Labels |
| `--text-faint` | `#3a4055` | Mono micro-text (rank, hash) |
| `--line` | `rgba(255,255,255,.06)` | Card / row separators |
| `--line-soft` | `rgba(255,255,255,.03)` | Section dividers |
| `--line-strong` | `rgba(255,255,255,.12)` | Hovered rows |

### Typography
| Token | Stack | Use |
|---|---|---|
| `--font-display` | `Orbitron`, sans-serif | KPI big numbers, sidebar logo, scores |
| `--font-tactical` | `Rajdhani`, sans-serif | Card titles, sidebar nav, sev pills |
| `--font-body` | `Inter`, system-ui | Body text |
| `--font-mono` | `JetBrains Mono`, ui-monospace | Hashes, time, rank, mono labels |

### Spacing
- Card padding: `18px`
- Card head margin-bottom: `16px`
- Page row gap: `14px`
- KPI row gap: `12px`

### Radii
- Cards: `8px` outer, `6px` for KPI cards
- Pills / chips: `2–3px` (sharp / tactical)
- No fully-rounded elements except the small status dots.

### Shadows
None on cards. Only the pulsing accent dot uses `box-shadow: 0 0 6px var(--accent-glow)`.

## Interactions & Behavior

- **Sidebar nav**: standard router links — active item gets `border-left: 2px solid
  var(--accent)` and `background: var(--accent-subtle)`. No animation beyond hover bg.
- **Cards**: no hover lift or shadow. Static.
- **MITRE filter chips** (`All / Critical / Hi-impact`): clientside filter on the cell
  data — wire to whatever filter state lives in your Tests query. The cells
  themselves are decorative (severity-coded blocks); they don't need to be clickable
  in V1, but if you want to make them so, route to the tests page filtered by tactic ID.
- **TopBar search**: not wired in the prototype. Wire to existing test search service.
- **Pulsing agent dot**: `animation: pulse 2s ease-in-out infinite` (defined in
  `styles.css`). Keep as-is.
- **Sparklines**: simple SVG `<path>` from a data array — see `Sparkline` in
  `shared.jsx`. Replace mock arrays with whatever `frontend/src/services/` exposes
  for KPI history, or compute from existing test history.

## Data Model

The prototype uses `window.DASHBOARD_DATA` from `data.js`. Replace each field with the
real source from your existing services. Mapping:

| Mock field | Replace with |
|---|---|
| `branch`, `commit`, `syncedAgo` | Existing git/sync state (already shown elsewhere) |
| `agentStatus` | Agent service status hook |
| `totalTests`, `techniques`, `tactics`, `categories` | Aggregations over the test catalog |
| `avgScore`, `testsScored` | Existing scoring service |
| `critical/high/medium/low` | Severity counts from the test catalog |
| `trends.{tests,techniques,categories,score}` | Time-series for last 14 days |
| `tactics_data` | MITRE coverage per tactic — `{id, name, techniques, covered}` |
| `category_data` | Category buckets — `{id, name, count, color}` |
| `topRated` (in v1.jsx body) | Top-5 by score (descending) from the catalog |
| `recentlyMod` (in v1.jsx body) | Last 5 modified tests with timestamp |
| Run queue (inline in v1.jsx) | Active runs from the runs service |

## Assets

- `assets/logo-achilles.svg` — same logo as the landing page; if it's already in your
  codebase (e.g. imported by `Sidebar.tsx` elsewhere), reuse the existing import.

## Dev-only files to strip

When porting to production:
- **`design-canvas.jsx`** — the canvas wrapper that lets the design tool show artboards
  side by side. Don't ship this.
- **`app.jsx`** — wraps `<Variation1>` in the canvas. The real entry point should
  render the dashboard directly into your route.
- **The script-tag bootstrap** in `Achilles Dashboard.html`. Your bundler / Vite setup
  replaces all of this.
- Any `?v=N` cache-busting query strings on `<link>` and `<script>` tags.

## Files in the source bundle

- `Achilles Dashboard.html` — entry HTML (script tags only)
- `app.jsx` — design-canvas mount (dev only)
- `shared.jsx` — Sidebar / TopBar / BranchPill / QuickActions / Sparkline / Icon set
- `v1.jsx` — KPI / MitreMatrix / SeverityCard / CategoryDonut / TopRated /
  RecentlyMod / Run queue and page composition
- `data.js` — mock `window.DASHBOARD_DATA`
- `styles.css` — design tokens
- `shell.css` — Sidebar / TopBar / generic `.dash-card`
- `v1.css` — V1-specific layout grid + cards
- `design-canvas.jsx` — dev-only wrapper (strip)
- `assets/logo-achilles.svg`

See `INTEGRATION_PLAN.md` for the step-by-step implementation plan.
