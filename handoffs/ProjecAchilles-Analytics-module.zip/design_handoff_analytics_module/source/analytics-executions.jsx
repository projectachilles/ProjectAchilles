/* global React, Icon, I, AnShell */
const { useState: useStateE } = React;
const AD_E = window.ANALYTICS_DATA;

// ── Sub-row for expanded child tests ────────────────────────────────
function ChildRow({ row }) {
  const isOk = row.result === 'protected';
  return (
    <tr className="is-child">
      <td><span className="an-exec-childbranch">└</span></td>
      <td/>
      <td>
        <span className="an-exec-test">
          {row.archived && <Icon d={I.bell} size={12} style={{ opacity:.4 }}/>}
          <span style={{ color:'var(--text-secondary)' }}>{row.name}</span>
        </span>
      </td>
      <td><span className="an-exec-host">{row.host}</span></td>
      <td>
        <span className={`an-exec-result ${isOk?'is-protected-ok':'is-unprotected'}`}>
          <Icon d={isOk? I.check : I.alert} size={11} sw={2.2}/>
          {isOk ? 'protected' : 'unprotected'}
        </span>
      </td>
      <td><span className="an-exec-cat">{row.cat}</span></td>
      <td>
        <span className="an-exec-tech-stack" style={{ flexDirection:'row', gap:4 }}>
          {row.tech.split(',').map(t => <span key={t}>{t.trim()}</span>)}
        </span>
      </td>
      <td><span className={`an-exec-code ${isOk?'is-ok':'is-fail'}`}>{row.code}</span></td>
      <td/>
    </tr>
  );
}

function BundleRow({ row, expanded, onToggle }) {
  const isFail = row.protectedN < row.total / 2;
  return (
    <tr>
      <td style={{ width: 24 }}>
        <span className={`an-exec-expander ${expanded?'is-open':''}`} onClick={onToggle}>
          <Icon d="M9 6l6 6-6 6" size={12} sw={2}/>
        </span>
      </td>
      <td style={{ width: 22 }}><span className="an-exec-checkbox"/></td>
      <td>
        <span className="an-exec-test">
          {row.archived && <Icon d={I.bell} size={12} className="an-exec-archived-icon"/>}
          <Icon d={I.flask} size={13} className="an-exec-test-icon"/>
          <span>{row.name}</span>
          <span className="an-exec-controls-pill">{row.controls} controls</span>
        </span>
      </td>
      <td><span className="an-exec-host">{row.host}</span></td>
      <td>
        <span className={`an-exec-result ${isFail?'is-protected':'is-protected-ok'}`}>
          <Icon d={isFail? I.alert : I.check} size={11} sw={2.2}/>
          {row.protectedN} / {row.total} protected
        </span>
      </td>
      <td><span className="an-exec-cat">{row.cat}</span></td>
      <td>
        <div className="an-exec-tech-stack">
          {row.techniques.map(t => <span key={t}>{t}</span>)}
          {row.extraTechniques>0 && <span className="an-exec-tech-extra">+{row.extraTechniques} more</span>}
        </div>
      </td>
      <td><span className={`an-exec-code ${isFail?'is-fail':'is-ok'}`}>{row.codes}</span></td>
      <td><span className="an-exec-time">{row.when}</span></td>
    </tr>
  );
}

function AnalyticsExecutions() {
  const [expanded, setExpanded] = useStateE({ 'cyb-01': true });
  const [density, setDensity] = useStateE('comfortable');
  const toggle = id => setExpanded(s => ({ ...s, [id]: !s[id] }));

  return (
    <AnShell title="Analytics · All Executions" activeTab="executions" label="Analytics — Executions">
      <div className="an-exec-toolbar">
        <div className="an-exec-toolbar-left">
          Showing <strong>{AD_E.executions.length}</strong> bundles · <strong>{AD_E.totalExecutions.toLocaleString()}</strong> total executions
          <span style={{ color:'var(--text-muted)', marginLeft:10 }}>· grouped by name+host+date</span>
        </div>
        <div className="an-exec-toolbar-right">
          <div className="an-mode-toggle">
            <button className={density==='comfortable'?'is-active':''} onClick={()=>setDensity('comfortable')}>COMFORT</button>
            <button className={density==='compact'?'is-active':''} onClick={()=>setDensity('compact')}>COMPACT</button>
          </div>
          <button className="an-pill"><Icon d={I.shield} size={11}/>SCORING: NORMAL ▾</button>
          <button className="an-pill"><Icon d={I.download} size={11}/>EXPORT CSV</button>
          <button className="an-pill"><Icon d={I.bell} size={11}/>ARCHIVE…</button>
        </div>
      </div>

      <div className={`an-exec ${density==='compact'?'is-compact':''}`}>
        <table>
          <thead>
            <tr>
              <th style={{ width:24 }}/>
              <th style={{ width:22 }}><span className="an-exec-checkbox"/></th>
              <th>Test / Bundle <span className="an-th-arrow">↕</span></th>
              <th>Host</th>
              <th>Result</th>
              <th>Category</th>
              <th>Techniques</th>
              <th>Codes</th>
              <th>Executed <span className="an-th-arrow">↓</span></th>
            </tr>
          </thead>
          <tbody>
            {AD_E.executions.map(row => (
              <React.Fragment key={row.id}>
                <BundleRow row={row} expanded={!!expanded[row.id]} onToggle={()=>toggle(row.id)}/>
                {expanded[row.id] && (AD_E.expandedChildren[row.id]||[]).map((c, i) => (
                  <ChildRow key={i} row={c}/>
                ))}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'14px 4px', fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-muted)' }}>
        <span>Page 1 of 60 · 25 per page</span>
        <div style={{ display:'flex', gap:6 }}>
          <button className="an-pill" disabled style={{ opacity:.4 }}>← PREV</button>
          <button className="an-pill">NEXT →</button>
        </div>
      </div>
    </AnShell>
  );
}

Object.assign(window, { AnalyticsExecutions });
