/* global React, Icon, I, AnShell, TrendChart */
const AD_D = window.ANALYTICS_DATA;

// ── Defender tab ────────────────────────────────────────────────────
function AnalyticsDefender() {
  const total = AD_D.detection.total;
  const detected = AD_D.detection.detected;
  return (
    <AnShell title="Analytics · Defender" activeTab="defender" label="Analytics — Defender">
      <div className="an-defender-head">
        <div>
          <h2>Microsoft Defender</h2>
          <p>
            Secure Score, security alerts, and remediation controls
            <span> · Last synced <code>2m ago</code> · tenant <code>contoso.onmicrosoft.com</code></span>
          </p>
        </div>
        <button className="an-pill"><Icon d={I.sync} size={11}/>SYNC NOW</button>
      </div>

      <div className="an-grid">
        <div className="col-4">
          <div className="an-card" style={{ padding: 0 }}>
            <div className="an-hero-score">
              <span className="an-hero-score-label"><Icon d={I.shield} size={14}/>Secure Score</span>
              <div className="an-hero-score-value is-secure">{AD_D.secureScore.toFixed(1)}%</div>
              <div className="an-hero-score-delta">
                <Icon d={I.arrowU} size={9} sw={2}/>+3.4 pts (7d)
              </div>
              <div className="an-hero-score-sub">{AD_D.secureScoreCurrent.toFixed(1)} / {AD_D.secureScoreMax.toFixed(1)} pts</div>
            </div>
            <div className="an-kpi-strip">
              <div className="an-kpi-cell">
                <span className="an-kpi-cell-label">CONTROLS</span>
                <span className="an-kpi-cell-value">182</span>
              </div>
              <div className="an-kpi-cell">
                <span className="an-kpi-cell-label">REMEDIATED</span>
                <span className="an-kpi-cell-value" style={{ color:'var(--accent)' }}>148</span>
              </div>
            </div>
          </div>
        </div>

        <div className="col-8">
          <div className="an-card">
            <div className="an-card-head">
              <div>
                <div className="an-card-title"><Icon d={I.shield} size={13}/>Top Remediation Controls</div>
                <div className="an-card-sub">RANKED BY DEFENDER · MAX-SCORE WEIGHT</div>
              </div>
            </div>
            <div className="an-list">
              {AD_D.topControls.map(c => (
                <div key={c.rank} className="an-list-row">
                  <span className="an-list-rank">{String(c.rank).padStart(2,'0')}</span>
                  <span className="an-list-title">{c.title}</span>
                  <span className="an-list-cat">{c.cat}</span>
                  <span className="an-list-score">+{c.score.toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Detection Analysis */}
        <div className="col-7">
          <div className="an-card">
            <div className="an-card-head">
              <div>
                <div className="an-card-title"><Icon d={I.target} size={13}/>Detection Analysis</div>
                <div className="an-card-sub">DEFENDER ALERTS PER ATT&amp;CK TECHNIQUE · LAST 7 DAYS</div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div style={{ fontFamily:'var(--font-display)', fontSize:24, fontWeight:700, color:'var(--accent)' }}>{AD_D.detection.rate.toFixed(1)}%</div>
                <div style={{ fontFamily:'var(--font-mono)', fontSize:9.5, color:'var(--text-muted)', letterSpacing:'.15em' }}>DETECTION RATE</div>
              </div>
            </div>
            <div>
              {AD_D.detection.items.map(it => {
                const pct = (it.tests / 16) * 100;
                return (
                  <div key={it.id} className="an-detection-bar">
                    <span className="an-detection-id">{it.id}</span>
                    <div className="an-detection-track">
                      <div className={`an-detection-fill ${it.alerts>0?'is-detected':''}`} style={{ width: `${Math.min(100, pct)}%` }}/>
                    </div>
                    <span className="an-detection-tests">{it.tests} tests</span>
                    <span className={`an-detection-alert ${it.alerts>0?'is-alert':'is-none'}`}>
                      {it.alerts>0 ? <><Icon d={I.alert} size={10}/>{it.alerts} alert</> : 'no alerts'}
                    </span>
                  </div>
                );
              })}
            </div>
            <div style={{ marginTop: 12, display:'flex', gap:14, fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-muted)' }}>
              <span><span className="an-legend-dot" style={{ background:'var(--accent)' }}/>Detected by Defender</span>
              <span><span className="an-legend-dot" style={{ background:'var(--danger)' }}/>No matching alert</span>
              <span style={{ marginLeft:'auto' }}>{detected}/{total} techniques generated alerts</span>
            </div>
          </div>
        </div>

        {/* Secure Score Trend */}
        <div className="col-5">
          <div className="an-card">
            <div className="an-card-head">
              <div>
                <div className="an-card-title"><Icon d={I.chart} size={13}/>Secure Score Trend</div>
                <div className="an-card-sub">DAILY SNAPSHOT · 21 DAYS</div>
              </div>
            </div>
            <TrendChart width={520} height={220} />
            <div className="an-trend-legend" style={{ marginTop: 6 }}>
              <span className="an-trend-legend-item"><span className="an-trend-legend-swatch" style={{ background:'var(--accent)' }}/>Secure Score</span>
              <span style={{ marginLeft:'auto', color:'var(--text-faint)' }}>+9.0 pts in window</span>
            </div>
          </div>
        </div>

        {/* Technique overlap */}
        <div className="col-12">
          <div className="an-card">
            <div className="an-card-head">
              <div>
                <div className="an-card-title"><Icon d={I.grid} size={13}/>Technique Overlap · ATT&amp;CK ↔ Defender Alerts</div>
                <div className="an-card-sub">CROSS-REFERENCE TEST EXECUTIONS WITH DEFENDER ALERTS BY TECHNIQUE</div>
              </div>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(5, 1fr)', gap: 8 }}>
              {AD_D.techniques.map(t => (
                <div key={t.id} style={{
                  border:'1px solid var(--line)',
                  borderRadius:4,
                  padding:'10px 12px',
                  background: t.defender ? 'rgba(0,230,138,.05)' : 'rgba(255,59,92,.04)',
                  borderLeft: `3px solid ${t.defender? 'var(--accent)' : 'var(--danger)'}`,
                }}>
                  <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color: t.defender?'var(--accent)':'var(--danger)', fontWeight:600 }}>{t.id}</div>
                  <div style={{ fontSize:11.5, color:'var(--text-primary)', marginTop:2, lineHeight:1.3 }}>{t.name}</div>
                  <div style={{ display:'flex', justifyContent:'space-between', marginTop:8, fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-muted)' }}>
                    <span>{t.count} tests</span>
                    <span style={{ color: t.defender?'var(--accent)':'var(--text-muted)' }}>
                      {t.defender ? `${t.alerts} alert${t.alerts>1?'s':''}` : 'no alert'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AnShell>
  );
}

Object.assign(window, { AnalyticsDefender });
