// ── Mock data for Analytics Module ───────────────────────────────────────────
window.ANALYTICS_DATA = {
  // Hero metrics
  defenseScore: 52.9,
  defenseScoreDelta: +1.2,
  secureScore: 87.0,
  secureScoreCurrent: 1066.9,
  secureScoreMax: 1226.0,
  errorRate: 0.0,
  endpoints: 8,
  testsCount: 122,
  totalExecutions: 1490,
  groupsCount: 38,
  avgComparable: 71.4,

  branch: 'main',
  commit: '4238c50',
  syncedAgo: '6m ago',

  // Trend lines (28 days)
  trend: {
    days: ['Apr 5','Apr 6','Apr 7','Apr 8','Apr 9','Apr 10','Apr 11','Apr 12','Apr 13','Apr 14','Apr 15','Apr 16','Apr 17','Apr 18','Apr 19','Apr 20','Apr 21','Apr 22','Apr 23','Apr 24','Apr 25'],
    defense: [42, 43, 44, 47, 48, 50, 51, 50, 49, 51, 52, 51, 50, 51, 51, 52, 52, 52, 53, 53, 52.9],
    secure:  [78, 79, 80, 81, 82, 82, 83, 83, 84, 84, 85, 85, 86, 86, 86, 86, 87, 87, 87, 87, 87.0],
    error:   [3.1, 2.8, 2.4, 2.1, 1.9, 1.8, 1.7, 1.5, 1.3, 1.2, 1.1, 1.0, 0.9, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0.0],
  },

  // Top remediation controls (Defender)
  topControls: [
    { rank:1,  title:'Ensure multifactor authentication is enabled for all users in administrative roles', cat:'Identity', score:10.00 },
    { rank:2,  title:'Block executable content from email client and webmail',                              cat:'Device',   score:9.00 },
    { rank:3,  title:'Block all Office applications from creating child processes',                        cat:'Device',   score:9.00 },
    { rank:4,  title:'Block executable files from running unless they meet a prevalence, age, or trusted list criterion', cat:'Device', score:9.00 },
    { rank:5,  title:'Block abuse of exploited vulnerable signed drivers',                                  cat:'Device',   score:9.00 },
    { rank:6,  title:'Block Office applications from creating executable content',                          cat:'Device',   score:9.00 },
    { rank:7,  title:'Block Win32 API calls from Office macros',                                            cat:'Device',   score:9.00 },
    { rank:8,  title:'Block untrusted and unsigned processes that run from USB',                            cat:'Device',   score:9.00 },
    { rank:9,  title:'Block Adobe Reader from creating child processes',                                    cat:'Device',   score:9.00 },
    { rank:10, title:'Block execution of potentially obfuscated scripts',                                   cat:'Device',   score:8.00 },
  ],

  // Categories sunburst
  categories: [
    { id:'cyber-hygiene', name:'cyber-hygiene', score: 52.9, color: '#22d3ee', subs: [
      { name:'cis-windows-l1', score: 50.7 },
      { name:'baseline',       score: 45.6 },
      { name:'identity-endpoint', score: 67.0 },
    ]},
    { id:'intel-driven', name:'intel-driven', score: 33.1, color: '#a78bfa', subs: [
      { name:'apt-emulation', score: 40.0 },
      { name:'ransomware', score: 28.0 },
    ]},
    { id:'mitre-top10', name:'mitre-top10', score: 61.2, color: '#4f8eff', subs: [
      { name:'top-techniques', score: 61.2 },
    ]},
  ],

  // Recent test activity
  recentTests: [
    { name: 'Behavior Monitoring',                    host: 'LAP-PF55YGBW', when: '1d ago', result: 'protected' },
    { name: 'Virtualization-Based Security',          host: 'LAP-PF55YGBW', when: '1d ago', result: 'protected' },
    { name: 'Block all Office applications f...',     host: 'LAP-PF55YGBW', when: '1d ago', result: 'protected' },
    { name: 'Account Lockout',                        host: 'LAP-MZ03EPS6', when: '2d ago', result: 'unprotected' },
    { name: 'Lockout Threshold',                      host: 'LAP-MZ03EPS6', when: '2d ago', result: 'unprotected' },
  ],

  // Error type distribution
  errorTypes: [
    { name: 'ExecutionPrevented', count: 126, pct: 52.9, color: '#00e68a' },
    { name: 'Unprotected',        count:  88, pct: 36.9, color: '#ff3b5c' },
    { name: 'Inconclusive',       count:  19, pct:  8.0, color: '#ffaa2e' },
    { name: 'Skipped',            count:   5, pct:  2.2, color: '#6b7388' },
  ],

  // ATT&CK technique distribution (with Defender alert overlap)
  techniques: [
    { id:'T1110',   name:'Brute Force',                       count: 22, pct: 22, defender: true,  alerts: 1 },
    { id:'T1557.001', name:'LLMNR/NBT-NS Poisoning',          count: 51, pct: 51, defender: false },
    { id:'T1562.001', name:'Disable or Modify Tools',         count: 100, pct:100, defender: true,  alerts: 1 },
    { id:'T1071.001', name:'Web Protocols',                   count: 45, pct: 45, defender: false },
    { id:'T1204.002', name:'Malicious File',                  count: 38, pct: 38, defender: false },
    { id:'T1059.001', name:'PowerShell',                      count: 30, pct: 30, defender: false },
    { id:'T1547',     name:'Boot or Logon Autostart',         count: 26, pct: 26, defender: false },
    { id:'T1485',     name:'Data Destruction',                count: 14, pct: 14, defender: false },
    { id:'T1505.003', name:'Web Shell',                       count: 22, pct: 22, defender: false },
    { id:'T1543.003', name:'Windows Service',                 count: 18, pct: 18, defender: false },
  ],

  // Detection analysis (Defender)
  detection: {
    rate: 11.1,
    detected: 1,
    total: 9,
    items: [
      { id: 'T1562.001', tests: 1,  alerts: 1, color: 'green' },
      { id: 'T1071.001', tests: 16, alerts: 0 },
      { id: 'T1204.002', tests: 16, alerts: 0 },
      { id: 'T1547',     tests: 8,  alerts: 0 },
      { id: 'T1059.001', tests: 6,  alerts: 0 },
      { id: 'T1070.004', tests: 2,  alerts: 0 },
      { id: 'T1485',     tests: 1,  alerts: 0 },
      { id: 'T1505.003', tests: 1,  alerts: 0 },
      { id: 'T1543.003', tests: 1,  alerts: 0 },
    ],
  },

  // Executions table — collapsed bundle rows
  executions: [
    { id:'cyb-01', name:'Cyber-Hygiene Bundle (Windows Defender Edition)', controls:48, host:'LAP-PF55YGBW', protectedN:22, total:48, cat:'cyber-hygiene', techniques:['defense-evasion','execution'], extraTechniques:6, codes:'22P / 26F', when:'2 days ago' },
    { id:'cis-01', name:'CIS Windows Endpoint Level 1 Hardening Bundle',   controls:52, host:'LAP-PF62CFTV', protectedN:26, total:52, cat:'cyber-hygiene', techniques:['credential-access','lateral-movement'], extraTechniques:3, codes:'26P / 26F', when:'3 days ago' },
    { id:'idn-01', name:'Identity Endpoint Posture Bundle',                controls:22, host:'LAP-PF62CFTV', protectedN:15, total:22, cat:'cyber-hygiene', techniques:['credential-access','defense-evasion'], extraTechniques:4, codes:'15P / 7F', when:'3 days ago' },
    { id:'idn-02', name:'Identity Endpoint Posture Bundle',                controls:22, host:'LAP-PF4NF654', protectedN:15, total:22, cat:'cyber-hygiene', techniques:['credential-access','defense-evasion'], extraTechniques:4, codes:'15P / 7F', when:'3 days ago' },
    { id:'cis-02', name:'CIS Windows Endpoint Level 1 Hardening Bundle',   controls:52, host:'LAP-PF4NE654', protectedN:26, total:52, cat:'cyber-hygiene', techniques:['credential-access','lateral-movement'], extraTechniques:3, codes:'26P / 26F', when:'3 days ago' },
    { id:'cis-03', name:'CIS Windows Endpoint Level 1 Hardening Bundle',   controls:52, host:'LAP-PF1A47F0', protectedN:26, total:52, cat:'cyber-hygiene', techniques:['credential-access','persistence'], extraTechniques:3, codes:'26P / 26F', when:'3 days ago' },
    { id:'idn-03', name:'Identity Endpoint Posture Bundle',                controls:22, host:'LAP-PF1A47F0', protectedN:15, total:22, cat:'cyber-hygiene', techniques:['credential-access','defense-evasion'], extraTechniques:4, codes:'15P / 7F', when:'3 days ago' },
    { id:'cis-04', name:'CIS Windows Endpoint Level 1 Hardening Bundle',   controls:52, host:'LAP-PF55YGBW', protectedN:26, total:52, cat:'cyber-hygiene', techniques:['credential-access','lateral-movement'], extraTechniques:3, codes:'26P / 26F', when:'4 days ago' },
    { id:'cis-05', name:'CIS Windows Endpoint Level 1 Hardening Bundle',   controls:52, host:'CPC-Cesar-5K4JE', protectedN:28, total:52, cat:'cyber-hygiene', techniques:['credential-access','persistence'], extraTechniques:3, codes:'28P / 24F', when:'4 days ago' },
    { id:'cis-06', name:'CIS Windows Endpoint Level 1 Hardening Bundle',   controls:52, host:'RG-PF12U5Q9', protectedN:26, total:52, cat:'cyber-hygiene', techniques:['credential-access','persistence'], extraTechniques:3, codes:'26P / 26F', when:'4 days ago' },
    { id:'idn-04', name:'Identity Endpoint Posture Bundle',                controls:22, host:'LAP-PF55YGBW', protectedN:15, total:22, cat:'cyber-hygiene', techniques:['credential-access','defense-evasion'], extraTechniques:4, codes:'15P / 7F', when:'4 days ago' },
    { id:'idn-05', name:'Identity Endpoint Posture Bundle',                controls:22, host:'LAP-MZ03EPS6', protectedN:15, total:22, cat:'cyber-hygiene', techniques:['credential-access','defense-evasion'], extraTechniques:4, codes:'15P / 7F', when:'4 days ago' },
    { id:'idn-06', name:'Identity Endpoint Posture Bundle',                controls:22, host:'CPC-Cesar-5K4JE', protectedN:13, total:22, cat:'cyber-hygiene', techniques:['credential-access','defense-evasion'], extraTechniques:4, codes:'13P / 9F', when:'4 days ago' },
    { id:'idn-07', name:'Identity Endpoint Posture Bundle',                controls:22, host:'RG-PF12U5Q9', protectedN:15, total:22, cat:'cyber-hygiene', techniques:['credential-access','defense-evasion'], extraTechniques:4, codes:'15P / 7F', when:'4 days ago' },
    { id:'cyb-02', name:'Cyber-Hygiene Bundle (Windows Defender Edition)', controls:48, host:'LAP-PF4NF654', protectedN:21, total:48, cat:'cyber-hygiene', techniques:['lateral-movement','credential-access'], extraTechniques:6, codes:'21P / 27F', when:'4 days ago', archived:true },
    { id:'cyb-03', name:'Cyber-Hygiene Bundle (Windows Defender Edition)', controls:48, host:'LAP-PF1A47F0', protectedN:21, total:48, cat:'cyber-hygiene', techniques:['defense-evasion','credential-access'], extraTechniques:6, codes:'21P / 27F', when:'4 days ago' },
  ],

  // Expanded children for cyb-01
  expandedChildren: {
    'cyb-01': [
      { name: 'PUA Protection',                                            host:'LAP-PF55YGBW', result:'protected',  cat:'cyber-hygiene', tech:'defense-evasion',     code:'ExecutionPrevented' },
      { name: 'Script Block Logging',                                      host:'LAP-PF55YGBW', result:'unprotected', cat:'cyber-hygiene', tech:'execution',           code:'Unprotected (101)' },
      { name: 'WPAD Disabled',                                             host:'LAP-PF55YGBW', result:'unprotected', cat:'cyber-hygiene', tech:'credential-access',   code:'Unprotected (101)' },
      { name: 'Audit Policy Change',                                       host:'LAP-PF55YGBW', result:'unprotected', cat:'cyber-hygiene', tech:'defense-evasion',     code:'Unprotected (101)' },
      { name: 'Minimum Password Length',                                   host:'LAP-PF55YGBW', result:'unprotected', cat:'cyber-hygiene', tech:'credential-access',   code:'Unprotected (101)' },
      { name: 'Behavior Monitoring',                                       host:'LAP-PF55YGBW', result:'protected',   cat:'cyber-hygiene', tech:'defense-evasion',     code:'ExecutionPrevented' },
      { name: 'Virtualization-Based Security',                             host:'LAP-PF55YGBW', result:'protected',   cat:'cyber-hygiene', tech:'credential-access',   code:'ExecutionPrevented' },
      { name: 'Block all Office applications from creating chi...',        host:'LAP-PF55YGBW', result:'protected',   cat:'cyber-hygiene', tech:'execution',           code:'ExecutionPrevented' },
      { name: 'Block Office applications from creating executa...',        host:'LAP-PF55YGBW', result:'protected',   cat:'cyber-hygiene', tech:'execution',           code:'ExecutionPrevented', archived:true },
      { name: 'Block JavaScript or VBScript from launching dow...',        host:'LAP-PF55YGBW', result:'protected',   cat:'cyber-hygiene', tech:'execution',           code:'ExecutionPrevented' },
      { name: 'Block Office communication apps from creating c...',        host:'LAP-PF55YGBW', result:'protected',   cat:'cyber-hygiene', tech:'execution',           code:'ExecutionPrevented' },
      { name: 'Account Lockout',                                           host:'LAP-PF55YGBW', result:'unprotected', cat:'cyber-hygiene', tech:'credential-access',   code:'Unprotected (101)' },
      { name: 'Lockout Threshold',                                         host:'LAP-PF55YGBW', result:'unprotected', cat:'cyber-hygiene', tech:'credential-access',   code:'Unprotected (101)' },
      { name: 'Reset Counter After',                                       host:'LAP-PF55YGBW', result:'unprotected', cat:'cyber-hygiene', tech:'credential-access',   code:'Unprotected (101)' },
      { name: 'IPv6 Tunneling Disabled',                                   host:'LAP-PF55YGBW', result:'protected',   cat:'cyber-hygiene', tech:'command-and-control', code:'ExecutionPrevented' },
      { name: 'Security Group Management',                                 host:'LAP-PF55YGBW', result:'unprotected', cat:'cyber-hygiene', tech:'persistence, privilege-escalation', code:'Unprotected (101)' },
      { name: 'Print Spooler Service',                                     host:'LAP-PF55YGBW', result:'unprotected', cat:'cyber-hygiene', tech:'execution',           code:'Unprotected (101)' },
    ],
  },

  // Risk acceptances
  riskAcceptances: [
    { id:'ra-01', test:'Print Spooler Service',           control:'WPS.001', host:'LAP-PF55YGBW',     just:'Required for shared printer access in HQ.',                          by:'Jim Hartmann',     when:'2d ago',  status:'active' },
    { id:'ra-02', test:'WPAD Disabled',                   control:'WPAD.001', host:'all hosts (global)', just:'Legacy app dependency — removal scheduled Q3.',                       by:'Sarah Chen',       when:'5d ago',  status:'active' },
    { id:'ra-03', test:'Audit Policy Change',             control:'AUD.014', host:'LAP-PF4NF654',    just:'False positive on dev workstations.',                                  by:'Sarah Chen',       when:'9d ago',  status:'active' },
    { id:'ra-04', test:'Lockout Threshold',               control:'LCK.003', host:'LAP-MZ03EPS6',    just:'Service account exception approved by IT council 2025-03-12.',          by:'Marcus Webb',      when:'12d ago', status:'active' },
    { id:'ra-05', test:'Minimum Password Length',         control:'PWD.001', host:'all hosts (global)', just:'Awaiting AD policy migration.',                                       by:'Marcus Webb',      when:'18d ago', status:'active' },
    { id:'ra-06', test:'Reset Counter After',             control:'LCK.005', host:'LAP-PF12U5Q9',    just:'Compatibility issue with kiosk software.',                              by:'Jim Hartmann',     when:'22d ago', status:'active' },
    { id:'ra-07', test:'Block executable content email',  control:'XBL.001', host:'CPC-Cesar-5K4JE', just:'Resolved — block now enforced.',                                       by:'Sarah Chen',       when:'30d ago', status:'revoked', revokedBy:'Sarah Chen', revokedReason:'Policy update completed.' },
    { id:'ra-08', test:'Account Lockout',                 control:'LCK.001', host:'all hosts (global)', just:'Test exempt during scheduled maintenance window.',                    by:'Jim Hartmann',     when:'45d ago', status:'revoked', revokedBy:'Jim Hartmann', revokedReason:'Maintenance window ended.' },
  ],

  // Defense score by host (for dashboard)
  hostScores: [
    { host:'LAP-PF55YGBW',     score: 56.3 },
    { host:'LAP-PF62CFTV',     score: 50.0 },
    { host:'LAP-PF4NF654',     score: 47.8 },
    { host:'LAP-PF1A47F0',     score: 53.2 },
    { host:'CPC-Cesar-5K4JE',  score: 60.1 },
    { host:'RG-PF12U5Q9',      score: 49.4 },
    { host:'LAP-MZ03EPS6',     score: 45.5 },
    { host:'LAP-PF4NE654',     score: 51.0 },
  ],
};
