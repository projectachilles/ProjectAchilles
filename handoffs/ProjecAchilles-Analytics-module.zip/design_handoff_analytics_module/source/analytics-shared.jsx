/* global React, Icon, I, Sparkline */
const { useState: useStateA } = React;
const AD = window.ANALYTICS_DATA;

// ── Sidebar with Analytics active ─────────────────────────────────────────
function AnSidebar() {
  const items = [
    { group: 'Tests', icon: I.flask, items: [
      { icon: I.layout, label: 'Dashboard' },
      { icon: I.grid,   label: 'Browse All' },
      { icon: I.star,   label: 'Favorites' },
    ]},
    { group: 'Analytics', icon: I.chart, items: [
      { icon: I.layout, label: 'Dashboard', active: true, key:'dashboard' },
      { icon: I.play,   label: 'Executions',           key:'executions' },
    ]},
    { group: 'Endpoints', icon: I.monitor, items: [
      { icon: I.layout, label: 'Dashboard' },
      { icon: I.bot,    label: 'Agents' },
      { icon: I.task,   label: 'Tasks' },
    ]},
  ];
  return (
    <aside className="dash-sidebar" style={{ '--side-accent': 'var(--accent)' }}>
      <div className="dash-sidebar-logo">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L4 6v6c0 5 3.5 9 8 10 4.5-1 8-5 8-10V6l-8-4z" stroke="var(--accent)" strokeWidth="1.8"/>
          <path d="M9 12l2 2 4-4" stroke="var(--accent)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        <span className="dash-sidebar-brand">ACHILLES</span>
      </div>
      <div className="dash-sidebar-section-title">Modules</div>
      {items.map(g => (
        <div key={g.group} className="dash-sidebar-group">
          <div className="dash-sidebar-group-head">
            <Icon d={g.icon} size={14} />
            <span>{g.group}</span>
          </div>
          <ul>
            {g.items.map(it => (
              <li key={it.label} className={it.active ? 'is-active' : ''}>
                <Icon d={it.icon} size={14} />
                <span>{it.label}</span>
                {it.active && <span className="dash-sidebar-active-bar" />}
              </li>
            ))}
          </ul>
        </div>
      ))}
      <div className="dash-sidebar-foot">
        <button className="dash-sidebar-settings">
          <Icon d={I.cog} size={14} />
          <span>Settings</span>
        </button>
      </div>
    </aside>
  );
}

function AnTopBar({ title='Analytics · Dashboard' }) {
  return (
    <header className="dash-topbar">
      <div className="dash-topbar-left">
        <div className="dash-topbar-title">{title}</div>
        <div className="dash-topbar-search">
          <Icon d={I.search} size={14} />
          <input placeholder="Search tests, agents, tasks…" />
          <span className="dash-topbar-kbd">⌘K</span>
        </div>
      </div>
      <div className="dash-topbar-right">
        <button className="dash-icon-btn"><Icon d={I.sync} size={16} /></button>
        <button className="dash-icon-btn"><Icon d={I.cog} size={16} /></button>
        <button className="dash-icon-btn"><Icon d={I.bell} size={16} /></button>
        <div className="dash-theme-pill">Tactical Dark ▾</div>
        <div className="dash-user-chip">
          <span className="tac-label" style={{ color: 'var(--accent)' }}>Administrator</span>
          <div className="dash-user-avatar">J</div>
        </div>
      </div>
    </header>
  );
}

// ── Tab bar (Dashboard / Executions / Risk / Defender) ───────────────
function AnTabs({ active, total, riskCount }) {
  const tabs = [
    { id:'dashboard',    label:'Dashboard',        icon: I.layout },
    { id:'executions',   label:'All Executions',   icon: I.grid, count: total },
    { id:'risk',         label:'Risk Acceptances', icon: I.shield, count: riskCount },
    { id:'defender',     label:'Defender',         icon: I.check },
  ];
  return (
    <div className="an-tabs">
      {tabs.map(t => (
        <button key={t.id} className={`an-tab ${active===t.id?'is-active':''}`}>
          <Icon d={t.icon} size={13} />
          <span>{t.label}</span>
          {t.count != null && <span className="an-tab-count">{t.count.toLocaleString()}</span>}
        </button>
      ))}
      <div className="an-tabs-right">
        <button className="an-pill"><Icon d={I.filter} size={11}/> Filters</button>
        <button className="an-pill"><Icon d={I.clock}  size={11}/> Last 7 days ▾</button>
      </div>
    </div>
  );
}

// ── Multi-line trend chart with grid + axis ─────────────────────────
function TrendChart({ width=720, height=240, padding=36 }) {
  const { days, defense, secure, error } = AD.trend;
  const w = width - padding*2, h = height - padding - 16;
  const xStep = w / (days.length - 1);
  const yScale = v => h - (v/100) * h + 12;
  const errYScale = v => h - (v/8) * h + 12; // 0..8% scale for error rate
  const linePath = (vals, scale=yScale) => vals.map((v,i)=> `${i===0?'M':'L'}${padding + i*xStep},${scale(v)}`).join(' ');
  const areaPath = (vals, scale=yScale) => `${linePath(vals,scale)} L${padding + w},${scale(0)} L${padding},${scale(0)} Z`;

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="an-trend-svg" preserveAspectRatio="none">
      {/* gridlines */}
      {[0,25,50,75,100].map(v => (
        <g key={v}>
          <line x1={padding} y1={yScale(v)} x2={padding+w} y2={yScale(v)} stroke="rgba(255,255,255,.04)" strokeDasharray="2 4"/>
          <text x={padding-8} y={yScale(v)+4} fill="#6b7388" fontSize="9.5" textAnchor="end" fontFamily="var(--font-mono)">{v}%</text>
        </g>
      ))}
      {/* x labels (every ~5 days) */}
      {days.map((d,i)=> i % 4 === 0 && (
        <text key={i} x={padding+i*xStep} y={height-2} fill="#6b7388" fontSize="9.5" textAnchor="middle" fontFamily="var(--font-mono)">{d}</text>
      ))}
      {/* secure score */}
      <path d={areaPath(secure)} fill="rgba(0,230,138,.10)" />
      <path d={linePath(secure)} fill="none" stroke="var(--accent)" strokeWidth="2" />
      {/* defense score */}
      <path d={areaPath(defense)} fill="rgba(79,142,255,.12)" />
      <path d={linePath(defense)} fill="none" stroke="var(--signal)" strokeWidth="2" />
      {/* error rate (right axis) */}
      <path d={linePath(error, errYScale)} fill="none" stroke="var(--danger)" strokeWidth="1.5" strokeDasharray="3 3"/>
    </svg>
  );
}

// ── Donut (used in error type / categories) ─────────────────────────
function Donut({ data, size=140, thickness=22, label, sublabel }) {
  const total = data.reduce((s,x)=>s+x.pct, 0);
  let acc = 0;
  const r = size/2 - thickness/2;
  const cx = size/2, cy = size/2;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      {data.map((d,i) => {
        const start = (acc/total) * Math.PI*2 - Math.PI/2;
        const end = ((acc + d.pct)/total) * Math.PI*2 - Math.PI/2;
        acc += d.pct;
        const x1 = cx + r*Math.cos(start);
        const y1 = cy + r*Math.sin(start);
        const x2 = cx + r*Math.cos(end);
        const y2 = cy + r*Math.sin(end);
        const large = end - start > Math.PI ? 1 : 0;
        return (
          <path key={i} d={`M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2} Z`}
            fill="none" stroke={d.color} strokeWidth={thickness} />
        );
      })}
      {label && (
        <text x={cx} y={cy-2} textAnchor="middle" fontSize="20" fontWeight="700" fill="var(--text-primary)" fontFamily="var(--font-display)">{label}</text>
      )}
      {sublabel && (
        <text x={cx} y={cy+14} textAnchor="middle" fontSize="9" fill="var(--text-muted)" fontFamily="var(--font-mono)" letterSpacing=".15em">{sublabel}</text>
      )}
    </svg>
  );
}

// ── Sunburst (categories nested) ─────────────────────────────────────
function Sunburst({ data, size=160 }) {
  const cx = size/2, cy = size/2;
  const rOuter = size/2 - 4;
  const rInnerMid = rOuter - 18;
  const rCore = rInnerMid - 18;
  const total = data.reduce((s,c)=> s + c.subs.reduce((a,x)=>a+1,0), 0);
  let acc = 0;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      {/* outer ring: subcategories */}
      {data.flatMap((c, ci) => c.subs.map((s, si) => {
        const start = (acc/total) * Math.PI*2 - Math.PI/2;
        acc += 1;
        const end = (acc/total) * Math.PI*2 - Math.PI/2;
        const x1 = cx + rOuter*Math.cos(start), y1 = cy + rOuter*Math.sin(start);
        const x2 = cx + rOuter*Math.cos(end),   y2 = cy + rOuter*Math.sin(end);
        const x3 = cx + rInnerMid*Math.cos(end), y3 = cy + rInnerMid*Math.sin(end);
        const x4 = cx + rInnerMid*Math.cos(start), y4 = cy + rInnerMid*Math.sin(start);
        const large = end - start > Math.PI ? 1 : 0;
        return (
          <path key={`${ci}-${si}`} d={`M ${x1} ${y1} A ${rOuter} ${rOuter} 0 ${large} 1 ${x2} ${y2} L ${x3} ${y3} A ${rInnerMid} ${rInnerMid} 0 ${large} 0 ${x4} ${y4} Z`}
            fill={c.color} opacity={0.45 + si*0.18} stroke="#0a0e1a" strokeWidth="1"/>
        );
      }))}
      {/* inner ring: categories */}
      {(() => {
        let cAcc = 0;
        return data.map((c, i) => {
          const cStart = (cAcc/total) * Math.PI*2 - Math.PI/2;
          cAcc += c.subs.length;
          const cEnd = (cAcc/total) * Math.PI*2 - Math.PI/2;
          const x1 = cx + rInnerMid*Math.cos(cStart), y1 = cy + rInnerMid*Math.sin(cStart);
          const x2 = cx + rInnerMid*Math.cos(cEnd),   y2 = cy + rInnerMid*Math.sin(cEnd);
          const x3 = cx + rCore*Math.cos(cEnd), y3 = cy + rCore*Math.sin(cEnd);
          const x4 = cx + rCore*Math.cos(cStart), y4 = cy + rCore*Math.sin(cStart);
          const large = cEnd - cStart > Math.PI ? 1 : 0;
          return (
            <path key={i} d={`M ${x1} ${y1} A ${rInnerMid} ${rInnerMid} 0 ${large} 1 ${x2} ${y2} L ${x3} ${y3} A ${rCore} ${rCore} 0 ${large} 0 ${x4} ${y4} Z`}
              fill={c.color} stroke="#0a0e1a" strokeWidth="1.5"/>
          );
        });
      })()}
      <circle cx={cx} cy={cy} r={rCore} fill="#0a0e1a" stroke="rgba(255,255,255,.06)"/>
    </svg>
  );
}

// ── Page shell ────────────────────────────────────────────────────────
function AnShell({ title, activeTab, label, children }) {
  return (
    <div className="dash-shell" data-screen-label={label || title}>
      <AnSidebar />
      <div style={{ display:'flex', flexDirection:'column', minWidth: 0 }}>
        <AnTopBar title={title} />
        <AnTabs active={activeTab} total={AD.totalExecutions} riskCount={AD.riskAcceptances.filter(r=>r.status==='active').length} />
        <main className="an-main">
          <div className="an-scroll">{children}</div>
        </main>
      </div>
    </div>
  );
}

Object.assign(window, { AnSidebar, AnTopBar, AnTabs, TrendChart, Donut, Sunburst, AnShell });
