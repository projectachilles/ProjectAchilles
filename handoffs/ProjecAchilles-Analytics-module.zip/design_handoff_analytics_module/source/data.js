// ── Mock data for Achilles dashboard ─────────────────────────────────────────

window.DASHBOARD_DATA = {
  branch: 'main',
  commit: '4238c50',
  syncedAgo: '6m ago',
  agentStatus: 'online',
  totalTests: 53,
  techniques: 116,
  tactics: 12,
  categories: 3,
  avgScore: 8.719,
  testsScored: 53,
  critical: 12,
  high: 27,
  medium: 9,
  low: 5,

  // KPI sparkline data (14 days)
  trends: {
    tests:      [38, 39, 41, 42, 44, 46, 47, 47, 49, 50, 51, 52, 52, 53],
    techniques: [88, 90, 92, 95, 99,102,104,106,108,110,111,113,114,116],
    categories: [ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,  3],
    score:      [7.8, 7.9, 8.0, 8.1, 8.2, 8.2, 8.3, 8.4, 8.5, 8.5, 8.6, 8.65, 8.7, 8.719],
  },

  // MITRE ATT&CK tactics (12)
  tactics_data: [
    { id:'IA', name:'Initial Access',         techniques: 9,  covered: 6 },
    { id:'EX', name:'Execution',              techniques: 14, covered: 11 },
    { id:'PE', name:'Persistence',            techniques: 12, covered: 8 },
    { id:'PR', name:'Privilege Escalation',   techniques: 10, covered: 5 },
    { id:'DE', name:'Defense Evasion',        techniques: 22, covered: 18 },
    { id:'CA', name:'Credential Access',      techniques: 11, covered: 7 },
    { id:'DI', name:'Discovery',              techniques: 13, covered: 4 },
    { id:'LM', name:'Lateral Movement',       techniques: 9,  covered: 3 },
    { id:'CO', name:'Collection',             techniques: 8,  covered: 2 },
    { id:'C2', name:'Command & Control',      techniques: 12, covered: 9 },
    { id:'EF', name:'Exfiltration',           techniques: 7,  covered: 4 },
    { id:'IM', name:'Impact',                 techniques: 9,  covered: 6 },
  ],

  // Categories
  category_data: [
    { id:'cyber-hygiene', name:'cyber-hygiene', count: 30, color: '#4f8eff' },
    { id:'intel-driven',  name:'intel-driven',  count: 13, color: '#a78bfa' },
    { id:'mitre-top10',   name:'mitre-top10',   count: 10, color: '#22d3ee' },
  ],

  // Top rated tests
  topRated: [
    { id:1, name:'MDE Process Injection and API Authentication Bypass',         severity:'critical', score:9.7 },
    { id:2, name:'ESXi Hypervisor Ransomware Kill Chain (RansomHub/Akira)',     severity:'critical', score:9.6 },
    { id:3, name:'CIS Windows Endpoint Level 1 Hardening Bundle',               severity:'high',     score:9.4 },
    { id:4, name:'PROMPTFLUX v1 — LLM-Assisted VBScript Dropper',               severity:'high',     score:9.4 },
    { id:5, name:'Perfctl/Symbiote LD_PRELOAD Hijacking with PAM Harvesting',   severity:'critical', score:9.4 },
    { id:6, name:'Volt Typhoon Living-off-the-Land WMIC Discovery Chain',       severity:'critical', score:9.3 },
    { id:7, name:'Kerberoasting + AS-REP Roast Combined Workflow',              severity:'high',     score:9.2 },
  ],

  // Recently modified
  recentlyModified: [
    { id:1, name:'Entra ID Tenant Security Hygiene Bundle',                      severity:'critical', when:'today' },
    { id:2, name:'ISACA ITGC Windows Endpoint Validation Bundle',                severity:'high',     when:'today' },
    { id:3, name:'ISACA ITGC AD Identity Validation Bundle',                     severity:'critical', when:'today' },
    { id:4, name:'Nightmare-Eclipse RedSun Cloud Files Rewrite Primitive Chain', severity:'high',     when:'today' },
    { id:5, name:'BlueHammer Early-Stage Behavioral Pattern',                    severity:'high',     when:'today' },
    { id:6, name:'CrowdStrike Falcon Sensor Bypass via DLL Side-loading',        severity:'critical', when:'2h ago' },
    { id:7, name:'Microsoft Defender for Cloud Apps Eval Bundle',                severity:'medium',   when:'5h ago' },
  ],

  // Coverage gaps (worst tactics)
  gaps: [
    { id:'CO', name:'Collection',         techniques: 8,  covered: 2, pct: 25 },
    { id:'LM', name:'Lateral Movement',   techniques: 9,  covered: 3, pct: 33 },
    { id:'DI', name:'Discovery',          techniques: 13, covered: 4, pct: 31 },
  ],

  // Terminal log lines (typed-out feel)
  terminalLines: [
    { kind:'cmt',  text:'# achilles · live activity stream' },
    { kind:'prompt', text:'$', cmd:'achilles sync --branch main' },
    { kind:'ok',   text:'✓ pulled 53 tests, 116 techniques' },
    { kind:'out',  text:'  → 4 added · 7 modified · 0 removed' },
    { kind:'prompt', text:'$', cmd:'achilles run --severity critical' },
    { kind:'out',  text:'queued 12 critical tests' },
    { kind:'ok',   text:'[01/12] MDE Process Injection ······· PASS  9.7' },
    { kind:'ok',   text:'[02/12] ESXi Ransomware Kill Chain ·· PASS  9.6' },
    { kind:'warn', text:'[03/12] Volt Typhoon LotL ··········· PARTIAL  7.1' },
    { kind:'cmt',  text:'# coverage gap detected · tactic=Collection (CO)' },
  ],
};
