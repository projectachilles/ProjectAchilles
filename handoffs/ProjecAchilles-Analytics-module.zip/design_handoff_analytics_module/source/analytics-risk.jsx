/* global React, Icon, I, AnShell */
const AD_R = window.ANALYTICS_DATA;

// ── V1: tactical table ──────────────────────────────────────────────
function RiskAcceptancesV1() {
  const active = AD_R.riskAcceptances.filter(r => r.status==='active');
  const revoked = AD_R.riskAcceptances.filter(r => r.status==='revoked');
  return (
    <AnShell title="Analytics · Risk Acceptances" activeTab="risk" label="Analytics — Risk Acceptances V1">
      <div style={{ display:'flex', gap:8, padding:'12px 0', alignItems:'center' }}>
        <button className="an-pill primary"><Icon d={I.shield} size={11}/>ACTIVE · {active.length}</button>
        <button className="an-pill"><Icon d={I.bell} size={11}/>REVOKED · {revoked.length}</button>
        <button className="an-pill"><Icon d={I.grid} size={11}/>ALL · {AD_R.riskAcceptances.length}</button>
        <span style={{ marginLeft:'auto', fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-muted)' }}>
          {active.length} ACTIVE · {revoked.length} REVOKED · WINDOW 90D
        </span>
      </div>

      <div className="an-card" style={{ padding: 0 }}>
        <table className="an-risk-table">
          <thead>
            <tr>
              <th>Test</th>
              <th>Control</th>
              <th>Scope</th>
              <th>Justification</th>
              <th>Accepted by</th>
              <th>When</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {AD_R.riskAcceptances.map(r => {
              const isGlobal = r.host.includes('global');
              return (
                <tr key={r.id}>
                  <td><span className="an-risk-test">{r.test}</span></td>
                  <td><span className="an-exec-host">{r.control}</span></td>
                  <td>
                    {isGlobal
                      ? <span className="an-exec-cat" style={{ background:'rgba(167,139,250,.1)', borderColor:'rgba(167,139,250,.3)', color:'#a78bfa' }}><Icon d={I.target} size={10}/> global</span>
                      : <span className="an-exec-host">{r.host}</span>}
                  </td>
                  <td><span className="an-risk-just">{r.just}
                    {r.status==='revoked' && <span className="an-risk-revoked-meta">↳ revoked: {r.revokedReason}</span>}
                  </span></td>
                  <td><span className="an-risk-by">{r.by}</span></td>
                  <td><span className="an-risk-when">{r.when}</span></td>
                  <td>
                    <span className={`an-risk-status ${r.status==='active'?'is-active':'is-revoked'}`}>
                      {r.status==='active'? <><Icon d={I.alert} size={9}/>ACTIVE</> : <><Icon d={I.check} size={9}/>REVOKED</>}
                    </span>
                  </td>
                  <td>
                    {r.status==='active' && <button className="an-pill" style={{ padding:'4px 8px' }}>REVOKE</button>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </AnShell>
  );
}

// ── V2: card grid ───────────────────────────────────────────────────
function RiskAcceptancesV2() {
  return (
    <AnShell title="Analytics · Risk Acceptances" activeTab="risk" label="Analytics — Risk Acceptances V2">
      <div style={{ display:'flex', gap:8, padding:'12px 0', alignItems:'center' }}>
        <button className="an-pill primary"><Icon d={I.shield} size={11}/>ACTIVE</button>
        <button className="an-pill"><Icon d={I.bell} size={11}/>REVOKED</button>
        <button className="an-pill"><Icon d={I.grid} size={11}/>ALL</button>
        <span style={{ marginLeft:'auto', fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-muted)' }}>
          CARD VIEW · 8 ACCEPTANCES
        </span>
      </div>

      <div className="an-risk-grid">
        {AD_R.riskAcceptances.map(r => {
          const isGlobal = r.host.includes('global');
          return (
            <div key={r.id} className={`an-risk-cardv2 ${r.status==='revoked'?'is-revoked':''}`}>
              <div className="an-risk-cardv2-head">
                <div>
                  <div className="an-risk-cardv2-test">{r.test}</div>
                  <div style={{ display:'flex', gap:6, marginTop:6, alignItems:'center' }}>
                    <span className="an-exec-host">{r.control}</span>
                    {isGlobal
                      ? <span className="an-exec-cat" style={{ background:'rgba(167,139,250,.1)', borderColor:'rgba(167,139,250,.3)', color:'#a78bfa' }}>global</span>
                      : <span className="an-exec-host" style={{ color:'var(--text-muted)' }}>· {r.host}</span>}
                  </div>
                </div>
                <span className={`an-risk-status ${r.status==='active'?'is-active':'is-revoked'}`}>
                  {r.status==='active'? 'ACTIVE' : 'REVOKED'}
                </span>
              </div>
              <div className="an-risk-cardv2-just">"{r.just}"</div>
              {r.status==='revoked' && (
                <div className="an-risk-cardv2-just" style={{ borderLeftColor:'var(--text-faint)', color:'var(--text-muted)' }}>
                  ↳ {r.revokedReason}
                </div>
              )}
              <div className="an-risk-cardv2-meta">
                <div>
                  <div className="an-risk-cardv2-meta-label">ACCEPTED BY</div>
                  <div className="an-risk-cardv2-meta-val">{r.by}</div>
                </div>
                <div>
                  <div className="an-risk-cardv2-meta-label">WHEN</div>
                  <div className="an-risk-cardv2-meta-val">{r.when}</div>
                </div>
              </div>
              {r.status==='active' && (
                <div style={{ display:'flex', gap:6, marginTop:4 }}>
                  <button className="an-pill" style={{ padding:'5px 10px' }}><Icon d={I.bell} size={10}/>REVOKE</button>
                  <button className="an-pill" style={{ padding:'5px 10px' }}><Icon d={I.search} size={10}/>VIEW EXECUTIONS</button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </AnShell>
  );
}

Object.assign(window, { RiskAcceptancesV1, RiskAcceptancesV2 });
