/* global React, ReactDOM, DesignCanvas, DCSection, DCArtboard,
   AnalyticsDashboard, AnalyticsExecutions, AnalyticsDefender,
   RiskAcceptancesV1, RiskAcceptancesV2 */
const { createRoot: createRootA } = ReactDOM;

function AnalyticsApp() {
  return (
    <DesignCanvas
      title="Achilles · Analytics Module Redesign"
      subtitle="Tactical-green direction · selected from Tests Module · 4 tabs + Risk variation"
      backgroundColor="#02040a"
    >
      <DCSection id="dashboard" title="Tab · Dashboard" subtitle="Hero scores, trend, controls, breakdowns">
        <DCArtboard id="dash" label="Analytics — Dashboard" width={1440} height={1900} background="#02040a">
          <AnalyticsDashboard/>
        </DCArtboard>
      </DCSection>

      <DCSection id="executions" title="Tab · All Executions" subtitle="Grouped bundle table with expandable child rows">
        <DCArtboard id="execs" label="Analytics — All Executions" width={1440} height={1400} background="#02040a">
          <AnalyticsExecutions/>
        </DCArtboard>
      </DCSection>

      <DCSection id="defender" title="Tab · Defender" subtitle="Secure Score, top controls, detection analysis, technique overlap">
        <DCArtboard id="def" label="Analytics — Defender" width={1440} height={1300} background="#02040a">
          <AnalyticsDefender/>
        </DCArtboard>
      </DCSection>

      <DCSection id="risk" title="Tab · Risk Acceptances" subtitle="Tactical table — selected direction">
        <DCArtboard id="risk-v1" label="Analytics — Risk Acceptances" width={1440} height={900} background="#02040a">
          <RiskAcceptancesV1/>
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

createRootA(document.getElementById('root')).render(<AnalyticsApp/>);
