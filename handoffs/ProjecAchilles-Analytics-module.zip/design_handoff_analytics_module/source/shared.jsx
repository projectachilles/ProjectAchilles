/* global React */
const { useState, useEffect, useMemo, useRef } = React;
const D = window.DASHBOARD_DATA;

// ── Inline icon set (lucide-style strokes) ───────────────────────────────────
const Icon = ({ d, size = 16, fill = 'none', sw = 1.6, style }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor"
    strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" style={style}>
    {typeof d === 'string' ? <path d={d} /> : d}
  </svg>
);
const I = {
  shield:  <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/></>,
  flask:  <><path d="M9 3h6"/><path d="M10 3v6L4.5 19a2 2 0 0 0 1.7 3h11.6a2 2 0 0 0 1.7-3L14 9V3"/></>,
  layout: <><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/></>,
  grid:   <><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></>,
  star:   <><path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></>,
  chart:  <><path d="M3 3v18h18"/><path d="M7 16l4-4 4 4 5-7"/></>,
  play:   <><polygon points="5,3 19,12 5,21"/></>,
  monitor:<><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8"/><path d="M12 17v4"/></>,
  bot:    <><rect x="3" y="11" width="18" height="10" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4"/><path d="M8 16h.01"/><path d="M16 16h.01"/></>,
  task:   <><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></>,
  cog:    <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></>,
  search: <><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></>,
  bell:   <><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></>,
  branch: <><circle cx="6" cy="3" r="2"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="9" r="2"/><path d="M6 5v8a4 4 0 0 0 4 4h2"/><path d="M18 11v3"/></>,
  clock:  <><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></>,
  sync:   <><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></>,
  arrow:  <><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></>,
  bolt:   <><path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/></>,
  download: <><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/></>,
  filter: <><path d="M22 3H2l8 9.46V19l4 2v-8.54L22 3z"/></>,
  alert:  <><path d="M12 9v4"/><path d="M12 17h.01"/><path d="m10.29 3.86-8.55 14.83A2 2 0 0 0 3.47 22h17.06a2 2 0 0 0 1.73-3.31L13.71 3.86a2 2 0 0 0-3.42 0z"/></>,
  check:  <><path d="M20 6 9 17l-5-5"/></>,
  cmd:    <><path d="M18 3a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3H6a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3V6a3 3 0 0 0-3-3 3 3 0 0 0-3 3 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/></>,
  user:   <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
  spark:  <><path d="M3 17l4-8 4 5 4-10 4 8 2-3"/></>,
  arrowU: <><path d="m5 12 7-7 7 7"/><path d="M12 19V5"/></>,
  target: <><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></>,
};

// ─────────────────────────────────────────────────────────────────────────────
// SHARED CHROME — sidebar, topbar, branch pill
// ─────────────────────────────────────────────────────────────────────────────
function Sidebar({ accentColor = 'var(--accent)' }) {
  const items = [
    { group: 'Tests', icon: I.flask, items: [
      { icon: I.layout, label: 'Dashboard', active: true },
      { icon: I.grid,   label: 'Browse All' },
      { icon: I.star,   label: 'Favorites' },
    ]},
    { group: 'Analytics', icon: I.chart, items: [
      { icon: I.layout, label: 'Dashboard' },
      { icon: I.play,   label: 'Executions' },
    ]},
    { group: 'Endpoints', icon: I.monitor, items: [
      { icon: I.layout, label: 'Dashboard' },
      { icon: I.bot,    label: 'Agents' },
      { icon: I.task,   label: 'Tasks' },
    ]},
  ];

  return (
    <aside className="dash-sidebar" style={{ '--side-accent': accentColor }}>
      <div className="dash-sidebar-logo">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L4 6v6c0 5 3.5 9 8 10 4.5-1 8-5 8-10V6l-8-4z"
            stroke={accentColor} strokeWidth="1.8"/>
          <path d="M9 12l2 2 4-4" stroke={accentColor} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        <span className="dash-sidebar-brand">ACHILLES</span>
      </div>

      <div className="dash-sidebar-section-title">Modules</div>
      {items.map((g) => (
        <div key={g.group} className="dash-sidebar-group">
          <div className="dash-sidebar-group-head">
            <Icon d={g.icon} size={14} />
            <span>{g.group}</span>
          </div>
          <ul>
            {g.items.map(it => (
              <li key={it.label} className={it.active ? 'is-active' : ''}>
                <Icon d={it.icon} size={14} />
                <span>{it.label}</span>
                {it.active && <span className="dash-sidebar-active-bar" />}
              </li>
            ))}
          </ul>
        </div>
      ))}

      <div className="dash-sidebar-foot">
        <button className="dash-sidebar-settings">
          <Icon d={I.cog} size={14} />
          <span>Settings</span>
        </button>
      </div>
    </aside>
  );
}

function TopBar({ title = 'Home', user = 'Jim' }) {
  return (
    <header className="dash-topbar">
      <div className="dash-topbar-left">
        <div className="dash-topbar-title">{title}</div>
        <div className="dash-topbar-search">
          <Icon d={I.search} size={14} />
          <input placeholder="Search tests, agents, tasks…" />
          <span className="dash-topbar-kbd">⌘K</span>
        </div>
      </div>
      <div className="dash-topbar-right">
        <button className="dash-icon-btn"><Icon d={I.bell} size={16} /></button>
        <button className="dash-icon-btn"><Icon d={I.cmd} size={16} /></button>
        <div className="dash-theme-pill">Tactical Dark ▾</div>
        <div className="dash-user-chip">
          <span className="tac-label" style={{ color:'var(--accent)' }}>Administrator</span>
          <div className="dash-user-avatar">{user[0]}</div>
        </div>
      </div>
    </header>
  );
}

function BranchPill() {
  return (
    <div className="dash-branch">
      <div className="dash-branch-item">
        <Icon d={I.branch} size={12} />
        <span className="font-mono">{D.branch}</span>
        <span className="dash-branch-sha">{D.commit}</span>
      </div>
      <div className="dash-branch-sep" />
      <div className="dash-branch-item">
        <Icon d={I.clock} size={12} />
        <span>synced {D.syncedAgo}</span>
      </div>
      <div className="dash-branch-sep" />
      <div className="dash-branch-item">
        <span className="dot dot-pulse" style={{ background:'var(--accent)', color:'var(--accent)' }} />
        <span className="font-mono" style={{ color:'var(--accent)' }}>agent online</span>
      </div>
      <div className="dash-branch-spacer" />
      <button className="dash-quick-btn primary">
        <Icon d={I.sync} size={12} /><span>Sync</span>
      </button>
    </div>
  );
}

function QuickActions() {
  const actions = [
    { icon: I.bolt,   label: 'Run all critical', tone:'primary' },
    { icon: I.play,   label: 'Run new tests',    tone:'ghost' },
    { icon: I.target, label: 'Plan campaign',    tone:'ghost' },
    { icon: I.download, label: 'Export report',  tone:'ghost' },
    { icon: I.filter, label: 'Filters',          tone:'ghost' },
  ];
  return (
    <div className="dash-quick-row">
      {actions.map(a => (
        <button key={a.label} className={`dash-quick-btn ${a.tone}`}>
          <Icon d={a.icon} size={12} />
          <span>{a.label}</span>
        </button>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SPARKLINE
// ─────────────────────────────────────────────────────────────────────────────
function Sparkline({ data, color = 'var(--accent)', w = 110, h = 28, fill = true }) {
  const min = Math.min(...data), max = Math.max(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / range) * (h - 4) - 2;
    return [x, y];
  });
  const path = pts.map((p, i) => (i === 0 ? `M${p[0]},${p[1]}` : `L${p[0]},${p[1]}`)).join(' ');
  const area = `${path} L${w},${h} L0,${h} Z`;
  return (
    <svg width={w} height={h} style={{ display:'block' }}>
      {fill && <path d={area} fill={color} opacity="0.12" />}
      <path d={path} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={pts[pts.length-1][0]} cy={pts[pts.length-1][1]} r="2.5" fill={color} />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// TERMINAL PANEL
// ─────────────────────────────────────────────────────────────────────────────
function TerminalPanel({ accent = 'var(--accent)' }) {
  return (
    <div className="dash-terminal" style={{ '--term-accent': accent }}>
      <div className="dash-terminal-head">
        <span className="dash-terminal-dot" style={{ background:'#ff5f57' }} />
        <span className="dash-terminal-dot" style={{ background:'#febc2e' }} />
        <span className="dash-terminal-dot" style={{ background:'#28c840' }} />
        <span className="dash-terminal-title">achilles · stream.log</span>
        <span className="dash-terminal-status">
          <span className="dot dot-pulse" style={{ background: accent, color: accent }} />
          LIVE
        </span>
      </div>
      <div className="dash-terminal-body">
        {D.terminalLines.map((l, i) => {
          if (l.kind === 'prompt') return (
            <div key={i} className="term-line"><span className="term-prompt">{l.text}</span> <span className="term-cmd">{l.cmd}</span></div>
          );
          return <div key={i} className={`term-line term-${l.kind}`}>{l.text}</div>;
        })}
        <div className="term-line"><span className="term-prompt">$</span> <span className="term-cursor" /></div>
      </div>
    </div>
  );
}

// Export to global so other scripts can use them
Object.assign(window, { Icon, I, Sidebar, TopBar, BranchPill, QuickActions, Sparkline, TerminalPanel });
