/* global React, Icon, I, AnShell, TrendChart, Donut, Sunburst */
const AD_DASH = window.ANALYTICS_DATA;

// ── Hero score card (shared with Defender, configurable) ─────────────
function HeroScoreCard({ kind = 'defense' }) {
  const isDef = kind === 'defense';
  const value  = isDef ? AD_DASH.defenseScore.toFixed(1) + '%' : AD_DASH.secureScore.toFixed(1) + '%';
  const label  = isDef ? 'Defense Score' : 'Secure Score';
  const sub    = isDef
    ? `Across ${AD_DASH.endpoints} endpoints, ${AD_DASH.testsCount} tests`
    : `${AD_DASH.secureScoreCurrent.toFixed(1)} / ${AD_DASH.secureScoreMax.toFixed(1)} pts`;
  const delta  = isDef ? '+1.2 pts (24h)' : '+3.4 pts (7d)';

  return (
    <div className="an-card" style={{ padding: 0, display: 'flex', flexDirection: 'column' }}>
      <div className="an-hero-score">
        <span className="an-hero-score-label">
          <Icon d={I.shield} size={14} />
          {label}
        </span>
        <div className={`an-hero-score-value ${isDef ? 'is-defense' : 'is-secure'}`}>{value}</div>
        <div className="an-hero-score-delta">
          <Icon d={I.arrowU} size={9} sw={2} />
          {delta}
        </div>
        <div className="an-hero-score-sub">{sub}</div>
      </div>
      <div className="an-kpi-strip">
        <div className="an-kpi-cell">
          <span className="an-kpi-cell-label"><Icon d={I.monitor} size={10}/> ENDPOINTS</span>
          <span className="an-kpi-cell-value">{AD_DASH.endpoints}</span>
        </div>
        <div className="an-kpi-cell">
          <span className="an-kpi-cell-label"><Icon d={I.flask} size={10}/> TESTS</span>
          <span className="an-kpi-cell-value">{AD_DASH.testsCount}</span>
        </div>
      </div>
    </div>
  );
}

// ── Trend overview card ─────────────────────────────────────────────
function TrendOverviewCard() {
  return (
    <div className="an-card">
      <div className="an-card-head">
        <div>
          <div className="an-card-title">
            <Icon d={I.chart} size={13}/> Trend Overview
          </div>
          <div className="an-card-sub">21 DAYS · DEFENSE · SECURE · ERROR-RATE</div>
        </div>
        <div className="an-trend-stats">
          <span>WINDOW <span className="an-trend-stat-val">21d</span></span>
          <span>EXECS <span className="an-trend-stat-val">{AD_DASH.totalExecutions.toLocaleString()}</span></span>
          <span>GROUPS <span className="an-trend-stat-val">{AD_DASH.groupsCount}</span></span>
        </div>
      </div>
      <TrendChart width={820} height={260} />
      <div className="an-trend-legend">
        <span className="an-trend-legend-item"><span className="an-trend-legend-swatch" style={{ background:'var(--accent)' }}/>Secure Score</span>
        <span className="an-trend-legend-item"><span className="an-trend-legend-swatch" style={{ background:'var(--signal)' }}/>Defense Score</span>
        <span className="an-trend-legend-item"><span className="an-trend-legend-swatch" style={{ background:'var(--danger)', opacity:.6 }}/>Error Rate (right axis)</span>
        <span style={{ marginLeft:'auto', color:'var(--text-faint)' }}>Apr 5 — Apr 25</span>
      </div>
    </div>
  );
}

// ── Top remediation controls (Defender) ─────────────────────────────
function TopControlsCard() {
  return (
    <div className="an-card">
      <div className="an-card-head">
        <div>
          <div className="an-card-title">
            <Icon d={I.shield} size={13}/> Top Remediation Controls
          </div>
          <div className="an-card-sub">RANKED BY DEFENDER · MAX-SCORE WEIGHT</div>
        </div>
        <button className="an-pill"><Icon d={I.arrow} size={11}/>VIEW ALL</button>
      </div>
      <div className="an-list">
        {AD_DASH.topControls.map(c => (
          <div key={c.rank} className="an-list-row">
            <span className="an-list-rank">{String(c.rank).padStart(2,'0')}</span>
            <span className="an-list-title">{c.title}</span>
            <span className="an-list-cat">{c.cat}</span>
            <span className="an-list-score">+{c.score.toFixed(2)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Score by category sunburst ──────────────────────────────────────
function ScoreByCategoryCard() {
  return (
    <div className="an-card">
      <div className="an-card-head">
        <div>
          <div className="an-card-title">
            <Icon d={I.target} size={13}/> Score by Category
          </div>
          <div className="an-card-sub">CATEGORY · SUBCATEGORY · DEFENSE-WEIGHTED</div>
        </div>
      </div>
      <div className="an-donut-wrap" style={{ gridTemplateColumns:'180px 1fr' }}>
        <Sunburst data={AD_DASH.categories} size={170} />
        <div>
          {AD_DASH.categories.map(c => (
            <div key={c.id}>
              <div className="an-cat-row">
                <span className="an-legend-dot" style={{ background:c.color }} />
                <span className="an-cat-name">{c.name}</span>
                <span className="an-cat-pct">{c.score.toFixed(1)}%</span>
              </div>
              {c.subs.map(s => (
                <div key={s.name} className="an-cat-row" style={{ paddingLeft: 22 }}>
                  <span style={{ width:8, height:8, borderRadius:'50%', background:c.color, opacity:.55 }} />
                  <span className="an-cat-sub">↳ {s.name}</span>
                  <span className="an-cat-pct">{s.score.toFixed(1)}%</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Test activity card ──────────────────────────────────────────────
function TestActivityCard() {
  const todayCount = 12;
  return (
    <div className="an-card">
      <div className="an-card-head">
        <div>
          <div className="an-card-title">
            <Icon d={I.bolt} size={13}/> Test Activity
          </div>
          <div className="an-card-sub">TODAY · PROTECTED 7 / 12 · {AD_DASH.recentTests.length} RECENT</div>
        </div>
        <button className="an-pill"><Icon d={I.arrow} size={11}/>OPEN EXECUTIONS</button>
      </div>
      <div className="an-activity-card">
        <div className="an-activity-bigday">
          <div className="an-activity-num">{todayCount}</div>
          <div className="an-activity-numlabel">EXECUTED</div>
          <div className="an-activity-date">25 APR 2025</div>
          <div className="an-activity-tests">7 protected</div>
        </div>
        <div className="an-activity-list">
          {AD_DASH.recentTests.map((t,i) => (
            <div key={i} className="an-activity-item">
              <div className={`an-activity-item-icon ${t.result==='protected'?'ok':'fail'}`}>
                <Icon d={t.result==='protected'? I.check : I.alert} size={12} sw={2.4}/>
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                <div className="an-activity-item-name" style={{ overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{t.name}</div>
                <div className="an-activity-item-host">{t.host}</div>
              </div>
              <div className="an-activity-item-when">{t.when}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Error type donut ────────────────────────────────────────────────
function ErrorTypeCard() {
  const total = AD_DASH.errorTypes.reduce((s,x)=>s+x.count, 0);
  return (
    <div className="an-card">
      <div className="an-card-head">
        <div>
          <div className="an-card-title">
            <Icon d={I.target} size={13}/> Results by Error Type
          </div>
          <div className="an-card-sub">{total} EXECUTIONS · LAST 7 DAYS</div>
        </div>
      </div>
      <div className="an-donut-wrap">
        <Donut data={AD_DASH.errorTypes} size={150} thickness={22} label={total.toString()} sublabel="TOTAL" />
        <div className="an-donut-legend">
          {AD_DASH.errorTypes.map(e => (
            <div key={e.name} className="an-donut-legend-row">
              <span className="an-donut-swatch" style={{ background:e.color }}/>
              <span><span className="an-donut-name">{e.name}</span> <span className="an-donut-name-sub"> · {e.count}</span></span>
              <span className="an-donut-pct">{e.pct.toFixed(1)}%</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── ATT&CK technique distribution ───────────────────────────────────
function TechniqueDistCard() {
  return (
    <div className="an-card">
      <div className="an-card-head">
        <div>
          <div className="an-card-title">
            <Icon d={I.grid} size={13}/> ATT&amp;CK Technique Distribution
          </div>
          <div className="an-card-sub">TOP 10 · EXECUTIONS PER TECHNIQUE · OVERLAP WITH DEFENDER</div>
        </div>
        <span style={{ fontFamily:'var(--font-mono)', fontSize:10, padding:'2px 7px', borderRadius:2, background:'var(--accent-bg)', color:'var(--accent)', border:'1px solid var(--accent-dim)', letterSpacing:'.08em' }}>
          2 W/ DEFENDER ALERTS
        </span>
      </div>
      <div>
        {AD_DASH.techniques.map(t => (
          <div key={t.id} className="an-tech-row">
            <span className="an-tech-id">{t.id}</span>
            <div>
              <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:3 }}>
                <span style={{ fontSize:11.5, color:'var(--text-primary)' }}>{t.name}</span>
                {t.defender && <span className="an-tech-alert"><Icon d={I.alert} size={9}/>+{t.alerts}</span>}
              </div>
              <div className="an-tech-bar">
                <div className={`an-tech-bar-fill ${t.defender?'has-defender':''}`} style={{ width:`${t.pct}%` }}/>
              </div>
            </div>
            <span className="an-tech-pct">{t.count}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Defense Score by Host (horizontal bars) ─────────────────────────
function DefenseByHostCard() {
  const max = Math.max(...AD_DASH.hostScores.map(h=>h.score));
  return (
    <div className="an-card">
      <div className="an-card-head">
        <div>
          <div className="an-card-title">
            <Icon d={I.monitor} size={13}/> Defense Score by Host
          </div>
          <div className="an-card-sub">PER-ENDPOINT BREAKDOWN · {AD_DASH.endpoints} HOSTS</div>
        </div>
      </div>
      <div>
        {AD_DASH.hostScores.map((h,i) => {
          const color = h.score >= 55 ? 'var(--accent)' : h.score >= 48 ? 'var(--warn-bright)' : 'var(--danger)';
          return (
            <div key={i} className="an-tech-row" style={{ gridTemplateColumns:'160px 1fr 60px' }}>
              <span className="an-tech-id" style={{ color:'var(--text-primary)', fontSize:11 }}>{h.host}</span>
              <div className="an-tech-bar" style={{ height:14 }}>
                <div className="an-tech-bar-fill" style={{ width:`${(h.score/max)*100}%`, background: color }}/>
              </div>
              <span className="an-tech-pct" style={{ color, fontWeight:600 }}>{h.score.toFixed(1)}%</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Test breadth treemap (host x test density) ──────────────────────
function TestBreadthTreemap() {
  // Synthesize a heatmap grid: hosts (rows) × techniques (cols). Cell shows count.
  const hosts = AD_DASH.hostScores.map(h => h.host);
  const techs = AD_DASH.techniques.slice(0, 10);
  const cell = (hi, ti) => {
    const seed = (hi*7 + ti*13) % 11;
    const v = ((techs[ti].count / 100) * (1 - hi*0.05)) + seed*0.012;
    return Math.max(0, Math.min(1, v));
  };
  return (
    <div className="an-card">
      <div className="an-card-head">
        <div>
          <div className="an-card-title">
            <Icon d={I.grid} size={13}/> Test Breadth by Host
          </div>
          <div className="an-card-sub">HOST × TECHNIQUE · COVERAGE DENSITY (DARKER = MORE COVERAGE)</div>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:8, fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-muted)' }}>
          <span>0</span>
          <div style={{ width:120, height:8, borderRadius:2, background:'linear-gradient(90deg, rgba(0,230,138,.08), rgba(0,230,138,.7))', border:'1px solid var(--line)' }}/>
          <span>120</span>
        </div>
      </div>
      <div style={{ overflowX:'auto' }}>
        <table style={{ borderCollapse:'collapse', width:'100%' }}>
          <thead>
            <tr>
              <th style={{ textAlign:'left', padding:'4px 6px', fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-muted)', letterSpacing:'.18em', textTransform:'uppercase' }}>Host</th>
              {techs.map(t => <th key={t.id} style={{ padding:'4px 6px', fontFamily:'var(--font-mono)', fontSize:9.5, color:'var(--text-muted)', letterSpacing:'.04em', writingMode:'sideways-lr', height:90 }}>{t.id}</th>)}
              <th style={{ padding:'4px 6px', fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-muted)', letterSpacing:'.18em', textTransform:'uppercase' }}>Total</th>
            </tr>
          </thead>
          <tbody>
            {hosts.map((h, hi) => {
              const total = techs.reduce((s,_,ti)=>s + Math.round(cell(hi,ti)*100), 0);
              return (
                <tr key={h}>
                  <td style={{ padding:'5px 6px', fontFamily:'var(--font-mono)', fontSize:10.5, color:'var(--text-secondary)', whiteSpace:'nowrap' }}>{h}</td>
                  {techs.map((t, ti) => {
                    const v = cell(hi, ti);
                    return (
                      <td key={t.id} style={{ padding:2 }}>
                        <div style={{
                          width:36, height:24, borderRadius:2,
                          background: `rgba(0,230,138,${0.06 + v*0.6})`,
                          border:'1px solid var(--line-soft)',
                          display:'grid', placeItems:'center',
                          fontFamily:'var(--font-mono)', fontSize:9.5,
                          color: v>0.4 ? '#062013' : 'var(--text-muted)',
                          fontWeight: v>0.4 ? 700 : 400,
                        }}>{Math.round(v*100)||''}</div>
                      </td>
                    );
                  })}
                  <td style={{ padding:'5px 6px', fontFamily:'var(--font-mono)', fontSize:11, color:'var(--accent)', textAlign:'right', fontWeight:600 }}>{total}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Dashboard composition ──────────────────────────────────────────
function AnalyticsDashboard() {
  return (
    <AnShell title="Analytics · Dashboard" activeTab="dashboard" label="Analytics — Dashboard">
      <div className="an-grid">
        <div className="col-4"><HeroScoreCard kind="defense"/></div>
        <div className="col-8"><TrendOverviewCard/></div>

        <div className="col-4"><HeroScoreCard kind="secure"/></div>
        <div className="col-8"><TopControlsCard/></div>

        <div className="col-6"><ScoreByCategoryCard/></div>
        <div className="col-6"><TestActivityCard/></div>

        <div className="col-6"><ErrorTypeCard/></div>
        <div className="col-6"><TechniqueDistCard/></div>

        <div className="col-6"><DefenseByHostCard/></div>
        <div className="col-6">
          <div className="an-card" style={{ height:'100%', display:'flex', flexDirection:'column' }}>
            <div className="an-card-head">
              <div>
                <div className="an-card-title"><Icon d={I.spark} size={13}/> Branch &amp; Sync Status</div>
                <div className="an-card-sub">CURRENT BASELINE FOR ANALYTICS QUERIES</div>
              </div>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:10, flex:1 }}>
              <MetaTile label="BRANCH" value={AD_DASH.branch} icon={I.branch} accent/>
              <MetaTile label="COMMIT" value={AD_DASH.commit} icon={I.cmd} mono/>
              <MetaTile label="SYNCED" value={AD_DASH.syncedAgo} icon={I.sync}/>
              <MetaTile label="WINDOW" value="LAST 21 DAYS" icon={I.clock}/>
              <MetaTile label="AVG COMPARABLE" value={AD_DASH.avgComparable.toFixed(1)+'%'} icon={I.target}/>
              <MetaTile label="ERROR RATE" value={AD_DASH.errorRate.toFixed(1)+'%'} icon={I.alert} good/>
            </div>
          </div>
        </div>

        <div className="col-12"><TestBreadthTreemap/></div>
      </div>
    </AnShell>
  );
}

function MetaTile({ label, value, icon, accent, mono, good }) {
  const valColor = accent ? 'var(--accent)' : good ? 'var(--accent)' : 'var(--text-primary)';
  return (
    <div style={{
      background:'var(--bg-elevated)', border:'1px solid var(--line)',
      borderRadius:6, padding:'12px 14px',
      display:'flex', flexDirection:'column', gap:6, justifyContent:'center'
    }}>
      <div style={{ display:'inline-flex', alignItems:'center', gap:6, fontFamily:'var(--font-mono)', fontSize:9.5, color:'var(--text-muted)', letterSpacing:'.2em' }}>
        <Icon d={icon} size={10}/>{label}
      </div>
      <div style={{ fontFamily: mono?'var(--font-mono)':'var(--font-display)', fontSize: mono?14:18, fontWeight: mono?500:700, color:valColor, letterSpacing: mono?'.05em':0 }}>
        {value}
      </div>
    </div>
  );
}

Object.assign(window, { AnalyticsDashboard });
