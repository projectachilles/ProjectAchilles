# Handoff: Analytics Module

## Overview

This is a redesign of the Achilles **Analytics Module** — four distinct surfaces under
the Analytics nav section. Current implementation lives in
`frontend/src/pages/analytics/` (multiple page files).

The redesign covers four sub-pages, all reachable from the Analytics sidebar entry:

1. **Analytics Dashboard** — hero scores (Defense Score + Secure Score), trend chart,
   top failing controls, score-by-category sunburst, test-activity timeline,
   error-type donut, technique distribution, defense-by-host bars, branch/sync meta,
   host × technique coverage heatmap.
2. **All Executions** — grouped bundle table with expandable child rows (one row per
   agent within a bundle), density toggle, scoring/archive controls, status counts.
3. **Defender** — Defender-specific surface: Secure Score hero, top remediation list,
   detection analysis bars, secure score trend, technique-overlap grid.
4. **Risk Acceptances** — tactical table of accepted-risk entries (technique, host,
   justification, owner, expiry, status).

The visual language is the same Tactical Green system established by the Dashboard V1
handoff (`design_handoff_dashboard_v1/`) and the landing page handoff
(`design_handoff_achilles_landing/`). Reuse those tokens; do not introduce new ones.

> **Branch.** Implement on a new branch — suggested name: `redesign/analytics-module-v1`.

## About the Design Files

The files in `source/` are **design references created in HTML/JSX** — a high-fidelity
prototype demonstrating the intended look, layout, behavior, copy, and interactions for
the Analytics Module. They use React 18 from a CDN with in-browser Babel transpilation
and mock data from `analytics-data.js`.

**Your job is not to ship this HTML directly.** Recreate the design in the existing
Fortika `frontend/` codebase using its established patterns: TSX components, the existing
styling system, the existing analytics hooks/services in `frontend/src/services/` and
`frontend/src/hooks/`, and the `AchillesShell` layout produced in the dashboard handoff
(if merged) or the existing layout shell otherwise.

## Fidelity

**High-fidelity (hifi).** All colors, typography, spacing, copy, and interaction details
are final. Recreate pixel-perfectly. All design tokens are inherited from
`source/styles.css` (already shipped via the dashboard handoff).

## File Map

```
design_handoff_analytics_module/
├── README.md                       ← you are here
└── source/
    ├── Analytics Module.html       ← entry point (script tags only)
    ├── analytics-app.jsx           ← root mount + design-canvas wrapper (strip in prod)
    ├── analytics-shared.jsx        ← AnalyticsShell, sub-nav, KPI tile, donut, heatmap helpers
    ├── analytics-dashboard.jsx     ← Dashboard sub-page
    ├── analytics-executions.jsx    ← All Executions sub-page
    ├── analytics-defender.jsx      ← Defender sub-page
    ├── analytics-risk.jsx          ← Risk Acceptances sub-page
    ├── analytics-data.js           ← mock data (window.ANALYTICS_DATA)
    ├── analytics.css               ← Analytics-module styles
    ├── shared.jsx                  ← Sidebar / TopBar / Icon set (from dashboard handoff)
    ├── data.js, styles.css, shell.css, v1.css, tests.css ← reused from prior handoffs
    ├── design-canvas.jsx           ← DEV ONLY canvas wrapper (strip)
    └── assets/
        └── logo-achilles.svg
```

## Sub-pages

The Analytics Module has its **own sub-nav** rendered as a horizontal tab strip below
the top bar, listing the four sub-pages. Active tab gets accent underline + bright text.
Tab strip lives in `analytics-shared.jsx` → `AnalyticsSubNav`. Each sub-page is a
separate route (`/analytics/dashboard`, `/analytics/executions`, etc.).

### 1 — Analytics Dashboard (`analytics-dashboard.jsx` → `AnalyticsDashboard`)

**Purpose:** glance at overall security posture across the fleet and the test catalog.

**Layout (12-col grid, gap 14px):**

- **Row 1 — Hero strip (12 cols):** two large score tiles side by side.
  - Defense Score (left, 6 cols): big Orbitron number + 14-day trend sparkline + delta tag.
  - Secure Score (right, 6 cols): same shape, accent-coloured by Defender threshold.
- **Row 2 — Trends + top controls (12 cols):**
  - Score trend chart (8 cols): full-width line chart, 30 days, multi-series (Def vs Sec).
  - Top failing controls (4 cols): top-5 list with score + delta + sparkline.
- **Row 3 — Distribution (12 cols):**
  - Score-by-category sunburst (4 cols).
  - Test activity timeline (4 cols): bars per day, last 14 days.
  - Error-type donut (4 cols): exit-code distribution.
- **Row 4 — Coverage (12 cols):**
  - Technique distribution histogram (6 cols): horizontal bars per MITRE tactic.
  - Defense by host (6 cols): horizontal bars per host with score.
- **Row 5 — Heatmap (12 cols):** Host × Technique coverage matrix
  (rows = hosts, cols = technique IDs, cell = pass/fail/N-A — 3-color heatmap).

### 2 — All Executions (`analytics-executions.jsx` → `AnalyticsExecutions`)

**Purpose:** browse every test execution, grouped by bundle (the parent task) with
per-agent child rows.

**Layout:**
- Filter strip (search · status chips · agent filter · date range · density toggle).
- Table:
  - Parent rows = bundles. Show: status counts (`completed ×8`, `failed ×2`, `pending`),
    bundle name, agent count, created time, action menu.
  - Click chevron → expand to inline child table: `agent · status · duration · exit · notes · actions`.
  - Density toggle: `compact / comfy` — switches row padding 6px ↔ 10px.
- Bulk-action toolbar appears when rows are checked: `Score selected · Archive · Export`.

### 3 — Defender (`analytics-defender.jsx` → `AnalyticsDefender`)

**Purpose:** Defender-specific posture — what the Defender catalog detected, what slipped,
what remediations are recommended.

**Layout (12-col grid):**
- **Hero (12 cols):** Secure Score big card (left, 6 cols) + 30-day trend (right, 6 cols).
- **Remediation row (12 cols):**
  - Top remediation list (6 cols): top-5 fixes by impact, each with affected-host count + apply-action.
  - Detection analysis bars (6 cols): horizontal bars per detection type, count + delta.
- **Technique overlap (12 cols):** grid showing Defender-detected techniques × Achilles-tested
  techniques, with overlap cells highlighted accent.

### 4 — Risk Acceptances (`analytics-risk.jsx` → `AnalyticsRisk`)

**Purpose:** track explicitly accepted risks — technique × host pairs that have been
formally signed off.

**Layout:**
- Filter strip (search · status · expiring-soon toggle).
- Table:
  - Columns: `technique (T####) · host · justification (truncated) · owner · accepted on · expires · status pill`.
  - Status pills: `active` (accent), `expiring` (warn-bright, <14 days), `expired` (danger), `revoked` (muted).
  - Per-row action menu: `Renew · Edit · Revoke`.

## Components & Cards

All cards reuse the `.dash-card` base from `shell.css`. New components introduced in
this module:

- **ScoreHero** (Dashboard + Defender): big Orbitron score + delta tag + trend sparkline.
- **ScoreTrendChart**: SVG line chart, multi-series, with hover tooltip.
- **CategorySunburst**: 2-ring sunburst (category → severity), colored by category palette.
- **ActivityTimeline**: 14-day vertical bar chart, accent fills.
- **ErrorTypeDonut**: 5-slice donut, exit-code coloring.
- **HostTechniqueHeatmap**: pixel-style grid, 3-color cells (pass/fail/N-A).
- **GroupedExecTable**: parent + child expandable rows.
- **DefenderRemediationList**: ranked-list with apply-action buttons.
- **TechniqueOverlapGrid**: matrix with accent overlap cells.
- **RiskTable**: same density rules as the executions table.

## Interactions & Behavior

- **Sub-nav active state:** derived from the route. No client-side tab state.
- **Score hero hover:** trend sparkline expands to show the day's value tooltip.
- **Heatmap cell hover:** tooltip with `host`, `technique ID`, `status`, `last run`.
- **Heatmap cell click:** navigate to the corresponding execution detail.
- **Executions parent-row chevron:** toggles the inline child table; row keeps state per session.
- **Bulk select:** standard checkbox model. Toolbar floats above the table when ≥1 row is checked.
- **Density toggle (executions):** persists in `localStorage` as `analytics.executions.density`.
- **Risk table action menu:** `Renew` opens a date-picker modal; `Revoke` opens a confirm
  dialog — reuse existing dialog patterns in the codebase.

## State Management

- `route`: the active sub-page (from React Router).
- `filters` (per sub-page): synced to URL.
- `expandedBundles` (executions): `Set<string>` of bundle IDs.
- `density` (executions): `'compact' | 'comfy'`, persisted in localStorage.
- `selectedRows` (executions, risk): `Set<string>`.

## Design Tokens

Reuse the tokens from `source/styles.css` per `design_handoff_dashboard_v1/README.md`.
No new tokens.

Heatmap cell colors:
- `pass` → `var(--accent)` at 80% opacity
- `fail` → `var(--danger)` at 80% opacity
- `n-a` → `rgba(255,255,255,.04)`

Module-specific style classes live in `source/analytics.css`.

## Data Model

The prototype uses `window.ANALYTICS_DATA` from `analytics-data.js`. Replace each field
with the real source from your existing services. Mapping:

| Mock field | Replace with |
|---|---|
| `defenseScore`, `secureScore` | Existing scoring service |
| `scoreTrend[]` | 30-day score history |
| `topFailingControls[]` | Bottom-5 controls by score |
| `categoryBreakdown` | Catalog aggregations by category × severity |
| `activityTimeline[]` | Run counts per day, last 14d |
| `errorTypes[]` | Exit-code histogram |
| `techniqueDistribution` | Catalog aggregations by tactic |
| `defenseByHost[]` | Per-host score |
| `hostTechniqueMatrix` | Per-host × per-technique latest run status |
| `executions[]` | Bundle-level executions service (already exists) |
| `defender.*` | Defender catalog + secure-score service |
| `riskAcceptances[]` | Existing risk-acceptance service |

## Assets

- `assets/logo-achilles.svg` — reuse existing import if present.

## Dev-only files to strip

- **`design-canvas.jsx`** + **`analytics-app.jsx`**.
- **The script-tag bootstrap** in `Analytics Module.html`.
- Any `?v=N` cache-busting query strings.
- Mock data files (`analytics-data.js`, `data.js`).

## Files in the source bundle

- `Analytics Module.html` — entry HTML (script tags only)
- `analytics-app.jsx` — design-canvas mount (dev only)
- `analytics-shared.jsx` — sub-nav, KPI tile, donut, heatmap helpers
- `analytics-dashboard.jsx` — Dashboard sub-page
- `analytics-executions.jsx` — All Executions sub-page
- `analytics-defender.jsx` — Defender sub-page
- `analytics-risk.jsx` — Risk Acceptances sub-page
- `analytics-data.js` — mock data
- `analytics.css` — Analytics-module styles
- Plus reused shell files: `shared.jsx`, `data.js`, `styles.css`, `shell.css`, `v1.css`,
  `tests.css` (some pill/badge classes are reused)
- `design-canvas.jsx` — dev-only wrapper (strip)
- `assets/logo-achilles.svg`
